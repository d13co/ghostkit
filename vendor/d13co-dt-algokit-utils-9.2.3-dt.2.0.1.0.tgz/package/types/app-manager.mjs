import { DELETABLE_TEMPLATE_NAME, UPDATABLE_TEMPLATE_NAME } from "./app.mjs";
import { getABIReturnValue } from "../transaction/transaction.mjs";
import { dtAlgodForRead, fetchOptions } from "./dt-support.mjs";
import algosdk, { ProgramSourceMap } from "algosdk";
//#region src/types/app-manager.ts
/** Allows management of application information. */
var AppManager = class AppManager {
	_algod;
	_compilationResults = {};
	/**
	* Creates an `AppManager`
	* @param algod An algod instance
	*/
	constructor(algod) {
		this._algod = algod;
	}
	/**
	* Compiles the given TEAL using algod and returns the result, including source map.
	*
	* The result of this compilation is also cached keyed by the TEAL
	*  code so it can be retrieved via `getCompilationResult`.
	*
	* This function is re-entrant; it will only compile the same code once.
	*
	* @param tealCode The TEAL code
	* @returns The information about the compiled file
	* @example
	* ```typescript
	* const compiled = await appManager.compileTeal(tealProgram)
	* ```
	*/
	async compileTeal(tealCode) {
		if (this._compilationResults[tealCode]) return this._compilationResults[tealCode];
		const compiled = await this._algod.compile(tealCode).sourcemap(true).do();
		const result = {
			teal: tealCode,
			compiled: compiled.result,
			compiledHash: compiled.hash,
			compiledBase64ToBytes: new Uint8Array(Buffer.from(compiled.result, "base64")),
			sourceMap: new ProgramSourceMap(JSON.parse(algosdk.encodeJSON(compiled.sourcemap)))
		};
		this._compilationResults[tealCode] = result;
		return result;
	}
	/**
	* Performs template substitution of a teal template and compiles it, returning the compiled result.
	*
	* Looks for `TMPL_{parameter}` for template replacements and replaces AlgoKit deploy-time control parameters
	* if deployment metadata is specified.
	*
	* * `TMPL_UPDATABLE` for updatability / immutability control
	* * `TMPL_DELETABLE` for deletability / permanence control
	*
	* @param tealTemplateCode The TEAL logic to compile
	* @param templateParams Any parameters to replace in the .teal file before compiling
	* @param deploymentMetadata The deployment metadata the app will be deployed with
	* @returns The information about the compiled code
	* @example
	* ```typescript
	* const compiled = await appManager.compileTealTemplate(tealTemplate, { TMPL_APP_ID: 12345n }, { updatable: true, deletable: false })
	* ```
	*/
	async compileTealTemplate(tealTemplateCode, templateParams, deploymentMetadata) {
		let tealCode = AppManager.stripTealComments(tealTemplateCode);
		tealCode = AppManager.replaceTealTemplateParams(tealCode, templateParams);
		if (deploymentMetadata) tealCode = AppManager.replaceTealTemplateDeployTimeControlParams(tealCode, deploymentMetadata);
		return await this.compileTeal(tealCode);
	}
	/**
	* Returns a previous compilation result.
	* @param tealCode The TEAL code
	* @returns The information about the previously compiled file
	*  or `undefined` if that TEAL code wasn't previously compiled
	* @example
	* ```typescript
	* const compiled = appManager.getCompilationResult(tealProgram)
	* ```
	*/
	getCompilationResult(tealCode) {
		return this._compilationResults[tealCode];
	}
	/**
	* Returns the current app information for the app with the given ID.
	*
	* @example
	* ```typescript
	* const appInfo = await appManager.getById(12353n);
	* ```
	*
	* @param appId The ID of the app
	* @param options Optional `round` to read the app as of the end of a past round (needs dtalgod time travel)
	* @returns The app information
	*/
	async getById(appId, options) {
		const round = options?.round;
		const app = round === void 0 ? await this._algod.getApplicationByID(Number(appId)).do(void 0, fetchOptions(options)) : await (await dtAlgodForRead(this._algod, "Reading an app", round, true)).getApplicationByID(appId).round(round).do(void 0, fetchOptions(options));
		return AppManager.appInformationFromAlgod(app);
	}
	/**
	* Converts an algod application into an `AppInformation`.
	* @param app The application from algod
	* @returns The app information
	*/
	static appInformationFromAlgod(app) {
		const params = app.params;
		return {
			appId: BigInt(app.id),
			appAddress: algosdk.getApplicationAddress(app.id),
			approvalProgram: params.approvalProgram,
			clearStateProgram: params.clearStateProgram,
			creator: params.creator,
			localInts: Number(params.localStateSchema?.numUint ?? 0),
			localByteSlices: Number(params.localStateSchema?.numByteSlice ?? 0),
			globalInts: Number(params.globalStateSchema?.numUint ?? 0),
			globalByteSlices: Number(params.globalStateSchema?.numByteSlice ?? 0),
			extraProgramPages: Number(params.extraProgramPages ?? 0),
			globalState: AppManager.decodeAppState(params.globalState ?? []),
			version: params.version
		};
	}
	/**
	* Returns the current global state values for the given app ID and account address
	*
	* @param appId The ID of the app to return global state for
	* @param options Optional `round` to read the state as of the end of a past round (needs dtalgod time travel)
	* @returns The current global state for the given app
	* @example
	* ```typescript
	* const globalState = await appManager.getGlobalState(12353n);
	* ```
	*/
	async getGlobalState(appId, options) {
		return (await this.getById(appId, options)).globalState;
	}
	/**
	* Returns the current local state values for the given app ID and account address
	*
	* @param appId The ID of the app to return local state for
	* @param address The string address of the account to get local state for the given app
	* @param options Optional `round` to read the state as of the end of a past round (needs dtalgod time travel)
	* @returns The current local state for the given (app, account) combination
	* @example
	* ```typescript
	* const localState = await appManager.getLocalState(12353n, 'ACCOUNTADDRESS');
	* ```
	*/
	async getLocalState(appId, address, options) {
		const round = options?.round;
		const appInfo = round === void 0 ? await this._algod.accountApplicationInformation(address, appId).do(void 0, fetchOptions(options)) : await (await dtAlgodForRead(this._algod, "Reading local state", round, false)).accountApplicationInformation(address, appId).round(round).do(void 0, fetchOptions(options));
		if (!appInfo.appLocalState?.keyValue) throw new Error("Couldn't find local state");
		return AppManager.decodeAppState(appInfo.appLocalState.keyValue);
	}
	/**
	* Returns the names of the current boxes for the given app.
	* @param appId The ID of the app return box names for
	* @param options Optional `round` to list the boxes as of the end of a past round (needs dtalgod time travel)
	* @returns The current box names
	* @example
	* ```typescript
	* const boxNames = await appManager.getBoxNames(12353n);
	* ```
	*/
	async getBoxNames(appId, options) {
		const round = options?.round;
		let boxes;
		if (round === void 0) boxes = (await this._algod.getApplicationBoxes(appId).do(void 0, fetchOptions(options))).boxes;
		else {
			const tt = await dtAlgodForRead(this._algod, "Listing boxes", round, false);
			boxes = [];
			let next = void 0;
			do {
				const page = await tt.getApplicationBoxes(appId).round(round).next(next).do(void 0, fetchOptions(options));
				boxes.push(...page.boxes);
				next = page.nextToken;
			} while (next);
		}
		return boxes.map((b) => {
			return {
				nameRaw: b.name,
				nameBase64: Buffer.from(b.name).toString("base64"),
				name: Buffer.from(b.name).toString("utf-8")
			};
		});
	}
	/**
	* Returns the value of the given box name for the given app.
	* @param appId The ID of the app return box names for
	* @param boxName The name of the box to return either as a string, binary array or `BoxName`
	* @param options Optional `round` to read the box as of the end of a past round (needs dtalgod time travel)
	* @returns The current box value as a byte array
	* @example
	* ```typescript
	* const boxValue = await appManager.getBoxValue(12353n, 'boxName');
	* ```
	*/
	async getBoxValue(appId, boxName, options) {
		const boxId = typeof boxName === "object" && "nameRaw" in boxName ? boxName.nameRaw : boxName;
		const name = AppManager.getBoxReference(boxId).name;
		const round = options?.round;
		return (round === void 0 ? await this._algod.getApplicationBoxByName(Number(appId), name).do(void 0, fetchOptions(options)) : await (await dtAlgodForRead(this._algod, "Reading a box", round, false)).getApplicationBoxByName(appId, name).round(round).do(void 0, fetchOptions(options))).value;
	}
	/**
	* Returns the value of the given box names for the given app.
	* @param appId The ID of the app return box names for
	* @param boxNames The names of the boxes to return either as a string, binary array or `BoxName`
	* @param options Optional `round` to read the boxes as of the end of a past round (needs dtalgod time travel)
	* @returns The current box values as a byte array in the same order as the passed in box names
	* @example
	* ```typescript
	* const boxValues = await appManager.getBoxValues(12353n, ['boxName1', 'boxName2']);
	* ```
	*/
	async getBoxValues(appId, boxNames, options) {
		return await Promise.all(boxNames.map(async (boxName) => await this.getBoxValue(appId, boxName, options)));
	}
	/**
	* Returns the value of the given box name for the given app decoded based on the given ABI type.
	* @param request The parameters for the box value request
	* @returns The current box value as an ABI value
	* @example
	* ```typescript
	* const boxValue = await appManager.getBoxValueFromABIType({ appId: 12353n, boxName: 'boxName', type: new ABIUintType(32) });
	* ```
	*/
	async getBoxValueFromABIType(request) {
		const { appId, boxName, type, round } = request;
		const value = await this.getBoxValue(appId, boxName, round === void 0 ? void 0 : { round });
		return type.decode(value);
	}
	/**
	* Returns the value of the given box names for the given app decoded based on the given ABI type.
	* @param request The parameters for the box value request
	* @returns The current box values as an ABI value in the same order as the passed in box names
	* @example
	* ```typescript
	* const boxValues = await appManager.getBoxValuesFromABIType({ appId: 12353n, boxNames: ['boxName1', 'boxName2'], type: new ABIUintType(32) });
	* ```
	*/
	async getBoxValuesFromABIType(request) {
		const { appId, boxNames, type, round } = request;
		return await Promise.all(boxNames.map(async (boxName) => await this.getBoxValueFromABIType({
			appId,
			boxName,
			type,
			round
		})));
	}
	/**
	* Returns a `algosdk.BoxReference` given a `BoxIdentifier` or `BoxReference`.
	* @param boxId The box to return a reference for
	* @returns The box reference ready to pass into a `algosdk.Transaction`
	* @example
	* ```typescript
	* const boxRef = AppManager.getBoxReference('boxName');
	* ```
	*/
	static getBoxReference(boxId) {
		const ref = typeof boxId === "object" && "appId" in boxId ? boxId : {
			appId: 0n,
			name: boxId
		};
		return {
			appIndex: ref.appId,
			name: typeof ref.name === "string" ? new TextEncoder().encode(ref.name) : "length" in ref.name ? ref.name : ref.name.addr.publicKey
		};
	}
	/**
	* Converts an array of global/local state values from the algod api to a more friendly
	* generic object keyed by the UTF-8 value of the key.
	* @param state A `global-state`, `local-state`, `global-state-deltas` or `local-state-deltas`
	* @returns An object keyeed by the UTF-8 representation of the key with various parsings of the values
	* @example
	* ```typescript
	* const stateValues = AppManager.decodeAppState(state);
	* ```
	*/
	static decodeAppState(state) {
		const stateValues = {};
		for (const stateVal of state) {
			const keyBase64 = Buffer.from(stateVal.key).toString("base64");
			const keyRaw = stateVal.key;
			const key = Buffer.from(stateVal.key).toString("utf-8");
			const tealValue = stateVal.value;
			const dataTypeFlag = "action" in tealValue ? tealValue.action : tealValue.type;
			let valueBase64;
			let valueRaw;
			switch (dataTypeFlag) {
				case 1:
					valueBase64 = typeof tealValue.bytes === "string" ? tealValue.bytes : tealValue.bytes ? Buffer.from(tealValue.bytes).toString("base64") : "";
					valueRaw = Buffer.from(valueBase64, "base64");
					stateValues[key] = {
						keyRaw,
						keyBase64,
						valueRaw: new Uint8Array(valueRaw),
						valueBase64,
						value: valueRaw.toString("utf-8")
					};
					break;
				case 2:
					stateValues[key] = {
						keyRaw,
						keyBase64,
						value: BigInt(tealValue.uint ?? 0)
					};
					break;
				default: throw new Error(`Received unknown state data type of ${dataTypeFlag}`);
			}
		}
		return stateValues;
	}
	/**
	* Returns any ABI return values for the given app call arguments and transaction confirmation.
	* @param confirmation The transaction confirmation from algod
	* @param method The ABI method
	* @returns The return value for the method call
	* @example
	* ```typescript
	* const returnValue = AppManager.getABIReturn(confirmation, ABIMethod.fromSignature('hello(string)void'));
	* ```
	*/
	static getABIReturn(confirmation, method) {
		if (!method || !confirmation || method.returns.type === "void") return;
		return getABIReturnValue(algosdk.AtomicTransactionComposer.parseMethodResponse(method, {
			txID: "",
			method,
			rawReturnValue: /* @__PURE__ */ new Uint8Array()
		}, confirmation), method.returns.type);
	}
	/**
	* Replaces AlgoKit deploy-time deployment control parameters within the given TEAL template code.
	*
	* * `TMPL_UPDATABLE` for updatability / immutability control
	* * `TMPL_DELETABLE` for deletability / permanence control
	*
	* Note: If these values are defined, but the corresponding `TMPL_*` value
	*  isn't in the teal code it will throw an exception.
	*
	* @param tealTemplateCode The TEAL template code to substitute
	* @param params The deploy-time deployment control parameter value to replace
	* @returns The replaced TEAL code
	* @example
	* ```typescript
	* const tealCode = AppManager.replaceTealTemplateDeployTimeControlParams(tealTemplate, { updatable: true, deletable: false });
	* ```
	*/
	static replaceTealTemplateDeployTimeControlParams(tealTemplateCode, params) {
		if (params.updatable !== void 0) {
			if (!tealTemplateCode.includes("TMPL_UPDATABLE")) throw new Error(`Deploy-time updatability control requested for app deployment, but ${UPDATABLE_TEMPLATE_NAME} not present in TEAL code`);
			tealTemplateCode = replaceTemplateVariable(tealTemplateCode, UPDATABLE_TEMPLATE_NAME, (params.updatable ? 1 : 0).toString());
		}
		if (params.deletable !== void 0) {
			if (!tealTemplateCode.includes("TMPL_DELETABLE")) throw new Error(`Deploy-time deletability control requested for app deployment, but ${DELETABLE_TEMPLATE_NAME} not present in TEAL code`);
			tealTemplateCode = replaceTemplateVariable(tealTemplateCode, DELETABLE_TEMPLATE_NAME, (params.deletable ? 1 : 0).toString());
		}
		return tealTemplateCode;
	}
	/**
	* Performs template substitution of a teal file.
	*
	* Looks for `TMPL_{parameter}` for template replacements.
	*
	* @param tealTemplateCode The TEAL template code to make parameter replacements in
	* @param templateParams Any parameters to replace in the teal code
	* @returns The TEAL code with replacements
	* @example
	* ```typescript
	* const tealCode = AppManager.replaceTealTemplateParams(tealTemplate, { TMPL_APP_ID: 12345n });
	* ```
	*/
	static replaceTealTemplateParams(tealTemplateCode, templateParams) {
		if (templateParams !== void 0) for (const key in templateParams) {
			const value = templateParams[key];
			const token = `TMPL_${key.replace(/^TMPL_/, "")}`;
			if (typeof value === "number" || typeof value === "bigint") tealTemplateCode = tealTemplateCode.replace(new RegExp(`(?<=bytes )${token}`, "g"), `0x${value.toString(16).padStart(16, "0")}`);
			tealTemplateCode = replaceTemplateVariable(tealTemplateCode, token, typeof value === "string" ? `0x${Buffer.from(value, "utf-8").toString("hex")}` : ArrayBuffer.isView(value) ? `0x${Buffer.from(value).toString("hex")}` : value.toString());
		}
		return tealTemplateCode;
	}
	/**
	* Remove comments from TEAL code (useful to reduce code size before compilation).
	*
	* @param tealCode The TEAL logic to strip
	* @returns The TEAL without comments
	* @example
	* ```typescript
	* const stripped = AppManager.stripTealComments(tealProgram);
	* ```
	*/
	static stripTealComments(tealCode) {
		const stripCommentFromLine = (line) => {
			const commentIndex = findUnquotedString(line, "//");
			if (commentIndex === void 0) return line;
			return line.slice(0, commentIndex).trimEnd();
		};
		return tealCode.split("\n").map((line) => stripCommentFromLine(line)).join("\n");
	}
};
/**
* Find the first string within a line of TEAL. Only matches outside of quotes and base64 are returned.
* Returns undefined if not found
*/
const findUnquotedString = (line, token, startIndex = 0, _endIndex) => {
	const endIndex = _endIndex === void 0 ? line.length : _endIndex;
	let index = startIndex;
	let inQuotes = false;
	let inBase64 = false;
	while (index < endIndex) {
		const currentChar = line[index];
		if ((currentChar === " " || currentChar === "(") && !inQuotes && lastTokenBase64(line, index)) inBase64 = true;
		else if ((currentChar === " " || currentChar === ")") && !inQuotes && inBase64) inBase64 = false;
		else if (currentChar === "\\" && inQuotes) index += 1;
		else if (currentChar === "\"") inQuotes = !inQuotes;
		else if (!inQuotes && !inBase64 && line.startsWith(token, index)) return index;
		index += 1;
	}
};
const lastTokenBase64 = (line, index) => {
	try {
		const tokens = line.slice(0, index).split(/\s+/);
		const last = tokens[tokens.length - 1];
		return ["base64", "b64"].includes(last);
	} catch {
		return false;
	}
};
function replaceTemplateVariable(program, token, replacement) {
	const result = [];
	const tokenIndexOffset = replacement.length - token.length;
	const programLines = program.split("\n");
	for (const line of programLines) {
		const _commentIndex = findUnquotedString(line, "//");
		const commentIndex = _commentIndex === void 0 ? line.length : _commentIndex;
		let code = line.substring(0, commentIndex);
		const comment = line.substring(commentIndex);
		let trailingIndex = 0;
		while (true) {
			const tokenIndex = findTemplateToken(code, token, trailingIndex);
			if (tokenIndex === void 0) break;
			trailingIndex = tokenIndex + token.length;
			code = `${code.substring(0, tokenIndex)}${replacement}${code.substring(trailingIndex)}`;
			trailingIndex += tokenIndexOffset;
		}
		result.push(code + comment);
	}
	return result.join("\n");
}
const findTemplateToken = (line, token, startIndex = 0, _endIndex) => {
	const endIndex = _endIndex === void 0 ? line.length : _endIndex;
	let index = startIndex;
	while (index < endIndex) {
		const tokenIndex = findUnquotedString(line, token, index, endIndex);
		if (tokenIndex === void 0) break;
		const trailingIndex = tokenIndex + token.length;
		if ((tokenIndex === 0 || !isValidTokenCharacter(line[tokenIndex - 1])) && (trailingIndex >= line.length || !isValidTokenCharacter(line[trailingIndex]))) return tokenIndex;
		index = trailingIndex;
	}
};
function isValidTokenCharacter(char) {
	return char.length === 1 && (/\w/.test(char) || char === "_");
}
//#endregion
export { AppManager };

//# sourceMappingURL=app-manager.mjs.map