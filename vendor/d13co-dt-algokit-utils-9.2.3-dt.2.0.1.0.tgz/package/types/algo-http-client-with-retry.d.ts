import { BaseHTTPClientResponse, Query, URLTokenBaseHTTPClient } from 'algosdk/client';
/**
 * A HTTP Client that wraps the Algorand SDK HTTP Client with retries.
 *
 * A 429 or 503 with a `Retry-After` header waits at least that long before the next try (capped at 10 s). A 504 from
 * `POST /v2/query` (the node's time limit) is not retried.
 */
export declare class AlgoHttpClientWithRetry extends URLTokenBaseHTTPClient {
    private static readonly MAX_TRIES;
    private static readonly MAX_BACKOFF_MS;
    private static readonly RETRY_STATUS_CODES;
    /**
     * The status codes retried for `POST /v2/query`: all but 504, which is the node's time limit. A retry would repeat the
     * whole (up to `time-limit-seconds`) work; the caller splits the request instead.
     */
    private static readonly QUERY_RETRY_STATUS_CODES;
    /** The status codes whose `Retry-After` header is honored. */
    private static readonly RETRY_AFTER_STATUS_CODES;
    private static readonly RETRY_ERROR_CODES;
    /** The abort signal in fetch options passed as `customOptions`, if any. */
    private static signalOf;
    /** Waits `ms`, rejecting with the signal's reason as soon as it aborts. */
    private static sleep;
    /**
     * How long a failed response asks to wait before retrying, from its `Retry-After` header (seconds or an HTTP date),
     * or undefined without one. Only for 429 and 503. The header name is looked up case-insensitively.
     */
    private static retryAfterMs;
    /** The status codes to retry for a request to `relativePath`. */
    private static retryStatusCodes;
    private callWithRetry;
    get(relativePath: string, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
    post(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
    delete(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
}
