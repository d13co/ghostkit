const require_app = require("./types/app.js");
let algosdk = require("algosdk");
//#region src/util.ts
/**
* Converts a value which might be a number or a bigint into a number to be used with apis that don't support bigint.
*
* Throws an UnsafeConversionError if the conversion would result in an unsafe integer for the Number type
* @param value
*/
const toNumber = (value) => {
	if (typeof value === "number") return value;
	if (value > BigInt(Number.MAX_SAFE_INTEGER)) throw new UnsafeConversionError(`Cannot convert ${value} to a Number as it is larger than the maximum safe integer the Number type can hold.`);
	else if (value < BigInt(Number.MIN_SAFE_INTEGER)) throw new UnsafeConversionError(`Cannot convert ${value} to a Number as it is smaller than the minimum safe integer the Number type can hold.`);
	return Number(value);
};
var UnsafeConversionError = class extends Error {};
/**
* Calculates the amount of funds to add to a wallet to bring it up to the minimum spending balance.
* @param minSpendingBalance The minimum spending balance for the wallet
* @param currentSpendingBalance The current spending balance for the wallet
* @param minFundingIncrement The minimum amount of funds that can be added to the wallet
* @returns The amount of funds to add to the wallet or null if the wallet is already above the minimum spending balance
*/
const calculateFundAmount = (minSpendingBalance, currentSpendingBalance, minFundingIncrement) => {
	if (minSpendingBalance > currentSpendingBalance) {
		const minFundAmount = minSpendingBalance - currentSpendingBalance;
		return BigInt(Math.max(Number(minFundAmount), Number(minFundingIncrement)));
	} else return null;
};
/**
* Returns the given array split into chunks of `batchSize` batches.
* @param array The array to chunk
* @param batchSize The size of batches to split the array into
* @returns A generator that yields the array split into chunks of `batchSize` batches
*/
function* chunkArray(array, batchSize) {
	for (let i = 0; i < array.length; i += batchSize) yield array.slice(i, i + batchSize);
}
/**
* Memoize calls to the given function in an in-memory map.
* @param fn The function to memoize
* @returns The memoized function
*/
const memoize = (fn) => {
	const cache = /* @__PURE__ */ new Map();
	const cached = function(val) {
		return cache.has(val) ? cache.get(val) : cache.set(val, fn.call(this, val)) && cache.get(val);
	};
	cached.cache = cache;
	return cached;
};
const binaryStartsWith = (base, startsWith) => {
	if (startsWith.length > base.length) return false;
	for (let i = 0; i < startsWith.length; i++) if (base[i] !== startsWith[i]) return false;
	return true;
};
const defaultJsonValueReplacer = (key, value) => {
	if (typeof value === "bigint") try {
		return toNumber(value);
	} catch {
		return value.toString();
	}
	return value;
};
const asJson = (value, replacer = defaultJsonValueReplacer, space) => {
	return JSON.stringify(value, replacer, space);
};
/** Calculate minimum number of extra program pages required for provided approval and clear state programs */
const calculateExtraProgramPages = (approvalProgram, clearStateProgram) => {
	return Math.floor((approvalProgram.length + (clearStateProgram?.length ?? 0) - 1) / require_app.APP_PAGE_MAX_SIZE);
};
/** Take a decoded ABI value and convert all byte arrays (including nested ones) from number[] to Uint8Arrays */
function convertAbiByteArrays(value, type) {
	if (!type.toString().includes("byte") || value instanceof Uint8Array) return value;
	if ((type instanceof algosdk.ABIArrayStaticType || type instanceof algosdk.ABIArrayDynamicType) && type.childType instanceof algosdk.ABIByteType && Array.isArray(value)) return new Uint8Array(value);
	if ((type instanceof algosdk.ABIArrayStaticType || type instanceof algosdk.ABIArrayDynamicType) && Array.isArray(value)) {
		const result = [];
		for (let i = 0; i < value.length; i++) result.push(convertAbiByteArrays(value[i], type.childType));
		return result;
	}
	if (type instanceof algosdk.ABITupleType && Array.isArray(value)) {
		const result = [];
		for (let i = 0; i < value.length && i < type.childTypes.length; i++) result.push(convertAbiByteArrays(value[i], type.childTypes[i]));
		return result;
	}
	return value;
}
/**
* Convert bigint values to numbers for uint types with bit size < 53
*/
const convertABIDecodedBigIntToNumber = (value, type) => {
	if (typeof value === "bigint") {
		if (type instanceof algosdk.ABIUintType) return type.bitSize < 53 ? Number(value) : value;
		else return value;
	} else if (Array.isArray(value) && (type instanceof algosdk.ABIArrayStaticType || type instanceof algosdk.ABIArrayDynamicType)) return value.map((v) => convertABIDecodedBigIntToNumber(v, type.childType));
	else if (Array.isArray(value) && type instanceof algosdk.ABITupleType) return value.map((v, i) => convertABIDecodedBigIntToNumber(v, type.childTypes[i]));
	else return value;
};
//#endregion
exports.UnsafeConversionError = UnsafeConversionError;
exports.asJson = asJson;
exports.binaryStartsWith = binaryStartsWith;
exports.calculateExtraProgramPages = calculateExtraProgramPages;
exports.calculateFundAmount = calculateFundAmount;
exports.chunkArray = chunkArray;
exports.convertABIDecodedBigIntToNumber = convertABIDecodedBigIntToNumber;
exports.convertAbiByteArrays = convertAbiByteArrays;
exports.defaultJsonValueReplacer = defaultJsonValueReplacer;
exports.memoize = memoize;
exports.toNumber = toNumber;

//# sourceMappingURL=util.js.map