import { AlgoConfig } from '../../types/network-client';
import { AlgorandFixture, AlgorandFixtureConfig } from '../../types/testing';
/**
 * Creates a test fixture for automated testing against Algorand.
 * By default it tests against an environment variable specified client
 *  if the standard environment variables are specified, otherwise against
 *  a default LocalNet instance, but you can pass in an algod, indexer
 *  and/or kmd (or their respective config) if you want to test against
 * an explicitly defined network.
 *
 * @example No config (per-test isolation)
 * ```typescript
 * const fixture = algorandFixture()
 *
 * beforeEach(fixture.newScope)
 *
 * test('My test', async () => {
 *     const {algod, indexer, testAccount, ...} = fixture.context
 *     // test things...
 * })
 * ```
 *
 * @example No config (test suite isolation)
 * ```typescript
 * const fixture = algorandFixture()
 *
 * beforeAll(fixture.newScope)
 *
 * test('My test', async () => {
 *     const {algod, indexer, testAccount, ...} = fixture.context
 *     // test things...
 * })
 * ```
 *
 * @example With config
 * ```typescript
 * const fixture = algorandFixture({
 *  algod: new Algodv2('localhost', 12345, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
 *  // ...
 * })
 *
 * beforeEach(fixture.newScope)
 *
 * test('My test', async () => {
 *     const {algod, indexer, testAccount, ...} = fixture.context
 *     // test things...
 * })
 * ```
 *
 * @param fixtureConfig The fixture configuration
 * @returns The fixture
 */
export declare function algorandFixture(fixtureConfig?: AlgorandFixtureConfig): AlgorandFixture;
/**
 * @deprecated Config can be passed in directly to fixture config now.
 *
 * Creates a test fixture for automated testing against Algorand.
 * By default it tests against an environment variable specified client
 *  if the standard environment variables are specified, otherwise against
 *  a default LocalNet instance, but you can pass in an algod, indexer
 *  and/or kmd if you want to test against an explicitly defined network.
 *
 * @param fixtureConfig The fixture configuration
 * @param config The fixture configuration
 * @returns The fixture
 */
export declare function algorandFixture(fixtureConfig: AlgorandFixtureConfig | undefined, config: AlgoConfig): AlgorandFixture;
