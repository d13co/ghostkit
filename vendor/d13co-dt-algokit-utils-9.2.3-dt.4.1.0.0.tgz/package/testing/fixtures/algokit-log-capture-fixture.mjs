import { Config } from "../../config.mjs";
import { TestLogger } from "../test-logger.mjs";
//#region src/testing/fixtures/algokit-log-capture-fixture.ts
/**
* Creates a test fixture for capturing AlgoKit logs.
*
* @example
* ```typescript
* const logs = algoKitLogCaptureFixture()
*
* beforeEach(logs.beforeEach)
* afterEach(logs.afterEach)
*
* test('My test', () => {
*     const capturedLogs = logs.testLogger.capturedLogs
* })
* ```
*
* @returns The fixture
*/
const algoKitLogCaptureFixture = () => {
	const originalLogger = Config.logger;
	let hybridLogger;
	return {
		get testLogger() {
			return hybridLogger;
		},
		beforeEach: () => {
			hybridLogger = new TestLogger(originalLogger);
			Config.configure({ logger: hybridLogger });
		},
		afterEach: () => {
			Config.configure({ logger: originalLogger });
		}
	};
};
//#endregion
export { algoKitLogCaptureFixture };

//# sourceMappingURL=algokit-log-capture-fixture.mjs.map