import { Logger } from '../types/logging';
import { LogSnapshotConfig } from '../types/testing';
/** Exposes an AlgoKit logger which captures log messages, while wrapping an original logger.
 * This is useful for automated testing.
 */
export declare class TestLogger implements Logger {
    private originalLogger;
    private logs;
    /**
     * Create a new test logger that wraps the given logger if provided.
     * @param originalLogger The optional original logger to wrap.
     */
    constructor(originalLogger?: Logger);
    /** Returns all logs captured thus far. */
    get capturedLogs(): string[];
    /** Clears all logs captured so far. */
    clear(): void;
    /**
     * Returns a captured log snapshot.
     * This helps ensure that the provided configuration items won't appear
     *  with random values in the log snapshot, but rather will get substituted with predictable ids.
     *
     * https://jestjs.io/docs/snapshot-testing#2-tests-should-be-deterministic
     *
     * @example Jest Example
     * ```typescript
     * const logger = new TestLogger()
     * ...
     * expect(logger.getLogSnapshot()).toMatchSnapshot()
     * ```
     * @param config The snapshot configuration
     * @returns The snapshotted logs.
     */
    getLogSnapshot(config?: LogSnapshotConfig): string;
    error(message: string, ...optionalParams: unknown[]): void;
    warn(message: string, ...optionalParams: unknown[]): void;
    info(message: string, ...optionalParams: unknown[]): void;
    verbose(message: string, ...optionalParams: unknown[]): void;
    debug(message: string, ...optionalParams: unknown[]): void;
}
