import algosdk from 'algosdk';
import { SendTransactionResult } from '../types/transaction';
import { AlgoTransferParams } from '../types/transfer';
import Algodv2 = algosdk.Algodv2;
/**
 * @deprecated Use `algorand.send.payment()` / `algorand.createTransaction.payment()` instead
 *
 * Transfer Algo between two accounts.
 * @param transfer The transfer definition
 * @param algod An algod client
 * @returns The transaction object and optionally the confirmation if it was sent to the chain (`skipSending` is `false` or unset)
 *
 * @example Usage example
 * ```typescript
 * await algokit.transferAlgos({ from, to, amount: algokit.algo(1) }, algod)
 * ```
 */
export declare function transferAlgos(transfer: AlgoTransferParams, algod: Algodv2): Promise<SendTransactionResult>;
