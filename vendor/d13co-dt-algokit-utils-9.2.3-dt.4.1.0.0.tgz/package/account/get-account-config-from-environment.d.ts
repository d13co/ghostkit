import { AccountConfig } from '../types/account';
/**  @deprecated Use algokit.mnemonicAccountFromEnvironment, which doesn't need this function
 * Returns the Account configuration from environment variables
 *
 * @param accountName account name
 *
 * @example environment variables
 * {accountName}_MNEMONIC
 * {accountName}_SENDER
 *
 */
export declare function getAccountConfigFromEnvironment(accountName: string): AccountConfig;
