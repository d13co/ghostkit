Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_config = require("../config.js");
const require_util = require("../util.js");
const require_dt_support = require("./dt-support.js");
require("./composer.js");
//#region src/types/asset-manager.ts
/** Allows management of asset information. */
var AssetManager = class AssetManager {
	_algod;
	_newGroup;
	/**
	* Create a new asset manager.
	* @param algod An algod client
	* @param newGroup A function that creates a new `TransactionComposer` transaction group
	* @example Create a new asset manager
	* ```typescript
	* const assetManager = new AssetManager(algod, () => new TransactionComposer({algod, () => signer, () => suggestedParams}))
	* ```
	*/
	constructor(algod, newGroup) {
		this._algod = algod;
		this._newGroup = newGroup;
	}
	/**
	* Returns the current asset information for the asset with the given ID.
	*
	* @example
	* ```typescript
	* const assetInfo = await assetManager.getById(12353n);
	* ```
	*
	* @param assetId The ID of the asset
	* @param options Optional `round` to read the asset as of the end of a past round (needs dtalgod time travel)
	* @returns The asset information
	*/
	async getById(assetId, options) {
		const round = options?.round;
		const asset = round === void 0 ? await this._algod.getAssetByID(Number(assetId)).do() : await (await require_dt_support.requireTimeTravel(this._algod, "Reading an asset", round)).getAssetByID(assetId).round(round).do();
		return AssetManager.assetInformationFromAlgod(asset);
	}
	/**
	* Converts an algod asset into an `AssetInformation`.
	* @param asset The asset from algod
	* @returns The asset information
	*/
	static assetInformationFromAlgod(asset) {
		const params = asset.params;
		return {
			assetId: BigInt(asset.index),
			total: BigInt(params.total),
			decimals: Number(params.decimals),
			assetName: params.name,
			assetNameAsBytes: params.nameB64,
			unitName: params.unitName,
			unitNameAsBytes: params.unitNameB64,
			url: params.url,
			urlAsBytes: params.urlB64,
			creator: params.creator,
			manager: params.manager,
			clawback: params.clawback,
			freeze: params.freeze,
			reserve: params.reserve,
			defaultFrozen: params.defaultFrozen,
			metadataHash: params.metadataHash
		};
	}
	/**
	* Returns the given sender account's asset holding for a given asset.
	*
	* @example
	* ```typescript
	* const address = "XBYLS2E6YI6XXL5BWCAMOA4GTWHXWENZMX5UHXMRNWWUQ7BXCY5WC5TEPA";
	* const assetId = 123345n;
	* const accountInfo = await assetManager.getAccountInformation(address, assetId);
	* ```
	*
	* [Response data schema details](https://dev.algorand.co/reference/rest-api/algod/operations/accountassetinformation/)
	* @param sender The address of the sender/account to look up
	* @param assetId The ID of the asset to return a holding for
	* @param options Optional `round` to read the holding as of the end of a past round (needs dtalgod time travel)
	* @returns The account asset holding information
	*/
	async getAccountInformation(sender, assetId, options) {
		const round = options?.round;
		const info = round === void 0 ? await this._algod.accountAssetInformation(sender, Number(assetId)).do() : await (await require_dt_support.requireTimeTravel(this._algod, "Reading an account asset holding", round)).accountAssetInformation(sender, assetId).round(round).do();
		return {
			assetId: BigInt(assetId),
			balance: BigInt(info.assetHolding?.amount ?? 0),
			frozen: info.assetHolding?.isFrozen === true,
			round: BigInt(info["round"])
		};
	}
	/**
	* Opt an account in to a list of Algorand Standard Assets.
	*
	* Transactions will be sent in batches of 16 as transaction groups.
	*
	* @param account The account to opt-in
	* @param assetIds The list of asset IDs to opt-in to
	* @param options Any parameters to control the transaction or execution of the transaction
	* @example Example using AlgorandClient
	* ```typescript
	* // Basic example
	* assetManager.bulkOptIn("ACCOUNTADDRESS", [12345n, 67890n])
	* // With configuration
	* assetManager.bulkOptIn("ACCOUNTADDRESS", [12345n, 67890n], { maxFee: (1000).microAlgo(), suppressLog: true })
	* ```
	* @returns An array of records matching asset ID to transaction ID of the opt in
	*/
	async bulkOptIn(account, assetIds, options) {
		const results = [];
		for (const assetGroup of require_util.chunkArray(assetIds, 16)) {
			const composer = this._newGroup();
			for (const assetId of assetGroup) composer.addAssetOptIn({
				...options,
				sender: account,
				assetId: BigInt(assetId)
			});
			const result = await composer.send(options);
			require_config.Config.getLogger(options?.suppressLog).info(`Successfully opted in ${account} for assets ${assetGroup.join(", ")} with transaction IDs ${result.txIds.join(", ")}\n  Grouped under ${result.groupId} in round ${result.confirmations?.[0]?.confirmedRound}.`);
			assetGroup.forEach((assetId, index) => {
				results.push({
					assetId: BigInt(assetId),
					transactionId: result.txIds[index]
				});
			});
		}
		return results;
	}
	/**
	* Opt an account out of a list of Algorand Standard Assets.
	*
	* Transactions will be sent in batches of 16 as transaction groups.
	*
	* @param account The account to opt-in
	* @param assetIds The list of asset IDs to opt-out of
	* @param options Any parameters to control the transaction or execution of the transaction
	* @example Example using AlgorandClient
	* ```typescript
	* // Basic example
	* assetManager.bulkOptOut("ACCOUNTADDRESS", [12345n, 67890n])
	* // With configuration
	* assetManager.bulkOptOut("ACCOUNTADDRESS", [12345n, 67890n], { ensureZeroBalance: true, maxFee: (1000).microAlgo(), suppressLog: true })
	* ```
	* @returns An array of records matching asset ID to transaction ID of the opt in
	*/
	async bulkOptOut(account, assetIds, options) {
		const results = [];
		for (const assetGroup of require_util.chunkArray(assetIds, 16)) {
			const composer = this._newGroup();
			const notOptedInAssetIds = [];
			const nonZeroBalanceAssetIds = [];
			for (const assetId of assetGroup) if (options?.ensureZeroBalance !== false) try {
				if ((await this.getAccountInformation(account, assetId)).balance !== 0n) nonZeroBalanceAssetIds.push(BigInt(assetId));
			} catch {
				notOptedInAssetIds.push(BigInt(assetId));
			}
			if (notOptedInAssetIds.length > 0 || nonZeroBalanceAssetIds.length > 0) throw new Error(`Account ${account}${notOptedInAssetIds.length > 0 ? ` is not opted-in to Asset${notOptedInAssetIds.length > 1 ? "s" : ""} ${notOptedInAssetIds.join(", ")}` : ""}${nonZeroBalanceAssetIds.length > 0 ? ` has non-zero balance for Asset${nonZeroBalanceAssetIds.length > 1 ? "s" : ""} ${nonZeroBalanceAssetIds.join(", ")}` : ""}; can't opt-out.`);
			for (const assetId of assetGroup) composer.addAssetOptOut({
				...options,
				creator: (await this.getById(BigInt(assetId))).creator,
				sender: account,
				assetId: BigInt(assetId)
			});
			const result = await composer.send(options);
			require_config.Config.getLogger(options?.suppressLog).info(`Successfully opted ${account} out of assets ${assetGroup.join(", ")} with transaction IDs ${result.txIds.join(", ")}\n  Grouped under ${result.groupId} in round ${result.confirmations?.[0]?.confirmedRound}.`);
			assetGroup.forEach((assetId, index) => {
				results.push({
					assetId: BigInt(assetId),
					transactionId: result.txIds[index]
				});
			});
		}
		return results;
	}
};
//#endregion
exports.AssetManager = AssetManager;

//# sourceMappingURL=asset-manager.js.map