import { EventDataMap, EventType } from './lifecycle-events';
export type AsyncEventListener<T = unknown> = (event: T, eventName: string | symbol) => Promise<void> | void;
export declare class AsyncEventEmitter {
    private listenerWrapperMap;
    private listenerMap;
    emitAsync<K extends EventType>(eventName: K, event: EventDataMap[K]): Promise<void>;
    emitAsync(eventName: string | symbol, event: unknown): Promise<void>;
    on<K extends EventType>(eventName: K, listener: AsyncEventListener<EventDataMap[K]>): AsyncEventEmitter;
    on<T = unknown>(eventName: string | symbol, listener: AsyncEventListener<T>): AsyncEventEmitter;
    once<K extends EventType>(eventName: K, listener: AsyncEventListener<EventDataMap[K]>): AsyncEventEmitter;
    once<T = unknown>(eventName: string | symbol, listener: AsyncEventListener<T>): AsyncEventEmitter;
    removeListener(eventName: string | symbol, listener: AsyncEventListener): AsyncEventEmitter;
    off: (eventName: string | symbol, listener: AsyncEventListener) => AsyncEventEmitter;
}
