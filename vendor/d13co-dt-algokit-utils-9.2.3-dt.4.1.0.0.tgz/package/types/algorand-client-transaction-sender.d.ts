import algosdk, { Address } from 'algosdk';
import { SendAppCreateTransactionResult, SendAppTransactionResult, SendAppUpdateTransactionResult } from './app';
import { AppManager } from './app-manager';
import { AssetManager } from './asset-manager';
import { AppCreateParams, AppUpdateParams, AssetCreateParams, AssetOptOutParams, TransactionComposer } from './composer';
import { SendParams, SendSingleTransactionResult } from './transaction';
import Transaction = algosdk.Transaction;
/** Orchestrates sending transactions for `AlgorandClient`. */
export declare class AlgorandClientTransactionSender {
    private _newGroup;
    private _assetManager;
    private _appManager;
    /**
     * Creates a new `AlgorandClientSender`
     * @param newGroup A lambda that starts a new `TransactionComposer` transaction group
     * @param assetManager An `AssetManager` instance
     * @param appManager An `AppManager` instance
     * @example
     * ```typescript
     * const transactionSender = new AlgorandClientTransactionSender(() => new TransactionComposer(), assetManager, appManager)
     * ```
     */
    constructor(newGroup: () => TransactionComposer, assetManager: AssetManager, appManager: AppManager);
    /**
     * Start a new `TransactionComposer` transaction group
     * @returns A new instance of `TransactionComposer`.
     * @example
     * const composer = AlgorandClient.mainNet().send.newGroup();
     * const result = await composer.addTransaction(payment).send()
     */
    newGroup(): TransactionComposer;
    private _send;
    private _sendAppCall;
    private _sendAppUpdateCall;
    private _sendAppCreateCall;
    /**
     * Send a payment transaction to transfer Algo between accounts.
     * @param params The parameters for the payment transaction
     * @example Basic example
     * ```typescript
     * const result = await algorand.send.payment({
     *  sender: 'SENDERADDRESS',
     *  receiver: 'RECEIVERADDRESS',
     *  amount: (4).algo(),
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * const result = await algorand.send.payment({
     *   amount: (4).algo(),
     *   receiver: 'RECEIVERADDRESS',
     *   sender: 'SENDERADDRESS',
     *   closeRemainderTo: 'CLOSEREMAINDERTOADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     *   // Signer only needed if you want to provide one,
     *   //  generally you'd register it with AlgorandClient
     *   //  against the sender and not need to pass it in
     *   signer: transactionSigner,
     *   maxRoundsToWaitForConfirmation: 5,
     *   suppressLog: true,
     * })
     * ```
     * @returns The result of the payment transaction and the transaction that was sent
     */
    payment: (params: import("./composer").CommonTransactionParams & {
        receiver: string | Address;
        amount: import("./amount").AlgoAmount;
        closeRemainderTo?: string | Address;
    } & SendParams) => Promise<SendSingleTransactionResult>;
    /**
     * Create a new Algorand Standard Asset.
     *
     * The account that sends this transaction will automatically be
     * opted in to the asset and will hold all units after creation.
     *
     * @param params The parameters for the asset creation transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.send.assetCreate({ sender: "CREATORADDRESS", total: 100n})
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.assetCreate({
     *   sender: 'CREATORADDRESS',
     *   total: 100n,
     *   decimals: 2,
     *   assetName: 'asset',
     *   unitName: 'unit',
     *   url: 'url',
     *   metadataHash: 'metadataHash',
     *   defaultFrozen: false,
     *   manager: 'MANAGERADDRESS',
     *   reserve: 'RESERVEADDRESS',
     *   freeze: 'FREEZEADDRESS',
     *   clawback: 'CLAWBACKADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     *   // Signer only needed if you want to provide one,
     *   //  generally you'd register it with AlgorandClient
     *   //  against the sender and not need to pass it in
     *   signer: transactionSigner,
     *   maxRoundsToWaitForConfirmation: 5,
     *   suppressLog: true,
     * })
     * ```
     * @returns The result of the asset create transaction and the transaction that was sent
     */
    assetCreate: (params: AssetCreateParams & SendParams) => Promise<{
        assetId: bigint;
        groupId: string;
        txIds: string[];
        returns?: import("./app").ABIReturn[] | undefined;
        confirmations: algosdk.modelsv2.PendingTransactionResponse[];
        transactions: Transaction[];
        confirmation: algosdk.modelsv2.PendingTransactionResponse;
        transaction: Transaction;
    }>;
    /**
     * Configure an existing Algorand Standard Asset.
     *
     * **Note:** The manager, reserve, freeze, and clawback addresses
     * are immutably empty if they are not set. If manager is not set then
     * all fields are immutable from that point forward.
     *
     * @param params The parameters for the asset config transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.send.assetConfig({ sender: "MANAGERADDRESS", assetId: 123456n, manager: "MANAGERADDRESS" })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.assetConfig({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   manager: 'MANAGERADDRESS',
     *   reserve: 'RESERVEADDRESS',
     *   freeze: 'FREEZEADDRESS',
     *   clawback: 'CLAWBACKADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     *   // Signer only needed if you want to provide one,
     *   //  generally you'd register it with AlgorandClient
     *   //  against the sender and not need to pass it in
     *   signer: transactionSigner,
     *   maxRoundsToWaitForConfirmation: 5,
     *   suppressLog: true,
     * })
     * ```
     * @returns The result of the asset config transaction and the transaction that was sent
     */
    assetConfig: (params: import("./composer").CommonTransactionParams & {
        assetId: bigint;
        manager: string | Address | undefined;
        reserve?: string | Address;
        freeze?: string | Address;
        clawback?: string | Address;
    } & SendParams) => Promise<SendSingleTransactionResult>;
    /**
     * Freeze or unfreeze an Algorand Standard Asset for an account.
     *
     * @param params The parameters for the asset freeze transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.send.assetFreeze({ sender: "MANAGERADDRESS", assetId: 123456n, account: "ACCOUNTADDRESS", frozen: true })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.assetFreeze({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   account: 'ACCOUNTADDRESS',
     *   frozen: true,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     *   // Signer only needed if you want to provide one,
     *   //  generally you'd register it with AlgorandClient
     *   //  against the sender and not need to pass it in
     *   signer: transactionSigner,
     *   maxRoundsToWaitForConfirmation: 5,
     *   suppressLog: true,
     * })
     * ```
     * @returns The result of the asset freeze transaction and the transaction that was sent
     */
    assetFreeze: (params: import("./composer").CommonTransactionParams & {
        assetId: bigint;
        account: string | Address;
        frozen: boolean;
    } & SendParams) => Promise<SendSingleTransactionResult>;
    /**
     * Destroys an Algorand Standard Asset.
     *
     * Created assets can be destroyed only by the asset manager account.
     * All of the assets must be owned by the creator of the asset before
     * the asset can be deleted.
     *
     * @param params The parameters for the asset destroy transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.send.assetDestroy({ sender: "MANAGERADDRESS", assetId: 123456n })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.assetDestroy({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     *   // Signer only needed if you want to provide one,
     *   //  generally you'd register it with AlgorandClient
     *   //  against the sender and not need to pass it in
     *   signer: transactionSigner,
     *   maxRoundsToWaitForConfirmation: 5,
     *   suppressLog: true,
     * })
     * ```
     * @returns The result of the asset destroy transaction and the transaction that was sent
     */
    assetDestroy: (params: import("./composer").CommonTransactionParams & {
        assetId: bigint;
    } & SendParams) => Promise<SendSingleTransactionResult>;
    /**
     * Transfer an Algorand Standard Asset.
     *
     * @param params The parameters for the asset transfer transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.send.assetTransfer({ sender: "HOLDERADDRESS", assetId: 123456n, amount: 1n, receiver: "RECEIVERADDRESS" })
     * ```
     * @example Advanced example (with clawback)
     * ```typescript
     * await algorand.send.assetTransfer({
     *   sender: 'CLAWBACKADDRESS',
     *   assetId: 123456n,
     *   amount: 1n,
     *   receiver: 'RECEIVERADDRESS',
     *   clawbackTarget: 'HOLDERADDRESS',
     *   // This field needs to be used with caution
     *   closeAssetTo: 'ADDRESSTOCLOSETO'
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     *   // Signer only needed if you want to provide one,
     *   //  generally you'd register it with AlgorandClient
     *   //  against the sender and not need to pass it in
     *   signer: transactionSigner,
     *   maxRoundsToWaitForConfirmation: 5,
     *   suppressLog: true,
     * })
     * ```
     * @returns The result of the asset transfer transaction and the transaction that was sent
     */
    assetTransfer: (params: import("./composer").CommonTransactionParams & {
        assetId: bigint;
        amount: bigint;
        receiver: string | Address;
        clawbackTarget?: string | Address;
        closeAssetTo?: string | Address;
    } & SendParams) => Promise<SendSingleTransactionResult>;
    /**
     * Opt an account into an Algorand Standard Asset.
     *
     * @param params The parameters for the asset opt-in transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.send.assetOptIn({ sender: "SENDERADDRESS", assetId: 123456n })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.assetOptIn({
     *   sender: 'SENDERADDRESS',
     *   assetId: 123456n,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     *   // Signer only needed if you want to provide one,
     *   //  generally you'd register it with AlgorandClient
     *   //  against the sender and not need to pass it in
     *   signer: transactionSigner,
     *   maxRoundsToWaitForConfirmation: 5,
     *   suppressLog: true,
     * })
     * ```
     * @returns The result of the asset opt-in transaction and the transaction that was sent
     */
    assetOptIn: (params: import("./composer").CommonTransactionParams & {
        assetId: bigint;
    } & SendParams) => Promise<SendSingleTransactionResult>;
    /**
     * Opt an account out of an Algorand Standard Asset.
     *
     * *Note:* If the account has a balance of the asset,
     * it will not be able to opt-out unless `ensureZeroBalance`
     * is set to `false` (but then the account will lose the assets).
     *
     * @param params The parameters for the asset opt-out transaction
     *
     * @example Basic example (without creator, will be retrieved from algod)
     * ```typescript
     * await algorand.send.assetOptOut({ sender: "SENDERADDRESS", assetId: 123456n, ensureZeroBalance: true })
     * ```
     * @example Basic example (with creator)
     * ```typescript
     * await algorand.send.assetOptOut({ sender: "SENDERADDRESS", creator: "CREATORADDRESS", assetId: 123456n, ensureZeroBalance: true })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.assetOptOut({
     *   sender: 'SENDERADDRESS',
     *   assetId: 123456n,
     *   creator: 'CREATORADDRESS',
     *   ensureZeroBalance: true,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     *   // Signer only needed if you want to provide one,
     *   //  generally you'd register it with AlgorandClient
     *   //  against the sender and not need to pass it in
     *   signer: transactionSigner,
     *   maxRoundsToWaitForConfirmation: 5,
     *   suppressLog: true,
     * })
     * ```
     * @returns The result of the asset opt-out transaction and the transaction that was sent
     */
    assetOptOut: (params: Omit<AssetOptOutParams, "creator"> & {
        /** Optional asset creator account address; if not specified it will be retrieved from algod */
        creator?: string | Address;
        /** Whether or not to check if the account has a zero balance first or not.
         *
         * If this is set to `true` and the account has an asset balance it will throw an error.
         *
         * If this is set to `false` and the account has an asset balance it will lose those assets to the asset creator.
         */
        ensureZeroBalance: boolean;
    } & SendParams) => Promise<{
        groupId: string;
        txIds: string[];
        returns?: import("./app").ABIReturn[] | undefined;
        confirmations: algosdk.modelsv2.PendingTransactionResponse[];
        transactions: Transaction[];
        confirmation: algosdk.modelsv2.PendingTransactionResponse;
        transaction: Transaction;
    }>;
    /**
     * Create a smart contract.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app creation transaction
     * @example Basic example
     * ```typescript
     * const result = await algorand.send.appCreate({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE' })
     * const createdAppId = result.appId
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.appCreate({
     *  sender: 'CREATORADDRESS',
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  schema: {
     *    globalInts: 1,
     *    globalByteSlices: 2,
     *    localInts: 3,
     *    localByteSlices: 4
     *  },
     *  extraProgramPages: 1,
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     * @returns The result of the app create transaction and the transaction that was sent
     */
    appCreate: (params: {
        sender: string | Address;
        maxFee?: import("./amount").AlgoAmount | undefined;
        note?: (Uint8Array | string) | undefined;
        args?: Uint8Array[] | undefined;
        signer?: (algosdk.TransactionSigner | import("./account").TransactionSignerAccount) | undefined;
        onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
        rejectVersion?: number | undefined;
        lease?: (Uint8Array | string) | undefined;
        rekeyTo?: (string | Address) | undefined;
        staticFee?: import("./amount").AlgoAmount | undefined;
        extraFee?: import("./amount").AlgoAmount | undefined;
        validityWindow?: number | bigint | undefined;
        firstValidRound?: bigint | undefined;
        lastValidRound?: bigint | undefined;
        accountReferences?: (string | Address)[] | undefined;
        appReferences?: bigint[] | undefined;
        assetReferences?: bigint[] | undefined;
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
        accessReferences?: import("./app-manager").ResourceReference[] | undefined;
        approvalProgram: string | Uint8Array;
        clearStateProgram: string | Uint8Array;
        schema?: {
            globalInts: number;
            globalByteSlices: number;
            localInts: number;
            localByteSlices: number;
        } | undefined;
        extraProgramPages?: number | undefined;
    } & SendParams) => Promise<SendAppCreateTransactionResult>;
    /**
     * Update a smart contract.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app update transaction
     * @example Basic example
     * ```typescript
     * await algorand.send.appUpdate({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE' })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.appUpdate({
     *  sender: 'CREATORADDRESS',
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     * @returns The result of the app update transaction and the transaction that was sent
     */
    appUpdate: (params: {
        sender: string | Address;
        signer?: (algosdk.TransactionSigner | import("./account").TransactionSignerAccount) | undefined;
        rekeyTo?: (string | Address) | undefined;
        note?: (Uint8Array | string) | undefined;
        lease?: (Uint8Array | string) | undefined;
        staticFee?: import("./amount").AlgoAmount | undefined;
        extraFee?: import("./amount").AlgoAmount | undefined;
        maxFee?: import("./amount").AlgoAmount | undefined;
        validityWindow?: number | bigint | undefined;
        firstValidRound?: bigint | undefined;
        lastValidRound?: bigint | undefined;
        appId: bigint;
        onComplete?: algosdk.OnApplicationComplete.UpdateApplicationOC | undefined;
        args?: Uint8Array[] | undefined;
        accountReferences?: (string | Address)[] | undefined;
        appReferences?: bigint[] | undefined;
        assetReferences?: bigint[] | undefined;
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
        accessReferences?: import("./app-manager").ResourceReference[] | undefined;
        rejectVersion?: number | undefined;
        approvalProgram: string | Uint8Array;
        clearStateProgram: string | Uint8Array;
    } & SendParams) => Promise<SendAppUpdateTransactionResult>;
    /**
     * Delete a smart contract.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app deletion transaction
     * @example Basic example
     * ```typescript
     * await algorand.send.appDelete({ sender: 'CREATORADDRESS' })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.appDelete({
     *  sender: 'CREATORADDRESS',
     *  onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     * @returns The result of the app delete transaction and the transaction that was sent
     */
    appDelete: (params: import("./composer").CommonTransactionParams & {
        appId: bigint;
        onComplete?: algosdk.OnApplicationComplete;
        args?: Uint8Array[];
        accountReferences?: (string | Address)[];
        appReferences?: bigint[];
        assetReferences?: bigint[];
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[];
        accessReferences?: import("./app-manager").ResourceReference[];
        rejectVersion?: number;
    } & {
        onComplete?: algosdk.OnApplicationComplete.DeleteApplicationOC;
    } & SendParams) => Promise<SendAppTransactionResult>;
    /**
     * Call a smart contract.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app call transaction
     * @example Basic example
     * ```typescript
     * await algorand.send.appCall({ sender: 'CREATORADDRESS' })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.send.appCall({
     *  sender: 'CREATORADDRESS',
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     * @returns The result of the app call transaction and the transaction that was sent
     */
    appCall: (params: import("./composer").CommonTransactionParams & {
        appId: bigint;
        onComplete?: algosdk.OnApplicationComplete;
        args?: Uint8Array[];
        accountReferences?: (string | Address)[];
        appReferences?: bigint[];
        assetReferences?: bigint[];
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[];
        accessReferences?: import("./app-manager").ResourceReference[];
        rejectVersion?: number;
    } & {
        onComplete?: Exclude<algosdk.OnApplicationComplete, algosdk.OnApplicationComplete.UpdateApplicationOC>;
    } & SendParams) => Promise<SendAppTransactionResult>;
    /**
     * Create a smart contract via an ABI method.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app creation transaction
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * const result = await algorand.send.appCreateMethodCall({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE', method: method, args: ["arg1_value"] })
     * const createdAppId = result.appId
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.send.appCreateMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  schema: {
     *    globalInts: 1,
     *    globalByteSlices: 2,
     *    localInts: 3,
     *    localByteSlices: 4
     *  },
     *  extraProgramPages: 1,
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     * @returns The result of the application ABI method create transaction and the transaction that was sent
     */
    appCreateMethodCall: (params: {
        sender: string | Address;
        maxFee?: import("./amount").AlgoAmount | undefined;
        approvalProgram: string | Uint8Array;
        clearStateProgram: string | Uint8Array;
        note?: (Uint8Array | string) | undefined;
        schema?: {
            globalInts: number;
            globalByteSlices: number;
            localInts: number;
            localByteSlices: number;
        } | undefined;
        signer?: (algosdk.TransactionSigner | import("./account").TransactionSignerAccount) | undefined;
        onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
        rejectVersion?: number | undefined;
        lease?: (Uint8Array | string) | undefined;
        rekeyTo?: (string | Address) | undefined;
        staticFee?: import("./amount").AlgoAmount | undefined;
        extraFee?: import("./amount").AlgoAmount | undefined;
        validityWindow?: number | bigint | undefined;
        firstValidRound?: bigint | undefined;
        lastValidRound?: bigint | undefined;
        accountReferences?: (string | Address)[] | undefined;
        appReferences?: bigint[] | undefined;
        assetReferences?: bigint[] | undefined;
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
        accessReferences?: import("./app-manager").ResourceReference[] | undefined;
        extraProgramPages?: number | undefined;
    } & {
        method: algosdk.ABIMethod;
        args?: (algosdk.ABIValue | algosdk.TransactionWithSigner | Transaction | Promise<Transaction> | import("./composer").AppMethodCall<AppCreateParams> | import("./composer").AppMethodCall<AppUpdateParams> | import("./composer").AppMethodCall<import("./composer").AppMethodCallParams> | undefined)[];
    } & SendParams) => Promise<SendAppCreateTransactionResult>;
    /**
     * Update a smart contract via an ABI method.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app update transaction
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.send.appUpdateMethodCall({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.send.appUpdateMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     * @returns The result of the application ABI method update transaction and the transaction that was sent
     */
    appUpdateMethodCall: (params: {
        sender: string | Address;
        maxFee?: import("./amount").AlgoAmount | undefined;
        approvalProgram: string | Uint8Array;
        clearStateProgram: string | Uint8Array;
        note?: (Uint8Array | string) | undefined;
        appId: bigint;
        signer?: (algosdk.TransactionSigner | import("./account").TransactionSignerAccount) | undefined;
        onComplete?: algosdk.OnApplicationComplete.UpdateApplicationOC | undefined;
        rejectVersion?: number | undefined;
        lease?: (Uint8Array | string) | undefined;
        rekeyTo?: (string | Address) | undefined;
        staticFee?: import("./amount").AlgoAmount | undefined;
        extraFee?: import("./amount").AlgoAmount | undefined;
        validityWindow?: number | bigint | undefined;
        firstValidRound?: bigint | undefined;
        lastValidRound?: bigint | undefined;
        accountReferences?: (string | Address)[] | undefined;
        appReferences?: bigint[] | undefined;
        assetReferences?: bigint[] | undefined;
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
        accessReferences?: import("./app-manager").ResourceReference[] | undefined;
    } & {
        method: algosdk.ABIMethod;
        args?: (algosdk.ABIValue | algosdk.TransactionWithSigner | Transaction | Promise<Transaction> | import("./composer").AppMethodCall<AppCreateParams> | import("./composer").AppMethodCall<AppUpdateParams> | import("./composer").AppMethodCall<import("./composer").AppMethodCallParams> | undefined)[];
    } & SendParams) => Promise<SendAppUpdateTransactionResult>;
    /**
     * Delete a smart contract via an ABI method.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app deletion transaction
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.send.appDeleteMethodCall({ sender: 'CREATORADDRESS', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.send.appDeleteMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     * @returns The result of the application ABI method delete transaction and the transaction that was sent
     */
    appDeleteMethodCall: (params: {
        sender: string | Address;
        maxFee?: import("./amount").AlgoAmount | undefined;
        note?: (Uint8Array | string) | undefined;
        appId: bigint;
        signer?: (algosdk.TransactionSigner | import("./account").TransactionSignerAccount) | undefined;
        onComplete?: algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
        rejectVersion?: number | undefined;
        lease?: (Uint8Array | string) | undefined;
        rekeyTo?: (string | Address) | undefined;
        staticFee?: import("./amount").AlgoAmount | undefined;
        extraFee?: import("./amount").AlgoAmount | undefined;
        validityWindow?: number | bigint | undefined;
        firstValidRound?: bigint | undefined;
        lastValidRound?: bigint | undefined;
        accountReferences?: (string | Address)[] | undefined;
        appReferences?: bigint[] | undefined;
        assetReferences?: bigint[] | undefined;
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
        accessReferences?: import("./app-manager").ResourceReference[] | undefined;
    } & {
        method: algosdk.ABIMethod;
        args?: (algosdk.ABIValue | algosdk.TransactionWithSigner | Transaction | Promise<Transaction> | import("./composer").AppMethodCall<AppCreateParams> | import("./composer").AppMethodCall<AppUpdateParams> | import("./composer").AppMethodCall<import("./composer").AppMethodCallParams> | undefined)[];
    } & SendParams) => Promise<SendAppTransactionResult>;
    /**
     * Call a smart contract via an ABI method.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app call transaction
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.send.appCallMethodCall({ sender: 'CREATORADDRESS', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.send.appCallMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     * @returns The result of the application ABI method call transaction and the transaction that was sent
     */
    appCallMethodCall: (params: {
        sender: string | Address;
        maxFee?: import("./amount").AlgoAmount | undefined;
        note?: (Uint8Array | string) | undefined;
        appId: bigint;
        signer?: (algosdk.TransactionSigner | import("./account").TransactionSignerAccount) | undefined;
        onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
        rejectVersion?: number | undefined;
        lease?: (Uint8Array | string) | undefined;
        rekeyTo?: (string | Address) | undefined;
        staticFee?: import("./amount").AlgoAmount | undefined;
        extraFee?: import("./amount").AlgoAmount | undefined;
        validityWindow?: number | bigint | undefined;
        firstValidRound?: bigint | undefined;
        lastValidRound?: bigint | undefined;
        accountReferences?: (string | Address)[] | undefined;
        appReferences?: bigint[] | undefined;
        assetReferences?: bigint[] | undefined;
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
        accessReferences?: import("./app-manager").ResourceReference[] | undefined;
    } & {
        method: algosdk.ABIMethod;
        args?: (algosdk.ABIValue | algosdk.TransactionWithSigner | Transaction | Promise<Transaction> | import("./composer").AppMethodCall<AppCreateParams> | import("./composer").AppMethodCall<AppUpdateParams> | import("./composer").AppMethodCall<import("./composer").AppMethodCallParams> | undefined)[];
    } & SendParams) => Promise<SendAppTransactionResult>;
    /**
     * Register an online key.
     * @param params The parameters for the key registration transaction
     * @example Basic example
     * ```typescript
     * const result = await algorand.send.onlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   voteKey: Uint8Array.from(Buffer.from("voteKeyBase64", 'base64')),
     *   selectionKey: Uint8Array.from(Buffer.from("selectionKeyBase64", 'base64')),
     *   stateProofKey: Uint8Array.from(Buffer.from("stateProofKeyBase64", 'base64')),
     *   voteFirst: 1n,
     *   voteLast: 1000n,
     *   voteKeyDilution: 1n,
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * const result = await algorand.send.onlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   voteKey: Uint8Array.from(Buffer.from("voteKeyBase64", 'base64')),
     *   selectionKey: Uint8Array.from(Buffer.from("selectionKeyBase64", 'base64')),
     *   stateProofKey: Uint8Array.from(Buffer.from("stateProofKeyBase64", 'base64')),
     *   voteFirst: 1n,
     *   voteLast: 1000n,
     *   voteKeyDilution: 1n,
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The result of the online key registration transaction and the transaction that was sent
     */
    onlineKeyRegistration: (params: import("./composer").CommonTransactionParams & {
        voteKey: Uint8Array;
        selectionKey: Uint8Array;
        voteFirst: bigint;
        voteLast: bigint;
        voteKeyDilution: bigint;
        stateProofKey?: Uint8Array;
    } & SendParams) => Promise<SendSingleTransactionResult>;
    /**
     * Register an offline key.
     * @param params The parameters for the key registration transaction
     * @example Basic example
     * ```typescript
     * const result = await algorand.send.offlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * const result = await algorand.send.offlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The result of the offline key registration transaction and the transaction that was sent
     */
    offlineKeyRegistration: (params: import("./composer").CommonTransactionParams & {
        preventAccountFromEverParticipatingAgain?: boolean;
    } & SendParams) => Promise<SendSingleTransactionResult>;
}
