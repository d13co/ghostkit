Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/types/debugging.ts
/** The directory name for AlgoKit project related files */
const ALGOKIT_DIR = ".algokit";
/** The directory name for debug source files */
const SOURCES_DIR = "sources";
/** The file extension for TEAL files */
const TEAL_FILE_EXT = ".teal";
/** The file extension for TEAL source map files */
const TEAL_SOURCEMAP_EXT = ".teal.map";
/** The default maximum search depth for file operations */
const DEFAULT_MAX_SEARCH_DEPTH = 10;
//#endregion
exports.ALGOKIT_DIR = ALGOKIT_DIR;
exports.DEFAULT_MAX_SEARCH_DEPTH = DEFAULT_MAX_SEARCH_DEPTH;
exports.SOURCES_DIR = SOURCES_DIR;
exports.TEAL_FILE_EXT = TEAL_FILE_EXT;
exports.TEAL_SOURCEMAP_EXT = TEAL_SOURCEMAP_EXT;

//# sourceMappingURL=debugging.js.map