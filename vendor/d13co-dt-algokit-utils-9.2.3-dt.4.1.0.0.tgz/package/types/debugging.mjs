//#region src/types/debugging.ts
/** The directory name for AlgoKit project related files */
const ALGOKIT_DIR = ".algokit";
/** The directory name for debug source files */
const SOURCES_DIR = "sources";
/** The file extension for TEAL files */
const TEAL_FILE_EXT = ".teal";
/** The file extension for TEAL source map files */
const TEAL_SOURCEMAP_EXT = ".teal.map";
/** The default maximum search depth for file operations */
const DEFAULT_MAX_SEARCH_DEPTH = 10;
//#endregion
export { ALGOKIT_DIR, DEFAULT_MAX_SEARCH_DEPTH, SOURCES_DIR, TEAL_FILE_EXT, TEAL_SOURCEMAP_EXT };

//# sourceMappingURL=debugging.mjs.map