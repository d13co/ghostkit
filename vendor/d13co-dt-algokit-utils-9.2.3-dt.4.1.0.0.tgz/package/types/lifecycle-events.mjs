//#region src/types/lifecycle-events.ts
let EventType = /* @__PURE__ */ function(EventType) {
	EventType["TxnGroupSimulated"] = "TxnGroupSimulated";
	EventType["AppCompiled"] = "AppCompiled";
	return EventType;
}({});
//#endregion
export { EventType };

//# sourceMappingURL=lifecycle-events.mjs.map