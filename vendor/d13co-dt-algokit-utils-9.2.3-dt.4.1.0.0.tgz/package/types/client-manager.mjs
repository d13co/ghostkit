import { getCapabilities, getDTSdk, requireDTSdk, toDTAlgod } from "./dt-support.mjs";
import { genesisIdIsLocalNet } from "./network-client.mjs";
import { AlgoHttpClientWithRetry } from "./algo-http-client-with-retry.mjs";
import { AppClient } from "./app-client.mjs";
import { AppFactory } from "./app-factory.mjs";
import { TestNetDispenserApiClient } from "./dispenser-client.mjs";
import algosdk from "algosdk";
//#region src/types/client-manager.ts
var Kmd = algosdk.Kmd;
var Indexer = algosdk.Indexer;
/** Exposes access to various API clients. */
var ClientManager = class ClientManager {
	_algod;
	_indexer;
	_kmd;
	_algorand;
	/**
	* algosdk clients or config for interacting with the official Algorand APIs.
	* @param clientsOrConfig The clients or config to use
	* @example Algod client only
	* ```typescript
	* const clientManager = new ClientManager({ algod: algodClient })
	* ```
	* @example All clients
	* ```typescript
	* const clientManager = new ClientManager({ algod: algodClient, indexer: indexerClient, kmd: kmdClient })
	* ```
	* @example Algod config only
	* ```typescript
	* const clientManager = new ClientManager({ algodConfig })
	* ```
	* @example All client configs
	* ```typescript
	* const clientManager = new ClientManager({ algodConfig, indexerConfig, kmdConfig })
	* ```
	*/
	constructor(clientsOrConfig, algorandClient) {
		const _clients = "algod" in clientsOrConfig ? clientsOrConfig : {
			algod: ClientManager.getAlgodClient(clientsOrConfig.algodConfig),
			indexer: clientsOrConfig.indexerConfig ? ClientManager.getIndexerClient(clientsOrConfig.indexerConfig) : void 0,
			kmd: clientsOrConfig.kmdConfig ? ClientManager.getKmdClient(clientsOrConfig.kmdConfig) : void 0
		};
		this._algod = _clients.algod;
		this._indexer = _clients.indexer;
		this._kmd = _clients.kmd;
		this._algorand = algorandClient;
	}
	/**
	* Returns an algosdk Algod API client.
	* @returns The Algod client
	*/
	get algod() {
		return this._algod;
	}
	/**
	* Returns a time-travel algod client (dtalgosdk's `DTAlgodClient`) that shares the connection of `algod`, for reads
	* at past rounds, `/versions` listings, extended simulate and queries on dtalgod.
	* @returns The time-travel algod client
	* @throws DTNotAvailableError if the loaded algosdk is not dtalgosdk
	*/
	get dtAlgod() {
		return toDTAlgod(this._algod, "The time-travel algod client");
	}
	/**
	* Returns whether time travel can be used: the loaded algosdk is dtalgosdk and the algod node is dtalgod with time
	* travel on (`EnableTimeTravel`). It is read from the node's capabilities, asked for once per algod client.
	* @returns Whether time travel is supported
	*/
	async supportsDT() {
		if (!getDTSdk()) return false;
		return await this.dtAlgod.supportsDT();
	}
	/**
	* Returns what the algod node can do, as dtalgod reports it (`GET /v2/capabilities`): whether it is dtalgod at all
	* (`reported`), which optional features it has on (time travel, the developer API, queries), its time limit for
	* expensive requests, and the limits of its simulate and query requests. Stock algod, which has no capabilities
	* endpoint, gets stock algod's values with `reported` false. They are asked for once per algod client.
	*
	* @returns The node's capabilities
	* @throws DTNotAvailableError if the loaded algosdk is not dtalgosdk
	* @example
	* ```typescript
	* const { reported, timeTravel, simulate, query } = await algorand.client.capabilities()
	* ```
	*/
	async capabilities() {
		requireDTSdk("Reading the node capabilities");
		return await getCapabilities(this._algod);
	}
	/**
	* Returns an algosdk Indexer API client or throws an error if it's not been provided.
	* @returns The Indexer client
	* @throws Error if no Indexer client is configured
	*/
	get indexer() {
		if (!this._indexer) throw new Error("Attempt to use Indexer client in AlgoKit instance with no Indexer configured");
		return this._indexer;
	}
	/**
	* Returns an algosdk Indexer API client or `undefined` if it's not been provided.
	* @returns The Indexer client or `undefined`
	*/
	get indexerIfPresent() {
		return this._indexer;
	}
	/**
	* Returns an algosdk KMD API client or throws an error if it's not been provided.
	* @returns The KMD client
	* @throws Error if no KMD client is configured
	*/
	get kmd() {
		if (!this._kmd) throw new Error("Attempt to use Kmd client in AlgoKit instance with no Kmd configured");
		return this._kmd;
	}
	_getNetworkPromise;
	/**
	* Get details about the current network.
	* @example Getting genesis ID
	* ```typescript
	* const network = await networkClient.network()
	* const genesisId = network.genesisId
	* ```
	* @returns The current network details
	*/
	async network() {
		if (!this._getNetworkPromise) this._getNetworkPromise = this._algod.getTransactionParams().do();
		const params = await this._getNetworkPromise;
		return {
			isTestNet: [
				"testnet-v1.0",
				"testnet-v1",
				"testnet"
			].includes(params.genesisID ?? "unknown"),
			isMainNet: [
				"mainnet-v1.0",
				"mainnet-v1",
				"mainnet"
			].includes(params.genesisID ?? "unknown"),
			isLocalNet: ClientManager.genesisIdIsLocalNet(params.genesisID ?? "unknown"),
			genesisId: params.genesisID ?? "unknown",
			genesisHash: params.genesisHash ? Buffer.from(params.genesisHash).toString("base64") : "unknown"
		};
	}
	/**
	* Returns true if the given network genesisId is associated with a LocalNet network.
	* @param genesisId The network genesis ID
	* @returns Whether the given genesis ID is associated with a LocalNet network
	* @example
	* ```typescript
	* const isLocalNet = ClientManager.genesisIdIsLocalNet('testnet-v1.0')
	* ```
	*/
	static genesisIdIsLocalNet(genesisId) {
		return genesisIdIsLocalNet(genesisId);
	}
	/**
	* Returns true if the current network is LocalNet.
	* @returns True if the current network is LocalNet.
	* @example
	* ```typescript
	* const isLocalNet = await clientManager.isLocalNet()
	* ```
	*/
	async isLocalNet() {
		return (await this.network()).isLocalNet;
	}
	/**
	* Returns true if the current network is TestNet.
	* @returns True if the current network is TestNet.
	* @example
	* ```typescript
	* const isTestNet = await clientManager.isTestNet()
	* ```
	*/
	async isTestNet() {
		return (await this.network()).isTestNet;
	}
	/**
	* Returns true if the current network is MainNet.
	* @returns True if the current network is MainNet.
	* @example
	* ```typescript
	* const isMainNet = await clientManager.isMainNet()
	* ```
	*/
	async isMainNet() {
		return (await this.network()).isMainNet;
	}
	/**
	* Returns a TestNet Dispenser API client.
	*
	* Refer to [docs](https://github.com/algorandfoundation/algokit/blob/main/docs/testnet_api.md) on guidance to obtain an access token.
	*
	* @param params An object containing parameters for the TestNetDispenserApiClient class.
	* @example
	* const client = clientManager.getTestNetDispenser(
	*     {
	*       authToken: 'your_auth_token',
	*       requestTimeout: 15,
	*     }
	* )
	*
	* @returns An instance of the TestNetDispenserApiClient class.
	*/
	getTestNetDispenser(params) {
		return new TestNetDispenserApiClient(params);
	}
	/**
	* Returns a TestNet Dispenser API client, loading the auth token from `process.env.ALGOKIT_DISPENSER_ACCESS_TOKEN`.
	*
	* Refer to [docs](https://github.com/algorandfoundation/algokit/blob/main/docs/testnet_api.md) on guidance to obtain an access token.
	*
	* @param params An object containing parameters for the TestNetDispenserApiClient class.
	* @example
	* const client = clientManager.getTestNetDispenserFromEnvironment(
	*     {
	*       requestTimeout: 15,
	*     }
	* )
	*
	* @returns An instance of the TestNetDispenserApiClient class.
	*/
	getTestNetDispenserFromEnvironment(params) {
		return new TestNetDispenserApiClient(params ? {
			...params,
			authToken: ""
		} : void 0);
	}
	/**
	* Returns a new `AppFactory` client
	* @param params The parameters to create the app factory
	* @example Basic example
	* ```typescript
	* const factory = clientManager.getAppFactory({
	*   appSpec: '{/* ARC-56 or ARC-32 compatible JSON *\/}',
	* })
	* ```
	* @example Advanced example
	* ```typescript
	* const factory = clientManager.getAppFactory({
	*   appSpec: parsedAppSpec_AppSpec_or_Arc56Contract,
	*   defaultSender: "SENDERADDRESS",
	*   appName: "OverriddenAppName",
	*   version: "2.0.0",
	*   updatable: true,
	*   deletable: false,
	*   deployTimeParams: { ONE: 1, TWO: 'value' }
	* })
	* ```
	* @returns The `AppFactory` instance
	*/
	getAppFactory(params) {
		if (!this._algorand) throw new Error("Attempt to get app factory from a ClientManager without an Algorand client");
		return new AppFactory({
			...params,
			algorand: this._algorand
		});
	}
	/**
	* Returns a new `AppClient` client for managing calls and state for an ARC-32/ARC-56 app.
	* This method resolves the app ID by looking up the creator address and name
	* using AlgoKit app deployment semantics (i.e. looking for the app creation transaction note).
	* @param params The parameters to create the app client
	* @example Basic
	* ```typescript
	* const appClient = clientManager.getAppClientByCreatorAndName({
	*   appSpec: '{/* ARC-56 or ARC-32 compatible JSON *\}',
	*   // appId resolved by looking for app ID of named app by this creator
	*   creatorAddress: 'CREATORADDRESS',
	* })
	* ```
	* @returns The `AppClient` instance
	*/
	getAppClientByCreatorAndName(params) {
		if (!this._algorand) throw new Error("Attempt to get app client from a ClientManager without an Algorand client");
		return AppClient.fromCreatorAndName({
			...params,
			algorand: this._algorand
		});
	}
	/**
	* Returns a new `AppClient` client for managing calls and state for an ARC-32/ARC-56 app.
	* @param params The parameters to create the app client
	* @example Basic
	* ```typescript
	* const appClient = clientManager.getAppClientById({
	*   appSpec: '{/* ARC-56 or ARC-32 compatible JSON *\}',
	*   appId: 12345n,
	* })
	* ```
	* @returns The `AppClient` instance
	*/
	getAppClientById(params) {
		if (!this._algorand) throw new Error("Attempt to get app client from a ClientManager without an Algorand client");
		return new AppClient({
			...params,
			algorand: this._algorand
		});
	}
	/**
	* Returns a new `AppClient` client for managing calls and state for an ARC-56 app.
	* This method resolves the app ID for the current network based on
	* pre-determined network-specific app IDs specified in the ARC-56 app spec.
	*
	* If no IDs are in the app spec or the network isn't recognised, an error is thrown.
	* @param params The parameters to create the app client
	* @example Basic
	* ```typescript
	* const appClient = clientManager.getAppClientByNetwork({
	*   appSpec: '{/* ARC-56 or ARC-32 compatible JSON *\}',
	*   // appId resolved by using ARC-56 spec to find app ID for current network
	* })
	* ```
	* @returns The `AppClient` instance
	*/
	async getAppClientByNetwork(params) {
		if (!this._algorand) throw new Error("Attempt to get app client from a ClientManager without an Algorand client");
		return AppClient.fromNetwork({
			...params,
			algorand: this._algorand
		});
	}
	/**
	* Returns a new typed client, resolving the app by creator address and name.
	* @param typedClient The typed client type to use
	* @param params The params to resolve the app by creator address and name
	* @example Use name in ARC-32 / ARC-56 app spec
	* ```typescript
	* const appClient = clientManager.getTypedAppClientByCreatorAndName(MyContractClient, {
	*   creatorAddress: "CREATORADDRESS",
	*   defaultSender: alice,
	* })
	* ```
	* @example Specify name
	* ```typescript
	* const appClient = clientManager.getTypedAppClientByCreatorAndName(MyContractClient, {
	*   creatorAddress: "CREATORADDRESS",
	*   name: "contract-name",
	*   defaultSender: alice,
	* })
	* ```
	* @returns The typed client instance
	*/
	async getTypedAppClientByCreatorAndName(typedClient, params) {
		if (!this._algorand) throw new Error("Attempt to get app client from a ClientManager without an Algorand client");
		return typedClient.fromCreatorAndName({
			...params,
			algorand: this._algorand
		});
	}
	/**
	* Returns a new typed client, resolving the app by app ID.
	* @param typedClient The typed client type to use
	* @param params The params to resolve the app by ID
	* @example
	* ```typescript
	* const appClient = clientManager.getTypedAppClientById(MyContractClient, {
	*   appId: 12345n,
	*   defaultSender: alice,
	* })
	* ```
	* @returns The typed client instance
	*/
	getTypedAppClientById(typedClient, params) {
		if (!this._algorand) throw new Error("Attempt to get app client from a ClientManager without an Algorand client");
		return new typedClient({
			...params,
			algorand: this._algorand
		});
	}
	/**
	* Returns a new typed client, resolves the app ID for the current network based on
	* pre-determined network-specific app IDs specified in the ARC-56 app spec.
	*
	* If no IDs are in the app spec or the network isn't recognised, an error is thrown.
	* @param typedClient The typed client type to use
	* @param params The params to resolve the app by network
	* @example
	* ```typescript
	* const appClient = clientManager.getTypedAppClientByNetwork(MyContractClient, {
	*   defaultSender: alice,
	* })
	* ```
	* @returns The typed client instance
	*/
	getTypedAppClientByNetwork(typedClient, params) {
		if (!this._algorand) throw new Error("Attempt to get app client from a ClientManager without an Algorand client");
		return typedClient.fromNetwork({
			...params,
			algorand: this._algorand
		});
	}
	/**
	* Returns a new typed app factory.
	* @param typedFactory The typed factory type to use
	* @param params The params to resolve the factory by
	* @example
	* ```typescript
	* const appFactory = clientManager.getTypedAppFactory(MyContractClient, {
	*   sender: alice,
	* })
	* ```
	* @returns The typed client instance
	*/
	getTypedAppFactory(typedFactory, params) {
		if (!this._algorand) throw new Error("Attempt to get app factory from a ClientManager without an Algorand client");
		return new typedFactory({
			...params,
			algorand: this._algorand
		});
	}
	/**
	* Retrieve client configurations from environment variables when defined or get defaults (expects to be called from a Node.js environment)
	*
	* If both `process.env.INDEXER_SERVER` and `process.env.ALGOD_SERVER` is defined it will use both along with optional `process.env.ALGOD_PORT`, `process.env.ALGOD_TOKEN`, `process.env.INDEXER_PORT` and `process.env.INDEXER_TOKEN`.
	*
	* If only `process.env.ALGOD_SERVER` is defined it will use this along with optional `process.env.ALGOD_PORT` and `process.env.ALGOD_TOKEN` and leave indexer as `undefined`.
	*
	* If only `process.env.INDEXER_SERVER` is defined it will use the default (LocalNet) configuration for both algod and indexer.
	*
	* It will return a KMD configuration that uses `process.env.KMD_PORT` (or port 4002) if `process.env.ALGOD_SERVER` is defined,
	* otherwise it will use the default LocalNet config unless it detects testnet or mainnet.
	* @example
	* ```typescript
	* const config = ClientManager.getConfigFromEnvironmentOrLocalNet()
	* ```
	* @returns The config for algod, indexer and kmd
	*/
	static getConfigFromEnvironmentOrLocalNet() {
		if (!process || !process.env) throw new Error("Attempt to get default client configuration from a non Node.js context; supply the config instead");
		const [algodConfig, indexerConfig, kmdConfig] = process.env.ALGOD_SERVER ? [
			ClientManager.getAlgodConfigFromEnvironment(),
			process.env.INDEXER_SERVER ? ClientManager.getIndexerConfigFromEnvironment() : void 0,
			!process.env.ALGOD_SERVER.includes("mainnet") && !process.env.ALGOD_SERVER.includes("testnet") ? {
				...ClientManager.getAlgodConfigFromEnvironment(),
				port: process?.env?.KMD_PORT ?? "4002"
			} : void 0
		] : [
			ClientManager.getDefaultLocalNetConfig("algod"),
			ClientManager.getDefaultLocalNetConfig("indexer"),
			ClientManager.getDefaultLocalNetConfig("kmd")
		];
		return {
			algodConfig,
			indexerConfig,
			kmdConfig
		};
	}
	/**
	* Retrieve the algod configuration from environment variables (expects to be called from a Node.js environment)
	*
	* Expects `process.env.ALGOD_SERVER` to be defined, and you can also specify `process.env.ALGOD_PORT` and `process.env.ALGOD_TOKEN`.
	* @returns The Algod client configuration
	* @throws Error if `process.env.ALGOD_SERVER` is not defined
	* @example
	* ```typescript
	* const config = ClientManager.getAlgodConfigFromEnvironment()
	* ```
	*/
	static getAlgodConfigFromEnvironment() {
		if (!process || !process.env) throw new Error("Attempt to get default algod configuration from a non Node.js context; supply the config instead");
		if (!process.env.ALGOD_SERVER) throw new Error("Attempt to get default algod configuration without specifying ALGOD_SERVER in the environment variables");
		return {
			server: process.env.ALGOD_SERVER,
			port: process.env.ALGOD_PORT,
			token: process.env.ALGOD_TOKEN
		};
	}
	/**
	* Retrieve the indexer configuration from environment variables (expects to be called from a Node.js environment).
	*
	* Expects `process.env.INDEXER_SERVER` to be defined, and you can also specify `process.env.INDEXER_PORT` and `process.env.INDEXER_TOKEN`.
	* @returns The Indexer client configuration
	* @throws Error if `process.env.INDEXER_SERVER` is not defined
	* @example
	* ```typescript
	* const config = ClientManager.getIndexerConfigFromEnvironment()
	* ```
	*/
	static getIndexerConfigFromEnvironment() {
		if (!process || !process.env) throw new Error("Attempt to get default indexer configuration from a non Node.js context; supply the config instead");
		if (!process.env.INDEXER_SERVER) throw new Error("Attempt to get default indexer configuration without specifying INDEXER_SERVER in the environment variables");
		return {
			server: process.env.INDEXER_SERVER,
			port: process.env.INDEXER_PORT,
			token: process.env.INDEXER_TOKEN
		};
	}
	/** Returns the Algorand configuration to point to the free tier of the AlgoNode service.
	*
	* @param network Which network to connect to - TestNet or MainNet
	* @param config Which algod config to return - Algod or Indexer
	* @returns The AlgoNode client configuration
	* @example
	* ```typescript
	* const config = ClientManager.getAlgoNodeConfig('testnet', 'algod')
	* ```
	*/
	static getAlgoNodeConfig(network, config) {
		return {
			server: `https://${network}-${config === "algod" ? "api" : "idx"}.algonode.cloud/`,
			port: 443
		};
	}
	/** Returns the Algorand configuration to point to the default LocalNet.
	*
	* @param configOrPort Which algod config to return - algod, kmd, or indexer OR a port number
	* @returns The LocalNet client configuration
	* @example
	* ```typescript
	* const config = ClientManager.getDefaultLocalNetConfig('algod')
	* ```
	*/
	static getDefaultLocalNetConfig(configOrPort) {
		return {
			server: `http://localhost`,
			port: configOrPort === "algod" ? 4001 : configOrPort === "indexer" ? 8980 : configOrPort === "kmd" ? 4002 : configOrPort,
			token: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
		};
	}
	/**
	* Returns an algod SDK client that automatically retries on idempotent calls.
	*
	* @param config The config of the client
	* @returns The Algod client
	* @example AlgoNode (testnet)
	* ```typescript
	*  const algod = ClientManager.getAlgodClient(ClientManager.getAlgoNodeConfig('testnet', 'algod'))
	*  await algod.healthCheck().do()
	* ```
	* @example AlgoNode (mainnet)
	* ```typescript
	*  const algod = ClientManager.getAlgodClient(ClientManager.getAlgoNodeConfig('mainnet', 'algod'))
	*  await algod.healthCheck().do()
	* ```
	* @example Custom (e.g. default LocalNet)
	* ```typescript
	*  const algod = ClientManager.getAlgodClient({server: 'http://localhost', port: '4001', token: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'})
	*  await algod.healthCheck().do()
	* ```
	*/
	static getAlgodClient(config) {
		const { token, server, port } = config;
		const httpClientWithRetry = new AlgoHttpClientWithRetry(typeof token === "string" ? { "X-Algo-API-Token": token } : token ?? {}, server, port);
		return new algosdk.Algodv2(httpClientWithRetry, server);
	}
	/**
	* Returns an algod SDK client that automatically retries on idempotent calls loaded from environment variables (expects to be called from a Node.js environment).
	*
	* @returns The Algod client
	* @example
	*  ```typescript
	*  // Uses process.env.ALGOD_SERVER, process.env.ALGOD_PORT and process.env.ALGOD_TOKEN
	*  const algod = ClientManager.getAlgodClientFromEnvironment()
	*  await algod.healthCheck().do()
	*  ```
	*/
	static getAlgodClientFromEnvironment() {
		return ClientManager.getAlgodClient(ClientManager.getAlgodConfigFromEnvironment());
	}
	/**
	* Returns an indexer SDK client that automatically retries on idempotent calls
	*
	* @param config The config of the client
	* @returns The Indexer client
	* @example AlgoNode (testnet)
	* ```typescript
	*  const indexer = ClientManager.getIndexerClient(ClientManager.getAlgoNodeConfig('testnet', 'indexer'))
	*  await indexer.makeHealthCheck().do()
	* ```
	* @example AlgoNode (mainnet)
	* ```typescript
	*  const indexer = ClientManager.getIndexerClient(ClientManager.getAlgoNodeConfig('mainnet', 'indexer'))
	*  await indexer.makeHealthCheck().do()
	* ```
	* @example Custom (e.g. default LocalNet, although we recommend loading this into a .env and using the Default option instead)
	* ```typescript
	*  const indexer = ClientManager.getIndexerClient({server: 'http://localhost', port: '8980', token: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'})
	*  await indexer.makeHealthCheck().do()
	* ```
	*/
	static getIndexerClient(config) {
		const { token, server, port } = config;
		return new Indexer(new AlgoHttpClientWithRetry(typeof token === "string" ? { "X-Indexer-API-Token": token } : token ?? {}, server, port));
	}
	/**
	* Returns an indexer SDK client that automatically retries on idempotent calls loaded from environment variables (expects to be called from a Node.js environment).
	*
	* @returns The Indexer client
	* @example
	*
	*  ```typescript
	*  // Uses process.env.INDEXER_SERVER, process.env.INDEXER_PORT and process.env.INDEXER_TOKEN
	*  const indexer = ClientManager.getIndexerClientFromEnvironment()
	*  await indexer.makeHealthCheck().do()
	*  ```
	*/
	static getIndexerClientFromEnvironment() {
		return ClientManager.getIndexerClient(ClientManager.getIndexerConfigFromEnvironment());
	}
	/**
	* Returns a KMD SDK client.
	*
	* KMD client allows you to export private keys, which is useful to (for instance) get the default account in a LocalNet network.
	*
	* @param config The config for the client
	* @returns The KMD client
	* @example Custom (e.g. default LocalNet, although we recommend loading this into a .env and using the Default option instead)
	* ```typescript
	*  const kmd = ClientManager.getKmdClient({server: 'http://localhost', port: '4002', token: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'})
	* ```
	*/
	static getKmdClient(config) {
		const { token, server, port } = config;
		return new Kmd(token, server, port);
	}
	/**
	* Returns a KMD SDK client that automatically retries on idempotent calls loaded from environment variables (expects to be called from a Node.js environment).
	*
	* @returns The KMD client
	* @example
	*  ```typescript
	*  // Uses process.env.ALGOD_SERVER, process.env.KMD_PORT (or if not specified: port 4002) and process.env.ALGOD_TOKEN
	*  const kmd = ClientManager.getKmdClientFromEnvironment()
	*  ```
	*/
	static getKmdClientFromEnvironment() {
		return ClientManager.getKmdClient({
			...ClientManager.getAlgodConfigFromEnvironment(),
			port: process?.env?.KMD_PORT ?? "4002"
		});
	}
};
//#endregion
export { ClientManager };

//# sourceMappingURL=client-manager.mjs.map