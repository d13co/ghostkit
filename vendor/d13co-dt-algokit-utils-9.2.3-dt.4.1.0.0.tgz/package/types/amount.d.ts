/** Wrapper class to ensure safe, explicit conversion between µAlgo, Algo and numbers */
export declare class AlgoAmount {
    private amountInMicroAlgo;
    /** Return the amount as a number in µAlgo */
    get microAlgos(): bigint;
    /** Return the amount as a number in µAlgo */
    get microAlgo(): bigint;
    /** Return the amount as a number in Algo */
    get algos(): number;
    /** Return the amount as a number in Algo */
    get algo(): number;
    /**
     * Create a new `AlgoAmount` instance.
     *
     * @param amount - An object specifying the amount in Algo or µALGO. Use the key 'algo' for Algo amounts and 'microAlgo' for µALGO.
     * @returns A new instance of `AlgoAmount` representing the specified amount.
     * @example
     * ```typescript
     * const amount = new AlgoAmount({ algo: 5 });
     * ```
     */
    constructor(amount: {
        algos: number | bigint;
    } | {
        algo: number | bigint;
    } | {
        microAlgos: number | bigint;
    } | {
        microAlgo: number | bigint;
    });
    toString(): string;
    /** valueOf allows you to use `AlgoAmount` in comparison operations such as `<` and `>=` etc.,
     * but it's not recommended to use this to convert to a number, it's much safer to explicitly call
     * the algos or microAlgos properties
     */
    valueOf(): number;
    /** Create a `AlgoAmount` object representing the given number of Algo */
    static Algos(amount: number | bigint): AlgoAmount;
    /** Create a `AlgoAmount` object representing the given number of Algo */
    static Algo(amount: number | bigint): AlgoAmount;
    /** Create a `AlgoAmount` object representing the given number of µAlgo */
    static MicroAlgos(amount: number | bigint): AlgoAmount;
    /** Create a `AlgoAmount` object representing the given number of µAlgo */
    static MicroAlgo(amount: number | bigint): AlgoAmount;
}
