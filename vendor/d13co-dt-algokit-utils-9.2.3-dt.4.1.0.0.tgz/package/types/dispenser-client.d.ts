import { Address } from 'algosdk';
/** The TestNet Dispenser API response when funding. */
export interface DispenserFundResponse {
    /** The ID of the transaction that was issued to fund the account. */
    txId: string;
    /** The number of µAlgo that was funded. */
    amount: number;
}
/** The TestNet Dispenser API response when getting the current limit.  */
export interface DispenserLimitResponse {
    /** The limit, in µAlgo, that you can currently fund. */
    amount: number;
}
/** The parameters to construct a TestNet Dispenser API client. */
export interface TestNetDispenserApiClientParams {
    /** The API auth token */
    authToken: string;
    /** The request timeout in seconds */
    requestTimeout?: number;
}
/**
 * `TestNetDispenserApiClient` is a class that provides methods to interact with the [Algorand TestNet Dispenser API](https://github.com/algorandfoundation/algokit/blob/main/docs/testnet_api.md).
 * It allows you to fund an address with Algo, refund a transaction, and get the funding limit for the Algo asset.
 *
 * The class requires an authentication token and a request timeout to be initialized. The authentication token can be provided
 * either directly as a parameter or through an `ALGOKIT_DISPENSER_ACCESS_TOKEN` environment variable. If neither is provided, an error is thrown.
 *
 * The request timeout can be provided as a parameter. If not provided, a default value is used.
 *
 * @property {string} authToken - The authentication token used for API requests.
 * @property {number} requestTimeout - The timeout for API requests, in seconds.
 *
 * @method fund - Sends a funding request to the dispenser API to fund the specified address with the given amount of Algo.
 * @method refund - Sends a refund request to the dispenser API for the specified refundTxnId.
 * @method limit - Sends a request to the dispenser API to get the funding limit for the Algo asset.
 *
 * @example
 * ```typescript
 * const client = new TestNetDispenserApiClient({ authToken: 'your_auth_token', requestTimeout: 30 });
 * const fundResponse = await client.fund('your_address', 100);
 * const limitResponse = await client.getLimit();
 * await client.refund('your_transaction_id');
 * ```
 *
 * @throws {Error} If neither the environment variable 'ALGOKIT_DISPENSER_ACCESS_TOKEN' nor the authToken parameter were provided.
 */
export declare class TestNetDispenserApiClient {
    private _authToken;
    private _requestTimeout;
    constructor(params?: TestNetDispenserApiClientParams);
    get authToken(): string;
    get requestTimeout(): number;
    /**
     * Processes a dispenser API request.
     *
     * @param authToken - The authentication token.
     * @param urlSuffix - The URL suffix for the API request.
     * @param body - The request body.
     * @param method - The HTTP method.
     *
     * @returns The API response.
     */
    private processDispenserRequest;
    /**
     * Sends a funding request to the dispenser API to fund the specified address with the given amount of Algo.
     *
     * @param address - The address to fund.
     * @param amount - The amount of µAlgo to fund.
     *
     * @returns DispenserFundResponse: An object containing the transaction ID and funded amount.
     */
    fund(address: string | Address, amount: number | bigint): Promise<DispenserFundResponse>;
    /**
     * Sends a refund request to the dispenser API for the specified refundTxnId.
     *
     * @param refundTxnId - The transaction ID to refund.
     */
    refund(refundTxnId: string): Promise<void>;
    /**
     * Sends a request to the dispenser API to get the funding limit for the Algo asset.
     *
     * @returns DispenserLimitResponse: An object containing the funding limit amount.
     */
    getLimit(): Promise<DispenserLimitResponse>;
}
