import { BaseHTTPClientResponse, Query, URLTokenBaseHTTPClient } from 'algosdk/client';
/**
 * A HTTP Client that wraps the Algorand SDK HTTP Client with retries.
 *
 * A 429 or 503 with a `Retry-After` header waits at least that long before the next try (capped at 10 s). A dtalgod 503
 * for a busy node ("node is busy", or no slot free to re-evaluate an old round's deltas) without a readable header (a
 * proxy may drop it) waits at least 1 s. A 503 for history
 * the node can't serve (an incomplete box or holders index, an untrusted history) is not retried: it lasts until the node
 * is fixed. A 504 (the node's time limit) is not retried from `POST /v2/query` or from `GET` of `/versions` and `/holders`
 * listings: a retry repeats the whole work, and the caller narrows the request instead.
 */
export declare class AlgoHttpClientWithRetry extends URLTokenBaseHTTPClient {
    private static readonly MAX_TRIES;
    private static readonly MAX_BACKOFF_MS;
    private static readonly RETRY_STATUS_CODES;
    /**
     * The status codes retried for requests with a time limit on the node (`POST /v2/query`, `GET` of `/versions` and
     * `/holders` listings): all but 504, which is that limit. A retry would repeat the whole (up to the limit) work; the
     * caller splits or narrows the request instead.
     */
    private static readonly TIME_LIMITED_RETRY_STATUS_CODES;
    /**
     * dtalgod's 503s when it has no capacity left for a request (simulate, query, versions), or no slot to re-evaluate an
     * old round's deltas: worth a retry, but not at once.
     */
    private static readonly BUSY;
    /** The least wait before retrying a busy node that gave no readable `Retry-After`. */
    private static readonly BUSY_MIN_BACKOFF_MS;
    /**
     * dtalgod's 503s for history it can't serve until an operator fixes the node: an incomplete box or holders index, or
     * a time-travel history marked as differing from the chain. Retrying them only delays the error.
     */
    private static readonly HISTORY_UNAVAILABLE;
    /** The status codes whose `Retry-After` header is honored. */
    private static readonly RETRY_AFTER_STATUS_CODES;
    private static readonly RETRY_ERROR_CODES;
    /** The abort signal in fetch options passed as `customOptions`, if any. */
    private static signalOf;
    /** Waits `ms`, rejecting with the signal's reason as soon as it aborts. */
    private static sleep;
    /**
     * How long a failed response asks to wait before retrying, from its `Retry-After` header (seconds or an HTTP date),
     * or undefined without one. Only for 429 and 503. The header name is looked up case-insensitively.
     */
    private static retryAfterMs;
    /** The HTTP status of a failed request, or NaN. */
    private static statusOf;
    /** The error's message, and the `message` of its JSON body if it has one (algosdk puts it in the message, other clients may not). */
    private static messageOf;
    /** The status codes to retry for a `method` request to `relativePath`. */
    private static retryStatusCodes;
    private callWithRetry;
    get(relativePath: string, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
    post(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
    delete(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
}
