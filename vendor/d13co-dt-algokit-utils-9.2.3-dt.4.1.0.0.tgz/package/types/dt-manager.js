Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_dt_support = require("./dt-support.js");
const require_app_manager = require("./app-manager.js");
const require_asset_manager = require("./asset-manager.js");
const require_account_manager = require("./account-manager.js");
let buffer = require("buffer");
//#region src/types/dt-manager.ts
/**
* The most rounds an iterator sends in one `rounds` request, by default: about 4.5 KB of URL for 8-digit rounds, under
* the 8 KB request line many proxies allow.
*/
const DEFAULT_MAX_VERSIONS_ROUNDS_PER_REQUEST = 500;
const mapAssetHolder = (h) => ({
	address: h.address,
	amount: h.amount,
	frozen: h.isFrozen
});
const boxName = (name) => ({
	nameRaw: name,
	nameBase64: buffer.Buffer.from(name).toString("base64"),
	name: buffer.Buffer.from(name).toString("utf-8")
});
const boxNameBytes = (name) => require_app_manager.AppManager.getBoxReference(typeof name === "object" && "nameRaw" in name ? name.nameRaw : name).name;
const mapBoxVersion = (v) => ({
	round: v.round,
	timestamp: v.timestamp,
	deleted: v.deleted,
	value: v.value,
	changedRound: v.changedRound
});
const mapBoxesVersion = (v) => ({
	round: v.round,
	timestamp: v.timestamp,
	boxes: v.boxes.map((b) => ({
		name: boxName(b.name),
		deleted: b.deleted,
		value: b.value,
		changedRound: b.changedRound
	}))
});
/** The bytes of a `key` or `prefix` option, checked against the node's 64-byte limit. */
const filterBytes = (what, value) => {
	const bytes = typeof value === "string" ? new Uint8Array(buffer.Buffer.from(value, "utf-8")) : value;
	if (bytes.length > MAX_FILTER_BYTES) throw new Error(`${what} is ${bytes.length} bytes, longer than the ${MAX_FILTER_BYTES} the node allows`);
	return bytes;
};
const MAX_FILTER_BYTES = 64;
/** A `keyValue` decoded as {@link AppManager.decodeAppState} decodes state. */
const decodeKeyValue = (key, value) => key === void 0 || value === void 0 ? void 0 : Object.values(require_app_manager.AppManager.decodeAppState([{
	key: filterBytes("key", key),
	value
}]))[0];
const mapAppVersion = (v, key) => ({
	round: v.round,
	timestamp: v.timestamp,
	deleted: v.deleted,
	app: v.application?.params ? require_app_manager.AppManager.appInformationFromAlgod(v.application) : void 0,
	changedRound: v.changedRound,
	changedKeys: v.changedKeys,
	keyValue: decodeKeyValue(key, v.keyValue)
});
const mapAssetVersion = (v) => ({
	round: v.round,
	timestamp: v.timestamp,
	deleted: v.deleted,
	asset: v.asset?.params ? require_asset_manager.AssetManager.assetInformationFromAlgod(v.asset) : void 0,
	changedRound: v.changedRound
});
const mapAccountVersion = (v, key) => ({
	round: v.round,
	timestamp: v.timestamp,
	base: v.base && {
		deleted: v.base.deleted,
		account: v.base.account ? require_account_manager.accountInformationFromAlgod(v.base.account) : void 0,
		changedRound: v.base.changedRound
	},
	assets: v.assets?.map((a) => ({
		assetId: a.assetId,
		deleted: a.deleted,
		holding: a.assetHolding ? {
			balance: BigInt(a.assetHolding.amount),
			frozen: a.assetHolding.isFrozen
		} : void 0,
		changedRound: a.changedRound
	})),
	appsLocalState: v.appsLocalState?.map((a) => ({
		appId: a.appId,
		deleted: a.deleted,
		state: a.appLocalState ? require_app_manager.AppManager.decodeAppState(a.appLocalState.keyValue ?? []) : void 0,
		changedRound: a.changedRound,
		changedKeys: a.changedKeys,
		keyValue: decodeKeyValue(key, a.keyValue)
	})),
	createdAssets: v.createdAssets?.map((a) => ({
		assetId: a.assetId,
		deleted: a.deleted,
		asset: a.asset?.params ? require_asset_manager.AssetManager.assetInformationFromAlgod(a.asset) : void 0,
		changedRound: a.changedRound
	})),
	createdApps: v.createdApps?.map((a) => ({
		appId: a.appId,
		deleted: a.deleted,
		app: a.application?.params ? require_app_manager.AppManager.appInformationFromAlgod(a.application) : void 0,
		changedRound: a.changedRound,
		changedKeys: a.changedKeys
	}))
});
/** The distinct rounds of `rounds`, in `order`. */
const sortedRounds = (rounds, order) => {
	return [...new Set(rounds.map((r) => BigInt(r)))].sort((a, b) => a === b ? 0 : a < b === (order !== "desc") ? -1 : 1);
};
/**
* Time travel on a time-travel algod (dtalgod with `EnableTimeTravel`): the rounds at which boxes, apps, assets and
* accounts changed, with their values.
*
* Needs dtalgosdk (the time-travel fork of algosdk); without it every method throws a `DTNotAvailableError`. A node
* without time travel (stock algod, or dtalgod with `EnableTimeTravel` off) throws dtalgosdk's `DTUnsupportedError`
* before any request is sent; whether the node has time travel is read once per algod client, from its capabilities.
*
* To read state at a past round, pass `{ round }` to the usual reads (`algorand.app.getGlobalState(appId, { round })`,
* `algorand.account.getInformation(address, { round })`, ...) or use `appClient.atRound(round)`.
*/
var DTManager = class {
	_clientManager;
	/**
	* Create a new time travel manager.
	* @param clientManager The `ClientManager` client to use for algod
	*/
	constructor(clientManager) {
		this._clientManager = clientManager;
	}
	get algod() {
		return this._clientManager.dtAlgod;
	}
	/**
	* Returns whether time travel can be used: the loaded algosdk is dtalgosdk and the node is dtalgod with time travel
	* on (`EnableTimeTravel`). It is read from the node's capabilities, asked for once per algod client.
	* @returns Whether time travel is supported
	* @example
	* ```typescript
	* if (await algorand.dt.supported()) { ... }
	* ```
	*/
	async supported() {
		return await this._clientManager.supportsDT();
	}
	/**
	* Returns a page of the versions of a box: the rounds at which it changed.
	* @param appId The ID of the app
	* @param name The name of the box
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getBoxVersions(appId, 'counter', { order: 'desc', limit: 10, includeValues: true })
	* ```
	*/
	async getBoxVersions(appId, name, options) {
		return await this.page(this.algod.getApplicationBoxVersions(appId, boxNameBytes(name)), options, mapBoxVersion);
	}
	/**
	* Iterates over the versions of a box, following the pages.
	* @param appId The ID of the app
	* @param name The name of the box
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateBoxVersions(appId, 'counter', { includeValues: true })) { ... }
	* ```
	*/
	iterateBoxVersions(appId, name, options) {
		return this.iterate(() => this.algod.getApplicationBoxVersions(appId, boxNameBytes(name)), options, mapBoxVersion);
	}
	/**
	* Returns a page of an app's box change feed: the rounds at which any of its boxes changed, with the boxes that
	* changed in each.
	* @param appId The ID of the app
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getBoxesVersions(appId, { minRound: 45_000_000n })
	* ```
	*/
	async getBoxesVersions(appId, options) {
		return await this.page(this.algod.getApplicationBoxesVersions(appId), options, mapBoxesVersion, () => this.prefixFilter(options));
	}
	/**
	* Iterates over an app's box change feed, following the pages.
	* @param appId The ID of the app
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const { round, boxes } of algorand.dt.iterateBoxesVersions(appId)) { ... }
	* ```
	*/
	iterateBoxesVersions(appId, options) {
		return this.iterate(() => this.algod.getApplicationBoxesVersions(appId), options, mapBoxesVersion, () => this.prefixFilter(options));
	}
	/**
	* Returns a page of the versions of an app (its params and global state).
	* @param appId The ID of the app
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAppVersions(appId, { includeValues: true })
	* const counters = versions.map((v) => v.app?.globalState.counter?.value)
	* ```
	*/
	async getAppVersions(appId, options) {
		return await this.page(this.algod.getApplicationVersions(appId), options, (v) => mapAppVersion(v, options?.key), () => this.keyFilter(options));
	}
	/**
	* Iterates over the versions of an app (its params and global state), following the pages.
	* @param appId The ID of the app
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAppVersions(appId, { includeValues: true })) { ... }
	* ```
	*/
	iterateAppVersions(appId, options) {
		return this.iterate(() => this.algod.getApplicationVersions(appId), options, (v) => mapAppVersion(v, options?.key), () => this.keyFilter(options));
	}
	/**
	* Returns a page of the versions of an asset (its params).
	* @param assetId The ID of the asset
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAssetVersions(assetId, { includeValues: true })
	* ```
	*/
	async getAssetVersions(assetId, options) {
		return await this.page(this.algod.getAssetVersions(assetId), options, mapAssetVersion);
	}
	/**
	* Iterates over the versions of an asset (its params), following the pages.
	* @param assetId The ID of the asset
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAssetVersions(assetId)) { ... }
	* ```
	*/
	iterateAssetVersions(assetId, options) {
		return this.iterate(() => this.algod.getAssetVersions(assetId), options, mapAssetVersion);
	}
	/**
	* Returns a page of the versions of an account: its base record, holdings, local states and created assets and apps.
	* @param address The address of the account
	* @param options The range, order, page size, whether to include values, what to exclude and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAccountVersions(address, { exclude: ['all'], includeValues: true })
	* const balances = versions.map((v) => v.base?.account?.balance)
	* ```
	*/
	async getAccountVersions(address, options) {
		return await this.page(this.accountVersionsRequest(address, options), options, mapAccountVersion);
	}
	/**
	* Iterates over the versions of an account, following the pages.
	* @param address The address of the account
	* @param options The range, order, page size, whether to include values and what to exclude
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAccountVersions(address, { exclude: ['all'] })) { ... }
	* ```
	*/
	iterateAccountVersions(address, options) {
		return this.iterate(() => this.accountVersionsRequest(address, options), options, mapAccountVersion);
	}
	/**
	* Returns a page of the versions of an account's holding of one asset.
	* @param address The address of the account
	* @param assetId The ID of the asset
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAccountAssetVersions(address, assetId, { includeValues: true })
	* ```
	*/
	async getAccountAssetVersions(address, assetId, options) {
		return await this.page(this.algod.accountAssetVersions(address, assetId), options, mapAccountVersion);
	}
	/**
	* Iterates over the versions of an account's holding of one asset, following the pages.
	* @param address The address of the account
	* @param assetId The ID of the asset
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAccountAssetVersions(address, assetId)) { ... }
	* ```
	*/
	iterateAccountAssetVersions(address, assetId, options) {
		return this.iterate(() => this.algod.accountAssetVersions(address, assetId), options, mapAccountVersion);
	}
	/**
	* Returns a page of the versions of an account's local state in one app (and of the app, if the account created it).
	* @param address The address of the account
	* @param appId The ID of the app
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAccountAppVersions(address, appId, { includeValues: true })
	* ```
	*/
	async getAccountAppVersions(address, appId, options) {
		return await this.page(this.algod.accountApplicationVersions(address, appId), options, (v) => mapAccountVersion(v, options?.key), () => this.keyFilter(options));
	}
	/**
	* Iterates over the versions of an account's local state in one app, following the pages.
	* @param address The address of the account
	* @param appId The ID of the app
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAccountAppVersions(address, appId)) { ... }
	* ```
	*/
	iterateAccountAppVersions(address, appId, options) {
		return this.iterate(() => this.algod.accountApplicationVersions(address, appId), options, (v) => mapAccountVersion(v, options?.key), () => this.keyFilter(options));
	}
	accountVersionsRequest(address, options) {
		const request = this.algod.accountVersions(address);
		if (options?.exclude?.length) request.exclude(...options.exclude);
		return request;
	}
	/** Checks the options before anything is sent. */
	check(options) {
		if (options?.rounds && (options.minRound !== void 0 || options.maxRound !== void 0)) throw new Error("rounds cannot be combined with minRound or maxRound");
		const max = options?.maxRoundsPerRequest;
		if (max !== void 0 && !(Number.isInteger(max) && max > 0)) throw new Error(`maxRoundsPerRequest must be a positive integer, not ${max}`);
	}
	configure(request, options, rounds) {
		if (options?.minRound !== void 0) request.minRound(options.minRound);
		if (options?.maxRound !== void 0) request.maxRound(options.maxRound);
		if (rounds !== void 0) request.rounds(rounds);
		if (options?.order !== void 0) request.order(options.order);
		if (options?.limit !== void 0) request.limit(options.limit);
		const include = [...options?.includeValues ? ["values"] : [], ...options?.includeKeys ? ["keys"] : []];
		if (include.length) request.include(...include);
		return request;
	}
	async page(request, options, map, filter) {
		this.check(options);
		const apply = filter?.();
		await this.requireTimeTravel("Listing versions");
		const configured = this.configure(request, options, options?.rounds);
		apply?.(configured);
		if (options?.next) configured.next(options.next);
		const page = await configured.do(void 0, require_dt_support.fetchOptions(options));
		return {
			round: page.round,
			versions: page.versions.map(map),
			nextToken: page.nextToken || void 0
		};
	}
	async *iterate(request, options, map, filter) {
		const signal = options?.signal;
		signal?.throwIfAborted();
		this.check(options);
		const apply = filter?.();
		await this.requireTimeTravel("Listing versions");
		for (const rounds of this.roundsChunks(options)) {
			const configured = this.configure(request(), options, rounds);
			apply?.(configured);
			for await (const entry of configured.iterate(void 0, require_dt_support.fetchOptions(options))) {
				yield map(entry);
				signal?.throwIfAborted();
			}
		}
	}
	/**
	* Returns a page of the accounts that hold an asset at a round, in address order. Needs dtalgod with time travel and
	* the asset holders index (`TimeTravelHoldersIndex`); otherwise dtalgosdk's `DTUnsupportedError`. An index still being
	* built is a 503 that is thrown at once (not retried). For every holder, prefer {@link iterateAssetHolders}.
	* @param assetId The ID of the asset
	* @param options The round, the page size, the `next` token (with the first page's `round`) and an abort signal
	* @returns The page of holders
	* @example
	* ```typescript
	* const first = await algorand.dt.getAssetHolders(assetId, { limit: 100 })
	* const second = first.nextToken
	*   ? await algorand.dt.getAssetHolders(assetId, { round: first.round, next: first.nextToken, limit: 100 })
	*   : undefined
	* ```
	*/
	async getAssetHolders(assetId, options) {
		if (options?.next !== void 0 && options.round === void 0) throw new Error("Pass the first page's round with next, so every page of the holders lists the same round");
		await this.requireTimeTravel("Listing asset holders");
		const page = await this.holdersRequest(assetId, options).next(options?.next).do(void 0, require_dt_support.fetchOptions(options));
		return {
			round: page.round,
			holders: page.holders.map(mapAssetHolder),
			nextToken: page.nextToken || void 0
		};
	}
	/**
	* Iterates over the accounts that hold an asset at a round, in address order, following the pages, which all list the
	* first page's round.
	* @param assetId The ID of the asset
	* @param options The round, the page size and an abort signal
	* @returns The holders
	* @example
	* ```typescript
	* let held = 0n
	* for await (const h of algorand.dt.iterateAssetHolders(assetId, { round: 50_000_000n })) held += h.amount
	* ```
	*/
	async *iterateAssetHolders(assetId, options) {
		const signal = options?.signal;
		signal?.throwIfAborted();
		await this.requireTimeTravel("Listing asset holders");
		for await (const holder of this.holdersRequest(assetId, options).iterate(void 0, require_dt_support.fetchOptions(options))) {
			yield mapAssetHolder(holder);
			signal?.throwIfAborted();
		}
	}
	/**
	* Checks that the node has time travel. Stock algod would answer some of these routes with errors of its own; a
	* dtalgod without the holders index rejects the holders request itself with a `DTUnsupportedError`.
	*/
	async requireTimeTravel(feature) {
		await require_dt_support.requireTimeTravel(this._clientManager.algod, feature);
	}
	holdersRequest(assetId, options) {
		const request = this.algod.getAssetHolders(assetId);
		if (options?.round !== void 0) request.round(options.round);
		if (options?.limit !== void 0) request.limit(options.limit);
		return request;
	}
	/** The `key` filter of a listing, if any: checked, and set on the request as the node's `key` parameter. */
	keyFilter(options) {
		if (options?.key === void 0) return void 0;
		const key = filterBytes("key", options.key);
		if (options.rounds) throw new Error("key cannot be combined with rounds");
		return (request) => request.key(key);
	}
	/** The `prefix` filter of a box change feed, if any: checked, and set on the request as the node's `prefix` parameter. */
	prefixFilter(options) {
		if (options?.prefix === void 0) return void 0;
		const prefix = filterBytes("prefix", options.prefix);
		if (prefix.length === 0) return void 0;
		return (request) => request.prefix(prefix);
	}
	/**
	* The `rounds` of each request an iterator sends: the distinct rounds in `order`, in consecutive chunks of
	* `min(limit, maxRoundsPerRequest)`, so a request carries only the rounds its page can return and the URL stays short.
	* One request without `rounds` when there are none; none for an empty list.
	*/
	roundsChunks(options) {
		if (!options?.rounds) return [void 0];
		const rounds = sortedRounds(options.rounds, options.order);
		const size = Math.min(options.limit ?? 100, options.maxRoundsPerRequest ?? 500);
		const chunks = [];
		for (let i = 0; i < rounds.length; i += size) chunks.push(rounds.slice(i, i + size));
		return chunks;
	}
};
//#endregion
exports.DEFAULT_MAX_VERSIONS_ROUNDS_PER_REQUEST = DEFAULT_MAX_VERSIONS_ROUNDS_PER_REQUEST;
exports.DTManager = DTManager;

//# sourceMappingURL=dt-manager.js.map