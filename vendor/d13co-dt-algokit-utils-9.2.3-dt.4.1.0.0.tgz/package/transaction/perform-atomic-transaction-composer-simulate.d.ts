import algosdk from 'algosdk';
import Algodv2 = algosdk.Algodv2;
import AtomicTransactionComposer = algosdk.AtomicTransactionComposer;
import modelsv2 = algosdk.modelsv2;
/**
 * Performs a simulation of the transactions loaded into the given AtomicTransactionComposer.
 * Uses empty transaction signers for all transactions.
 *
 * @param atc The AtomicTransactionComposer with transaction(s) loaded.
 * @param algod An Algod client to perform the simulation.
 * @returns The simulation result, which includes various details about how the transactions would be processed.
 */
export declare function performAtomicTransactionComposerSimulate(atc: AtomicTransactionComposer, algod: Algodv2, options?: Omit<ConstructorParameters<typeof modelsv2.SimulateRequest>[0], 'txnGroups'>): Promise<algosdk.modelsv2.SimulateResponse>;
