import { ClientManager } from "../types/client-manager.mjs";
//#region src/localnet/is-localnet.ts
/** @deprecated Use `await algorand.client.isLocalNet()` or `await new ClientManager({ algod }).isLocalNet()` instead.
*
* Returns true if the algod client is pointing to a LocalNet Algorand network
*/
async function isLocalNet(algod) {
	return await new ClientManager({ algod }).isLocalNet();
}
//#endregion
export { isLocalNet };

//# sourceMappingURL=is-localnet.mjs.map