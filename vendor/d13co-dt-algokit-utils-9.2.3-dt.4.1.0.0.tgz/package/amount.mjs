import { AlgoAmount } from "./types/amount.mjs";
//#region src/amount.ts
Number.prototype.microAlgos = function() {
	return AlgoAmount.MicroAlgo(this);
};
Number.prototype.algos = function() {
	return AlgoAmount.Algo(this);
};
Number.prototype.microAlgo = function() {
	return AlgoAmount.MicroAlgo(this);
};
Number.prototype.algo = function() {
	return AlgoAmount.Algo(this);
};
BigInt.prototype.microAlgo = function() {
	return AlgoAmount.MicroAlgo(this);
};
BigInt.prototype.algo = function() {
	return AlgoAmount.Algo(this);
};
/** Returns an amount of Algo using AlgoAmount
* @param algos The amount of Algo
*/
const algos = (algos) => {
	return AlgoAmount.Algo(algos);
};
/** Returns an amount of Algo using AlgoAmount
* @param algos The amount of Algo
*/
const algo = (algos) => {
	return AlgoAmount.Algo(algos);
};
/** Returns an amount of µAlgo using AlgoAmount
* @param microAlgos The amount of µAlgo
*/
const microAlgos = (microAlgos) => {
	return AlgoAmount.MicroAlgo(microAlgos);
};
/** Returns an amount of µAlgo using AlgoAmount
* @param microAlgos The amount of µAlgo
*/
const microAlgo = (microAlgos) => {
	return AlgoAmount.MicroAlgo(microAlgos);
};
/** Returns an amount of µAlgo to cover standard fees for the given number of transactions using AlgoAmount
* @param numberOfTransactions The of standard transaction fees to return the amount of Algo
*/
const transactionFees = (numberOfTransactions) => {
	return AlgoAmount.MicroAlgo(BigInt(numberOfTransactions) * ALGORAND_MIN_TX_FEE.microAlgo);
};
const ALGORAND_MIN_TX_FEE = AlgoAmount.MicroAlgo(1e3);
//#endregion
export { ALGORAND_MIN_TX_FEE, algo, algos, microAlgo, microAlgos, transactionFees };

//# sourceMappingURL=amount.mjs.map