Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_async_event_emitter = require("./async-event-emitter.js");
const require_logging = require("./logging.js");
//#region src/types/config.ts
/** Updatable AlgoKit config */
var UpdatableConfig = class {
	config;
	get populateAppCallResources() {
		return this.config.populateAppCallResources;
	}
	get logger() {
		return this.config.logger;
	}
	get debug() {
		return this.config.debug;
	}
	get projectRoot() {
		return this.config.projectRoot;
	}
	get traceAll() {
		return this.config.traceAll;
	}
	get traceBufferSizeMb() {
		return this.config.traceBufferSizeMb;
	}
	get maxSearchDepth() {
		return this.config.maxSearchDepth;
	}
	get events() {
		return this.config.events;
	}
	get retry() {
		return this.config.retry;
	}
	/**
	* Returns the current logger, or the null logger if true is passed in to `returnNullLogger`
	* @param returnNullLogger Whether or not to return the null logger
	* @returns The requested logger
	*/
	getLogger(returnNullLogger) {
		if (returnNullLogger) return require_logging.nullLogger;
		return this.logger;
	}
	/**
	* Temporarily run with debug set to true.
	* @param lambda A lambda expression with code to run with debug config set to true
	*/
	withDebug(lambda) {
		const original = this.config.debug;
		try {
			this.config.debug = true;
			lambda();
		} finally {
			this.config.debug = original;
		}
	}
	constructor() {
		this.config = {
			logger: require_logging.consoleLogger,
			debug: false,
			projectRoot: null,
			traceAll: false,
			traceBufferSizeMb: 256,
			maxSearchDepth: 10,
			populateAppCallResources: true,
			events: new require_async_event_emitter.AsyncEventEmitter()
		};
	}
	/**
	* Update the AlgoKit configuration with your own configuration settings
	* @param newConfig Partial or complete config to replace
	*/
	configure(newConfig) {
		this.config = {
			...this.config,
			...newConfig
		};
	}
};
//#endregion
exports.UpdatableConfig = UpdatableConfig;

//# sourceMappingURL=config.js.map