Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.js");
const require_transaction = require("../transaction/transaction.js");
const require_dt_support = require("./dt-support.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/types/simulate-manager.ts
/** The most simulate requests in flight at once, by default. */
const DEFAULT_SIMULATE_CONCURRENCY = 4;
/** The options dtalgod's simulate no longer takes (dt5), with where they went. */
const REMOVED_OPTIONS = {
	protocol: "use algorand.query (query.run, or query.groups / query.rounds) to run past rounds under another protocol",
	validityWindow: "simulate.rounds builds the groups valid at each round, one request per round",
	maxRounds: "simulate.rounds sends one request per round"
};
/** Throws for an option dtalgod's simulate no longer takes, which a caller from before dt5 may still pass. */
function checkRemovedOptions(options) {
	for (const [name, instead] of Object.entries(REMOVED_OPTIONS)) if (options[name] !== void 0) throw new Error(`simulate no longer takes ${name}: ${instead}`);
}
/** The validity window of transactions simulated at `round` (none for the latest round). */
const validityAt = (round) => round ? {
	firstValidRound: BigInt(round) + 1n,
	lastValidRound: BigInt(round) + 11n
} : void 0;
/**
* Checks extended simulate options against the capabilities the node reported, throwing for what it doesn't allow.
* Shared with `QueryManager`, which validates the same options (and its `protocol`).
*/
function checkSimulateLimits(capabilities, protocol, raw) {
	if (!capabilities.developerApi) {
		if (protocol === "future") throw new Error("protocol 'future' needs a node with the developer API (EnableDeveloperAPI), and this node has it off");
		if (raw.execTraceConfig?.enable) throw new Error("execTraceConfig needs a node with the developer API (EnableDeveloperAPI), and this node has it off");
	}
	const { extraOpcodeBudget } = raw;
	const { maxExtraOpcodeBudget } = capabilities.simulate;
	if (extraOpcodeBudget !== void 0 && BigInt(extraOpcodeBudget) > BigInt(maxExtraOpcodeBudget)) throw new Error(`extraOpcodeBudget ${extraOpcodeBudget} is more than the node allows (maxExtraOpcodeBudget ${maxExtraOpcodeBudget})`);
}
/** The `concurrency` option, checked: a positive integer, or the default. */
function checkConcurrency(concurrency) {
	if (concurrency === void 0) return 4;
	if (!Number.isInteger(concurrency) || concurrency < 1) throw new RangeError(`concurrency must be a positive integer, not ${concurrency}`);
	return concurrency;
}
/** Turns a successful group result into the same shape as `TransactionComposer.simulate` returns. */
function toGroupResult(built, group, simulateResponse) {
	const { transactions, methodCalls } = built;
	const { groupId, txIds } = require_dt_support.txIdsOf(built);
	const confirmations = group.txnResults.map((t) => t.txnResult);
	const returns = [...methodCalls.entries()].map(([index, method]) => require_transaction.getABIReturnValue(algosdk.default.AtomicTransactionComposer.parseMethodResponse(method, {
		txID: txIds[index],
		rawReturnValue: /* @__PURE__ */ new Uint8Array(),
		method
	}, confirmations[index]), method.returns.type));
	return {
		confirmations,
		transactions,
		txIds: [...txIds],
		groupId,
		simulateResponse,
		returns
	};
}
function toOutcome(raw, groupIndex, built, response) {
	const base = {
		groupIndex,
		round: raw.round
	};
	return raw.ok ? {
		...base,
		ok: true,
		result: toGroupResult(built, raw.result, response)
	} : {
		...base,
		ok: false,
		error: raw.error
	};
}
/**
* Extended simulate on dtalgod: several transaction groups in one request (one after the other in one block), groups in
* parallel (each alone, in a request of its own), and the same groups at several rounds (a request per round).
*
* The groups are simulated without signatures (like `simulate({ skipSignatures: true })`), so this is for reads and
* dry runs. Needs dt-algosdk (without it, every method throws a `DTNotAvailableError`) and dtalgod: on stock algod,
* `groups` and `rounds` throw dt-algosdk's `DTUnsupportedError` before sending anything. The node's capabilities
* (`algorand.client.capabilities()`), which tell the two apart, are asked for once per algod client.
*
* For read-only app calls, `algorand.query` is faster: many calls at many rounds per request, under another protocol if
* asked.
*/
var SimulateManager = class {
	_clientManager;
	/**
	* Create a new simulate manager.
	* @param clientManager The `ClientManager` client to use for algod
	*/
	constructor(clientManager) {
		this._clientManager = clientManager;
	}
	/**
	* Simulates several transaction groups at the latest round or at a past `round`.
	*
	* The node's limits (see `limits()`) apply: at most `maxTxnGroups` groups per request, and an `extraOpcodeBudget` above
	* `maxExtraOpcodeBudget` throws.
	*
	* By default the groups run one after the other in one block, in one request: later groups see the effects of earlier
	* ones, and a failed group is rolled back without stopping the later ones. With `parallel`, each group runs on its own
	* against the starting state, in a request of its own.
	*
	* @param composers The groups, one composer each
	* @param options The simulate options
	* @returns The outcome of each group, in order
	* @example
	* ```typescript
	* const [a, b] = await algorand.simulate.groups([algorand.newGroup().addPayment(...), algorand.newGroup().addAppCallMethodCall(...)], {
	*   allowUnnamedResources: true,
	* })
	* if (b.ok) console.log(b.result.returns?.[0]?.returnValue)
	* ```
	*/
	async groups(composers, options) {
		const { round, ...rest } = options ?? {};
		require_dt_support.requireDTSdk("Simulating several groups");
		checkRemovedOptions(rest);
		rest.signal?.throwIfAborted();
		const capabilities = await require_dt_support.requireDTNode(this._clientManager.algod, "Simulating several groups");
		const limit = require_dt_support.concurrencyLimiter(checkConcurrency(rest.concurrency));
		const built = await this.buildGroups(composers, validityAt(round));
		return await this.send(built, rest, round, capabilities, limit);
	}
	/**
	* Returns the node's simulate limits: how many groups a request may hold, and the most `extraOpcodeBudget`. `groups`
	* and `rounds` keep to them.
	*
	* They are the `simulate` part of the node's capabilities (`algorand.client.capabilities()`, which also says whether the
	* node is dtalgod at all, and which features it has on), asked for once per algod client. Stock algod, which has no
	* capabilities endpoint, gets stock algod's limits.
	*
	* @returns The node's simulate limits
	* @throws DTNotAvailableError if the loaded algosdk is not dt-algosdk
	* @example
	* ```typescript
	* const { maxTxnGroups, maxExtraOpcodeBudget } = await algorand.simulate.limits()
	* ```
	*/
	async limits() {
		require_dt_support.requireDTSdk("Reading the simulate limits");
		return (await require_dt_support.getCapabilities(this._clientManager.algod)).simulate;
	}
	/**
	* Simulates the same transaction groups at several past rounds: a request per round (and per group with `parallel`),
	* `concurrency` at a time. The groups are built again for each round, valid at it; transactions that set their own
	* `firstValidRound` / `lastValidRound` keep them. A duplicate round is simulated once. A round the node can't simulate
	* (one it doesn't have) throws.
	*
	* For read-only app calls, `algorand.query.rounds` takes many rounds per request.
	*
	* @param composers The groups, one composer each (or a single composer)
	* @param rounds The rounds to simulate at (each > 0): the state as of the end of each round
	* @param options The simulate options
	* @returns The outcomes at each round, in the order of `rounds`
	* @example
	* ```typescript
	* const composer = algorand.newGroup().addAppCallMethodCall(await appClient.params.call({ method: 'get_price' }))
	* const prices = await algorand.simulate.rounds(composer, [45_000_000n, 45_001_000n, 45_002_000n], { allowUnnamedResources: true })
	* for (const { round, groups: [g] } of prices) if (g.ok) console.log(round, g.result.returns?.[0]?.returnValue)
	* ```
	*/
	async rounds(composers, rounds, options) {
		const groups = Array.isArray(composers) ? composers : [composers];
		require_dt_support.requireDTSdk("Simulating at several rounds");
		checkRemovedOptions(options ?? {});
		const limit = require_dt_support.concurrencyLimiter(checkConcurrency(options?.concurrency));
		options?.signal?.throwIfAborted();
		const capabilities = await require_dt_support.requireDTNode(this._clientManager.algod, "Simulating at several rounds");
		if (rounds.length === 0) return [];
		const unique = [...new Set(rounds.map((r) => BigInt(r)))];
		const zero = unique.find((r) => r < 1n);
		if (zero !== void 0) throw new RangeError(`Can't simulate at round ${zero} in rounds: give past rounds (look the latest round up with status())`);
		const built = [];
		for (const r of unique) built.push(await this.buildGroups(groups, validityAt(r)));
		const results = await Promise.all(unique.map((r, i) => this.send(built[i], options ?? {}, r, capabilities, limit)));
		const byRound = new Map(unique.map((r, i) => [r, results[i]]));
		return rounds.map((r) => ({
			round: BigInt(r),
			groups: byRound.get(BigInt(r))
		}));
	}
	async buildGroups(composers, validity) {
		if (composers.length === 0) throw new Error("No transaction groups to simulate");
		const built = [];
		for (const composer of composers) {
			const b = validity ? await composer.buildTransactionsWithValidity(validity) : await composer.buildTransactions();
			if (b.transactions.length === 0) throw new Error(`Transaction group ${built.length} is empty`);
			built.push(require_dt_support.asSentGroup(b));
		}
		return built;
	}
	/** Sends the groups at one round (the latest for none): in one request, or one request per group with `parallel`. */
	async send(built, options, round, capabilities, limit) {
		const tt = require_dt_support.requireDTSdk("Simulating several groups");
		const { parallel = false, maxGroups: maxGroupsOption, signal, concurrency: _concurrency, ...raw } = options;
		signal?.throwIfAborted();
		const fetchOptions = signal ? { signal } : void 0;
		const maxGroups = maxGroupsOption ?? capabilities.simulate.maxTxnGroups;
		if (!Number.isInteger(maxGroups) || maxGroups < 1) throw new RangeError(`maxGroups must be a positive integer, not ${maxGroups}`);
		if (!parallel && built.length > maxGroups) throw new Error(`Can't simulate ${built.length} groups one after the other: ${maxGroupsOption === void 0 ? "the node takes" : "maxGroups allows"} at most ${maxGroups} per request (use parallel to send each group on its own)`);
		checkSimulateLimits(capabilities, void 0, raw);
		const requests = parallel ? built.map((g) => [g]) : [built];
		const algod = this._clientManager.dtAlgod;
		let at = round || void 0;
		if (requests.length > 1 && !at) at = (await this._clientManager.algod.status().do(void 0, fetchOptions)).lastRound;
		const responses = await Promise.all(requests.map(async (groups) => {
			const request = tt.dtModels.DTSimulateRequest.fromTransactions(groups.map((g) => g.transactions), {
				...raw,
				allowEmptySignatures: true,
				fixSigners: true,
				round: at
			});
			return await limit(() => algod.simulateTransactions(request).do(void 0, fetchOptions));
		}));
		return requests.flatMap((groups, r) => {
			const response = responses[r];
			return response.groupResults(groups.length).map((raw, g) => toOutcome(raw, parallel ? r : g, groups[g], response));
		});
	}
};
//#endregion
exports.DEFAULT_SIMULATE_CONCURRENCY = DEFAULT_SIMULATE_CONCURRENCY;
exports.SimulateManager = SimulateManager;
exports.checkSimulateLimits = checkSimulateLimits;

//# sourceMappingURL=simulate-manager.js.map