import { AsyncEventEmitter } from './async-event-emitter';
import { Logger } from './logging';
import type { RetryOptionsLike } from './retry';
/** The AlgoKit configuration type */
export interface Config {
    /** Logger */
    logger: Logger;
    /** Whether or not debug mode is enabled */
    debug: boolean;
    /** The path to the project root directory */
    projectRoot: string | null;
    /** Indicates whether to trace all operations */
    traceAll: boolean;
    /** The size of the trace buffer in megabytes */
    traceBufferSizeMb: number;
    /** The maximum depth to search for a specific file */
    maxSearchDepth: number;
    /**
     * Whether to enable populateAppCallResources in sendParams by default.
     * Default value is false.
     */
    populateAppCallResources: boolean;
    events: AsyncEventEmitter;
    /**
     * How the algod and indexer clients that algokit-utils makes retry failed requests: the retry policy fields to change,
     * or `false` for no retries. Read on every request, so it applies to clients made before `configure`. A client's own
     * `retry` (`AlgoClientConfig.retry`) wins, field by field (`false` counting as `{ maxTries: 1 }`). Needs dt-algosdk (feature `retry-policy`): with stock
     * algosdk the clients retry as upstream algokit-utils does, and this has no effect. See "Retries" in docs/dt-fork.md.
     */
    retry?: RetryOptionsLike;
}
/** Updatable AlgoKit config */
export declare class UpdatableConfig implements Readonly<Config> {
    private config;
    get populateAppCallResources(): boolean;
    get logger(): Logger;
    get debug(): boolean;
    get projectRoot(): string | null;
    get traceAll(): boolean;
    get traceBufferSizeMb(): number;
    get maxSearchDepth(): number;
    get events(): AsyncEventEmitter;
    get retry(): RetryOptionsLike | undefined;
    /**
     * Returns the current logger, or the null logger if true is passed in to `returnNullLogger`
     * @param returnNullLogger Whether or not to return the null logger
     * @returns The requested logger
     */
    getLogger(returnNullLogger?: boolean): Logger;
    /**
     * Temporarily run with debug set to true.
     * @param lambda A lambda expression with code to run with debug config set to true
     */
    withDebug(lambda: () => unknown): void;
    constructor();
    /**
     * Update the AlgoKit configuration with your own configuration settings
     * @param newConfig Partial or complete config to replace
     */
    configure(newConfig: Partial<Config>): void;
}
