import { BaseHTTPClientResponse, Query, URLTokenBaseHTTPClient } from 'algosdk/client';
import type { RetryOptionsLike, RetryWaitLike } from './retry';
/**
 * Marks a client that retries, so dt-algosdk's `withRetry` doesn't wrap it again (dt-algosdk's `RETRYING_CLIENT`, a
 * registered symbol).
 */
export declare const RETRYING_CLIENT: unique symbol;
/**
 * A HTTP Client that wraps the Algorand SDK HTTP Client with retries.
 *
 * With dt-algosdk (feature `retry-policy`), requests (algod, indexer, simulate, query, deltas, ...) are retried by its
 * retry policy ("Retries" in docs/dt-fork.md): up to 5 tries; 408, 429, 500, 502, 503, 504 and network errors; not a 503
 * for history the node can't serve, nor a 504 from a request under the node's time limit, nor a transaction submit the
 * node may have taken; waits of 0, 2, 4, 8 s, at least a 429's or 503's `Retry-After` (giving up above 30 s), and at least
 * 1 s for a 429 or busy 503 without one, a refused connection or a browser's failed fetch. The policy can be changed per client (`retry` in the constructor or
 * `AlgoClientConfig`) and globally (`Config.configure({ retry })`), the client's fields winning. Each wait is logged
 * (`Config.logger.warn`), emitted as `EventType.RetryWait` on `Config.events`, passed to the policy's `onWait`, and
 * listed in {@link waits} while it lasts.
 *
 * With stock algosdk, requests are retried as upstream algokit-utils does (up to 5 tries, at once and then after 2, 4,
 * 8 s), stopping when the request's `signal` aborts; the `retry` options have no effect and no event is emitted.
 */
export declare class AlgoHttpClientWithRetry extends URLTokenBaseHTTPClient {
    private static readonly MAX_TRIES;
    private static readonly MAX_BACKOFF_MS;
    private static readonly RETRY_STATUS_CODES;
    private static readonly RETRY_ERROR_CODES;
    /** This client retries: dt-algosdk's `withRetry` returns it as is. */
    readonly [RETRYING_CLIENT] = true;
    /** This client's retry policy fields, which win over `Config.retry`; `false` for no retries. Needs dt-algosdk. */
    readonly retry?: RetryOptionsLike;
    private readonly active;
    /**
     * @param tokenHeader The token header, as for `URLTokenBaseHTTPClient`
     * @param baseServer The server URL
     * @param port The port
     * @param defaultHeaders Headers sent with every request
     * @param retry This client's retry policy fields, which win over `Config.retry`; `false` for no retries. Needs dt-algosdk
     */
    constructor(tokenHeader: ConstructorParameters<typeof URLTokenBaseHTTPClient>[0], baseServer: string, port?: string | number, defaultHeaders?: Record<string, string>, retry?: RetryOptionsLike);
    /** The requests waiting to be retried now, one entry each (dt-algosdk only). */
    get waits(): readonly RetryWaitLike[];
    /** Of the requests waiting now, the one that waits longest, if any (dt-algosdk only). */
    get waiting(): RetryWaitLike | undefined;
    /** The abort signal in fetch options passed as `customOptions`, if any. */
    private static signalOf;
    /** Waits `ms`, rejecting with the signal's reason as soon as it aborts. */
    private static sleep;
    /** The policy for a request: `Config.retry` with this client's fields over it, and an `onWait` that also logs and emits. */
    private retryOptions;
    private callWithRetry;
    get(relativePath: string, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
    post(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
    delete(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
}
