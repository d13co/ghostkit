Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/types/lifecycle-events.ts
let EventType = /* @__PURE__ */ function(EventType) {
	EventType["TxnGroupSimulated"] = "TxnGroupSimulated";
	EventType["AppCompiled"] = "AppCompiled";
	/** A request of an algod or indexer client made by algokit-utils is about to wait before a retry (dt-algosdk only). */
	EventType["RetryWait"] = "retry-wait";
	return EventType;
}({});
//#endregion
exports.EventType = EventType;

//# sourceMappingURL=lifecycle-events.js.map