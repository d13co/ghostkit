Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_config = require("../config.js");
require("./lifecycle-events.js");
const require_dt_support = require("./dt-support.js");
let algosdk = require("algosdk");
let algosdk_client = require("algosdk/client");
//#region src/types/algo-http-client-with-retry.ts
/**
* Marks a client that retries, so dt-algosdk's `withRetry` doesn't wrap it again (dt-algosdk's `RETRYING_CLIENT`, a
* registered symbol).
*/
const RETRYING_CLIENT = Symbol.for("dt-algosdk.retrying-client");
/** Calls `f`, ignoring what it throws or a promise it rejects: a broken listener must not break the request. */
function callQuietly(f) {
	try {
		const result = f();
		if (result && typeof result.catch === "function") result.catch(() => {});
	} catch {}
}
/**
* A HTTP Client that wraps the Algorand SDK HTTP Client with retries.
*
* With dt-algosdk (feature `retry-policy`), requests (algod, indexer, simulate, query, deltas, ...) are retried by its
* retry policy ("Retries" in docs/dt-fork.md): up to 5 tries; 408, 429, 500, 502, 503, 504 and network errors; not a 503
* for history the node can't serve, nor a 504 from a request under the node's time limit, nor a transaction submit the
* node may have taken; waits of 0, 2, 4, 8 s, at least a 429's or 503's `Retry-After` (giving up above 30 s), and at least
* 1 s for a 429 or busy 503 without one, a refused connection or a browser's failed fetch. The policy can be changed per client (`retry` in the constructor or
* `AlgoClientConfig`) and globally (`Config.configure({ retry })`), the client's fields winning. Each wait is logged
* (`Config.logger.warn`), emitted as `EventType.RetryWait` on `Config.events`, passed to the policy's `onWait`, and
* listed in {@link waits} while it lasts.
*
* With stock algosdk, requests are retried as upstream algokit-utils does (up to 5 tries, at once and then after 2, 4,
* 8 s), stopping when the request's `signal` aborts; the `retry` options have no effect and no event is emitted.
*/
var AlgoHttpClientWithRetry = class AlgoHttpClientWithRetry extends algosdk_client.URLTokenBaseHTTPClient {
	static MAX_TRIES = 5;
	static MAX_BACKOFF_MS = 1e4;
	static RETRY_STATUS_CODES = [
		408,
		413,
		429,
		500,
		502,
		503,
		504
	];
	static RETRY_ERROR_CODES = [
		"ETIMEDOUT",
		"ECONNRESET",
		"EADDRINUSE",
		"ECONNREFUSED",
		"EPIPE",
		"ENOTFOUND",
		"ENETUNREACH",
		"EAI_AGAIN",
		"EPROTO"
	];
	/** This client retries: dt-algosdk's `withRetry` returns it as is. */
	[RETRYING_CLIENT] = true;
	/** This client's retry policy fields, which win over `Config.retry`; `false` for no retries. Needs dt-algosdk. */
	retry;
	active = /* @__PURE__ */ new Set();
	/**
	* @param tokenHeader The token header, as for `URLTokenBaseHTTPClient`
	* @param baseServer The server URL
	* @param port The port
	* @param defaultHeaders Headers sent with every request
	* @param retry This client's retry policy fields, which win over `Config.retry`; `false` for no retries. Needs dt-algosdk
	*/
	constructor(tokenHeader, baseServer, port, defaultHeaders, retry) {
		super(tokenHeader, baseServer, port, defaultHeaders);
		this.retry = retry;
	}
	/** The requests waiting to be retried now, one entry each (dt-algosdk only). */
	get waits() {
		return [...this.active];
	}
	/** Of the requests waiting now, the one that waits longest, if any (dt-algosdk only). */
	get waiting() {
		let latest;
		for (const wait of this.active) if (!latest || wait.until > latest.until) latest = wait;
		return latest;
	}
	/** The abort signal in fetch options passed as `customOptions`, if any. */
	static signalOf(customOptions) {
		const signal = customOptions?.signal;
		return signal && typeof signal === "object" && "aborted" in signal ? signal : void 0;
	}
	/** Waits `ms`, rejecting with the signal's reason as soon as it aborts. */
	static sleep(ms, signal) {
		return new Promise((resolve, reject) => {
			if (signal?.aborted) return reject(signal.reason);
			const onAbort = () => {
				clearTimeout(timer);
				reject(signal.reason);
			};
			const timer = setTimeout(() => {
				signal?.removeEventListener("abort", onAbort);
				resolve();
			}, ms);
			signal?.addEventListener("abort", onAbort, { once: true });
		});
	}
	/** The policy for a request: `Config.retry` with this client's fields over it, and an `onWait` that also logs and emits. */
	retryOptions(formatRetryWait) {
		const fieldsOf = (options) => options === false ? { maxTries: 1 } : options;
		const policy = {};
		for (const fields of [fieldsOf(require_config.Config.retry), fieldsOf(this.retry)]) for (const [key, value] of Object.entries(fields ?? {})) if (value !== void 0) policy[key] = value;
		const onWait = policy.onWait;
		policy.onWait = (wait) => {
			callQuietly(() => require_config.Config.logger.warn(`${formatRetryWait(wait)}: ${wait.method.toUpperCase()} ${wait.path} failed: ${wait.error}`));
			callQuietly(() => require_config.Config.events.emitAsync("retry-wait", wait));
			if (onWait) callQuietly(() => onWait(wait));
		};
		return policy;
	}
	async callWithRetry(method, path, func, customOptions) {
		const signal = AlgoHttpClientWithRetry.signalOf(customOptions);
		const dt = require_dt_support.getDTRetry();
		if (dt) return dt.callWithRetry(func, {
			method,
			path,
			signal
		}, this.retryOptions(dt.formatRetryWait), this.active);
		let response;
		let numTries = 1;
		do {
			signal?.throwIfAborted();
			try {
				response = await func();
			} catch (err) {
				if (signal?.aborted) throw err;
				if (numTries >= AlgoHttpClientWithRetry.MAX_TRIES) throw err;
				if (!(AlgoHttpClientWithRetry.RETRY_ERROR_CODES.includes(err.code ?? err.cause?.code) || AlgoHttpClientWithRetry.RETRY_STATUS_CODES.includes(Number(err.status)) || "response" in err && AlgoHttpClientWithRetry.RETRY_STATUS_CODES.includes(Number(err.response?.status)))) throw err;
				const delayTimeMs = numTries == 1 ? 0 : Math.min(1e3 * Math.pow(2, numTries - 1), AlgoHttpClientWithRetry.MAX_BACKOFF_MS);
				if (delayTimeMs > 0) await AlgoHttpClientWithRetry.sleep(delayTimeMs, signal);
				require_config.Config.logger.warn(`algosdk request failed ${numTries} times. Retrying in ${delayTimeMs}ms: ${err}`);
			}
		} while (!response && ++numTries <= AlgoHttpClientWithRetry.MAX_TRIES);
		return response;
	}
	async get(relativePath, query, requestHeaders = {}, customOptions) {
		const response = await this.callWithRetry("get", relativePath, () => super.get(relativePath, query, requestHeaders, customOptions), customOptions);
		if (relativePath.startsWith("/v2/accounts/") && relativePath.endsWith("/created-applications") && response.status === 200 && query?.["include-all"]?.toString() === "true") try {
			const json = (0, algosdk.parseJSON)(Buffer.from(response.body).toString(), { intDecoding: algosdk.IntDecoding.MIXED });
			if (json.applications) {
				for (const app of json.applications) if (app.params) {
					if (app.params["approval-program"] === null) app.params["approval-program"] = "";
					if (app.params["clear-state-program"] === null) app.params["clear-state-program"] = "";
				}
				response.body = Buffer.from((0, algosdk.stringifyJSON)(json));
			}
		} catch (e) {
			require_config.Config.logger.warn("Failed to fix indexer response for created applications", e);
		}
		return response;
	}
	async post(relativePath, data, query, requestHeaders = {}, customOptions) {
		return await this.callWithRetry("post", relativePath, () => super.post(relativePath, data, query, requestHeaders, customOptions), customOptions);
	}
	async delete(relativePath, data, query, requestHeaders = {}, customOptions) {
		return await this.callWithRetry("delete", relativePath, () => super.delete(relativePath, data, query, requestHeaders, customOptions), customOptions);
	}
};
//#endregion
exports.AlgoHttpClientWithRetry = AlgoHttpClientWithRetry;
exports.RETRYING_CLIENT = RETRYING_CLIENT;

//# sourceMappingURL=algo-http-client-with-retry.js.map