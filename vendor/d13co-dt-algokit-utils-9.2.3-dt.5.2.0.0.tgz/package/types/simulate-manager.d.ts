import algosdk from 'algosdk';
import { ClientManager } from './client-manager';
import { RawSimulateOptions, TransactionComposer } from './composer';
import { Capabilities, Round, SimulateLimits } from './dt-support';
import { SendAtomicTransactionComposerResults } from './transaction';
import modelsv2 = algosdk.modelsv2;
/** The most simulate requests in flight at once, by default. */
export declare const DEFAULT_SIMULATE_CONCURRENCY = 4;
/** Options for an extended simulate request. */
export type ExtendedSimulateOptions = Omit<RawSimulateOptions, 'allowEmptySignatures' | 'fixSigners' | 'round'> & {
    /**
     * Simulate each group on its own against the starting state, in a request of its own, instead of one after the other in
     * one block. Parallel groups don't see each other's effects. When the groups go in several requests at the latest
     * round, it is looked up first so they all run at the same round.
     */
    parallel?: boolean;
    /**
     * The most groups per request without `parallel`. Groups one after the other can't be split across requests, so more
     * than this throws. Defaults to the node's `maxTxnGroups` (see `limits()`). Above what the node allows, the node rejects
     * the request.
     */
    maxGroups?: number;
    /**
     * The most simulate requests in flight at once (default {@link DEFAULT_SIMULATE_CONCURRENCY}, 4), across the rounds of
     * `rounds` and the requests of `parallel` groups. After a request fails, the ones not yet sent aren't.
     */
    concurrency?: number;
};
/** Options to simulate several groups at one round. */
export type SimulateGroupsOptions = ExtendedSimulateOptions & {
    /**
     * Simulate as of the end of this past round (0 or `undefined` for the latest round). Needs time travel on the node
     * for rounds older than its `MaxAcctLookback`. Transactions that don't set their own validity are built valid at this
     * round.
     */
    round?: Round;
};
/** Options to simulate groups at several rounds. */
export type SimulateRoundsOptions = ExtendedSimulateOptions;
/** The result of a group that simulated without failing. */
export type SimulateGroupResult = SendAtomicTransactionComposerResults & {
    /** The whole simulate response the group came in. */
    simulateResponse: modelsv2.SimulateResponse;
};
/** Why a group has no result: the group failed, the group wasn't simulated, or the node returned no result for it. */
export type SimulateGroupError = Error & {
    /**
     * - `group`: the group failed (see `failureMessage` and `failedAt`)
     * - `not-simulated`: the group wasn't simulated because an earlier group broke the block
     * - `missing`: the node returned no result for the group
     */
    kind: 'group' | 'not-simulated' | 'missing';
    /** The failure message of a failed group. */
    failureMessage?: string;
    /** The path of the failed transaction of a failed group. */
    failedAt?: number[];
    /** The result of a failed group, with the results of its transactions up to the failure. */
    result?: modelsv2.SimulateTransactionGroupResult;
};
/** The outcome of one group of an extended simulate request. */
export type SimulateGroupOutcome = {
    /** The index of the group, in the order the composers were given. */
    groupIndex: number;
    /** The round the group was simulated at: the state as of the end of this round. */
    round: bigint;
} & ({
    ok: true;
    result: SimulateGroupResult;
} | {
    ok: false;
    error: SimulateGroupError;
});
/** The outcomes of the groups at one round. */
export interface SimulateRoundOutcome {
    /** The round, as given. */
    round: bigint;
    /** The outcome of each group, in the order the composers were given. */
    groups: SimulateGroupOutcome[];
}
/**
 * Checks extended simulate options against the capabilities the node reported, throwing for what it doesn't allow.
 * Shared with `QueryManager`, which validates the same options (and its `protocol`).
 */
export declare function checkSimulateLimits(capabilities: Capabilities, protocol: string | undefined, raw: Pick<RawSimulateOptions, 'execTraceConfig' | 'extraOpcodeBudget'>): void;
/**
 * Extended simulate on dtalgod: several transaction groups in one request (one after the other in one block), groups in
 * parallel (each alone, in a request of its own), and the same groups at several rounds (a request per round).
 *
 * The groups are simulated without signatures (like `simulate({ skipSignatures: true })`), so this is for reads and
 * dry runs. Needs dt-algosdk (without it, every method throws a `DTNotAvailableError`) and dtalgod: on stock algod,
 * `groups` and `rounds` throw dt-algosdk's `DTUnsupportedError` before sending anything. The node's capabilities
 * (`algorand.client.capabilities()`), which tell the two apart, are asked for once per algod client.
 *
 * For read-only app calls, `algorand.query` is faster: many calls at many rounds per request, under another protocol if
 * asked.
 */
export declare class SimulateManager {
    private _clientManager;
    /**
     * Create a new simulate manager.
     * @param clientManager The `ClientManager` client to use for algod
     */
    constructor(clientManager: ClientManager);
    /**
     * Simulates several transaction groups at the latest round or at a past `round`.
     *
     * The node's limits (see `limits()`) apply: at most `maxTxnGroups` groups per request, and an `extraOpcodeBudget` above
     * `maxExtraOpcodeBudget` throws.
     *
     * By default the groups run one after the other in one block, in one request: later groups see the effects of earlier
     * ones, and a failed group is rolled back without stopping the later ones. With `parallel`, each group runs on its own
     * against the starting state, in a request of its own.
     *
     * @param composers The groups, one composer each
     * @param options The simulate options
     * @returns The outcome of each group, in order
     * @example
     * ```typescript
     * const [a, b] = await algorand.simulate.groups([algorand.newGroup().addPayment(...), algorand.newGroup().addAppCallMethodCall(...)], {
     *   allowUnnamedResources: true,
     * })
     * if (b.ok) console.log(b.result.returns?.[0]?.returnValue)
     * ```
     */
    groups(composers: TransactionComposer[], options?: SimulateGroupsOptions): Promise<SimulateGroupOutcome[]>;
    /**
     * Returns the node's simulate limits: how many groups a request may hold, and the most `extraOpcodeBudget`. `groups`
     * and `rounds` keep to them.
     *
     * They are the `simulate` part of the node's capabilities (`algorand.client.capabilities()`, which also says whether the
     * node is dtalgod at all, and which features it has on), asked for once per algod client. Stock algod, which has no
     * capabilities endpoint, gets stock algod's limits.
     *
     * @returns The node's simulate limits
     * @throws DTNotAvailableError if the loaded algosdk is not dt-algosdk
     * @example
     * ```typescript
     * const { maxTxnGroups, maxExtraOpcodeBudget } = await algorand.simulate.limits()
     * ```
     */
    limits(): Promise<SimulateLimits>;
    /**
     * Simulates the same transaction groups at several past rounds: a request per round (and per group with `parallel`),
     * `concurrency` at a time. The groups are built again for each round, valid at it; transactions that set their own
     * `firstValidRound` / `lastValidRound` keep them. A duplicate round is simulated once. A round the node can't simulate
     * (one it doesn't have) throws.
     *
     * For read-only app calls, `algorand.query.rounds` takes many rounds per request.
     *
     * @param composers The groups, one composer each (or a single composer)
     * @param rounds The rounds to simulate at (each > 0): the state as of the end of each round
     * @param options The simulate options
     * @returns The outcomes at each round, in the order of `rounds`
     * @example
     * ```typescript
     * const composer = algorand.newGroup().addAppCallMethodCall(await appClient.params.call({ method: 'get_price' }))
     * const prices = await algorand.simulate.rounds(composer, [45_000_000n, 45_001_000n, 45_002_000n], { allowUnnamedResources: true })
     * for (const { round, groups: [g] } of prices) if (g.ok) console.log(round, g.result.returns?.[0]?.returnValue)
     * ```
     */
    rounds(composers: TransactionComposer | TransactionComposer[], rounds: Round[], options?: SimulateRoundsOptions): Promise<SimulateRoundOutcome[]>;
    private buildGroups;
    /** Sends the groups at one round (the latest for none): in one request, or one request per group with `parallel`. */
    private send;
}
