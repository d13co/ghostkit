import algosdk from "algosdk";
import { Buffer } from "buffer";
//#region src/types/dt-support.ts
/**
* Runtime support for dtalgod (a time-travel algod) through the time-travel fork of algosdk.
*
* algokit-utils keeps working with stock algosdk: the fork's `DTAlgodClient` is looked up at runtime, and
* the features that need it throw a {@link DTNotAvailableError} when it isn't there. The types below describe
* the parts of the fork that algokit-utils uses, in terms of stock algosdk types, so that the published declarations
* never reference the fork.
*/
/** The `DTAlgodClient.features` that algokit-utils needs. */
const REQUIRED_DT_FEATURES = Object.freeze([
	"reads-at-round",
	"versions",
	"simulate-groups",
	"parallel-groups",
	"simulate-rounds",
	"from",
	"group-results",
	"from-transactions",
	"pack-rounds"
]);
/** Thrown when a time travel or extended simulate feature is used but the loaded algosdk is not the time-travel fork, or a version without it. */
var DTNotAvailableError = class extends Error {
	/**
	* @param feature The feature that was used, for the message
	* @param missing The optional features that a loaded fork lacks, if the fork is loaded but too old
	*/
	constructor(feature, missing = []) {
		super(missing.length > 0 ? `${feature} needs a newer version of the time-travel fork of algosdk: the loaded one does not have the DTAlgodClient features ${missing.join(", ")}. Install a newer fork and make sure the app loads a single copy of algosdk.` : `${feature} needs the time-travel fork of algosdk (with DTAlgodClient features ${REQUIRED_DT_FEATURES.join(", ")}), but the loaded algosdk does not have it. Install the fork and make sure the app loads a single copy of algosdk.`);
		this.name = "DTNotAvailableError";
	}
};
/** The fetch options (`customOptions`) that carry an abort signal to algosdk's `.do()`, if there is one. */
const fetchOptions = (options) => options?.signal ? { signal: options.signal } : void 0;
/** The order the node lists protocol notes in; codes it adds later go after these. */
const PROTOCOL_NOTE_ORDER = [
	"semantics-changed",
	"no-heartbeat-challenges",
	"no-load-history",
	"block-incentive-fields",
	"block-hash-fields",
	"online-stake-includes-expired",
	"account-incentive-fields",
	"app-version-starts-at-upgrade"
];
/**
* A protocol override with each note hit replaced by `map(hit)`: for results of requests that hold only part of the
* groups or calls asked for. Notes without hits, and an override without notes, are kept as they are.
* @param override The override of one request at one round, if any
* @param map The new hit for a hit of that request
*/
function mapProtocolOverrideHits(override, map) {
	if (!override || !override.notes) return override;
	return {
		...override,
		notes: override.notes.map((n) => n.hits ? {
			...n,
			hits: n.hits.map(map)
		} : n)
	};
}
/**
* A protocol override with the notes' group indexes moved by `offset`: for a request whose first group (or call) is the
* `offset`th of those asked for.
*/
function offsetProtocolOverride(override, offset) {
	if (offset === 0) return override;
	return mapProtocolOverrideHits(override, (h) => ({
		...h,
		group: h.group + offset
	}));
}
/**
* Merges the protocol overrides of the requests that the groups (or calls) of one round were split across: notes with the
* same code and message become one with all their hits, in the node's note order, and the override is `applied` if it
* applied in any request. Undefined when no request has one.
*/
function mergeProtocolOverrides(overrides) {
	const present = overrides.filter((o) => o !== void 0);
	if (present.length <= 1) return present[0];
	const notes = [];
	for (const n of present.flatMap((o) => o.notes ?? [])) {
		const same = notes.find((m) => m.code === n.code && m.message === n.message);
		if (!same) notes.push({
			...n,
			...n.hits ? { hits: [...n.hits] } : {}
		});
		else if (n.hits) same.hits = [...same.hits ?? [], ...n.hits];
	}
	const rank = (code) => PROTOCOL_NOTE_ORDER.includes(code) ? PROTOCOL_NOTE_ORDER.indexOf(code) : PROTOCOL_NOTE_ORDER.length;
	notes.sort((a, b) => rank(a.code) - rank(b.code));
	return {
		from: present[0].from,
		to: present[0].to,
		applied: present.some((o) => o.applied),
		...notes.length ? { notes } : {}
	};
}
/** The IDs of built groups' transactions, by the built group, with the group ID they were hashed under. */
const builtTxIds = /* @__PURE__ */ new WeakMap();
/**
* The base64 group ID and the transaction IDs of a built group, hashed once per group ID. Requests with `rounds` return
* the same group at every round, and hashing its transactions again for each was a large part of the time spent on the
* response. The `txIds` array is shared: copy it before handing it out.
*/
function txIdsOf(built) {
	const groupId = Buffer.from(built.transactions[0].group ?? /* @__PURE__ */ new Uint8Array()).toString("base64");
	const cached = builtTxIds.get(built);
	if (cached && cached.groupId === groupId) return cached;
	const ids = {
		groupId,
		txIds: built.transactions.map((t) => t.txID())
	};
	builtTxIds.set(built, ids);
	return ids;
}
/**
* Returns a function that runs tasks at most `concurrency` at a time, in the order they are given. After a task fails,
* the tasks not yet started reject with that error instead of running.
*/
function concurrencyLimiter(concurrency) {
	let active = 0;
	let failure;
	const waiting = [];
	return async (task) => {
		if (active >= concurrency) await new Promise((resolve) => waiting.push(resolve));
		else active++;
		try {
			if (failure) throw failure.error;
			return await task();
		} catch (error) {
			failure ??= { error };
			throw error;
		} finally {
			const next = waiting.shift();
			if (next) next();
			else active--;
		}
	};
}
/**
* Maps `items` with `fn`, at most `concurrency` at a time, keeping the order. The first failure rejects the result; the
* calls already started run on, and no new one starts after it.
*/
async function mapConcurrently(items, concurrency, fn) {
	const results = new Array(items.length);
	let nextIndex = 0;
	let failed = false;
	const worker = async () => {
		while (!failed && nextIndex < items.length) {
			const index = nextIndex++;
			try {
				results[index] = await fn(items[index], index);
			} catch (error) {
				failed = true;
				throw error;
			}
		}
	};
	await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
	return results;
}
/** Splits `items` into consecutive chunks of at most `size`. */
const chunk = (items, size) => {
	const chunks = [];
	for (let i = 0; i < items.length; i += size) chunks.push(items.slice(i, i + size));
	return chunks;
};
const sdk = algosdk;
/** Returns the parts of the time-travel fork of algosdk that algokit-utils uses, or `undefined` with stock algosdk. */
function getDTSdk() {
	const features = sdk.DTAlgodClient?.features;
	if (!features || !REQUIRED_DT_FEATURES.every((f) => features.includes(f))) return void 0;
	if (!sdk.packSimulateRounds || !sdk.dtModels?.DTSimulateRequest?.fromTransactions) return void 0;
	return sdk;
}
/** Returns the parts of the time-travel fork of algosdk that algokit-utils uses, or throws a {@link DTNotAvailableError}. */
function requireDTSdk(feature) {
	const tt = getDTSdk();
	if (!tt) throw new DTNotAvailableError(feature);
	return tt;
}
/**
* Like {@link requireDTSdk}, but also needs the given optional `DTAlgodClient.features` of a later version of the fork.
* @throws DTNotAvailableError if the loaded algosdk is not the time-travel fork, or a version without these features
*/
function requireDTSdkFeatures(feature, optional) {
	const tt = requireDTSdk(feature);
	const features = tt.DTAlgodClient.features ?? [];
	const missing = optional.filter((f) => !features.includes(f));
	if (missing.length > 0) throw new DTNotAvailableError(feature, missing);
	return tt;
}
/**
* Returns a time-travel algod client that shares the connection (server, token, headers and HTTP client) of the given
* algod client. The same client is returned for the same `algod`, so its cached time travel probe is kept.
*
* @param algod The algod client to share the connection of
* @param feature The feature that needs the client, for the error message
* @throws DTNotAvailableError if the loaded algosdk is not the time-travel fork
*/
function toDTAlgod(algod, feature = "This feature") {
	return requireDTSdk(feature).DTAlgodClient.from(algod);
}
/**
* Returns the node's simulate limits, through the fork's cached `DTAlgodClient.simulateLimits()`: stock algod's limits
* (`reported` false) if the node has no limits endpoint. Returns `undefined` when the loaded algosdk is not the
* time-travel fork, or a version without the `simulate-limits` feature, so the limits are unknown.
* @param algod The algod client to ask
* @throws The request's error, other than a 404
*/
async function getSimulateLimits(algod) {
	const tt = getDTSdk();
	if (!tt || !(tt.DTAlgodClient.features ?? []).includes("simulate-limits")) return void 0;
	const client = tt.DTAlgodClient.from(algod);
	if (!client.simulateLimits) return void 0;
	const { maxTxnGroups, maxRounds, maxExtraOpcodeBudget, resourceLimitMultiplier, timeTravel, developerApi, reported, query } = await client.simulateLimits();
	return {
		maxTxnGroups,
		maxRounds,
		maxExtraOpcodeBudget,
		resourceLimitMultiplier,
		timeTravel,
		developerApi,
		reported: reported === true,
		...query ? { query: {
			maxCalls: query.maxCalls,
			maxCallBudget: query.maxCallBudget,
			maxCallLogBytes: query.maxCallLogBytes,
			maxResponseBytes: query.maxResponseBytes,
			maxRounds: query.maxRounds
		} } : {}
	};
}
/**
* Returns the node's query limits (`query` of its simulate limits), or `undefined` when the node has no queries (stock
* algod, an older dtalgod, or queries disabled) or the loaded algosdk is not a version of the time-travel fork with the
* `query` feature.
* @param algod The algod client to ask
* @throws The limits request's error, other than a 404
*/
async function getQueryLimits(algod) {
	const tt = getDTSdk();
	if (!tt || !(tt.DTAlgodClient.features ?? []).includes("query")) return void 0;
	return (await getSimulateLimits(algod))?.query;
}
/**
* Returns whether an error is the fork's `DTUnsupportedError`: the node answered without time travel, or for a
* different round than the one asked for.
*/
function isDTUnsupportedError(error) {
	const ctor = sdk.DTUnsupportedError;
	return ctor !== void 0 && error instanceof ctor || error instanceof Error && error.name === "DTUnsupportedError";
}
/**
* Returns a time-travel algod client for a read at a past round, after checking that the node supports time travel
* when `checkSupport` is set. Use `checkSupport` for reads whose response has no round to check, such as asset and
* application lookups, so that a stock node can't silently answer with the latest state.
*/
async function dtAlgodForRead(algod, feature, round, checkSupport) {
	const tt = requireDTSdk(feature);
	const client = tt.DTAlgodClient.from(algod);
	if (checkSupport && !await client.supportsDT()) throw new tt.DTUnsupportedError(`${feature} at round ${round} needs a time-travel algod (EnableTimeTravel), but the node does not support it`, { requestedRound: BigInt(round) });
	return client;
}
//#endregion
export { DTNotAvailableError, PROTOCOL_NOTE_ORDER, REQUIRED_DT_FEATURES, chunk, concurrencyLimiter, dtAlgodForRead, fetchOptions, getDTSdk, getQueryLimits, getSimulateLimits, isDTUnsupportedError, mapConcurrently, mapProtocolOverrideHits, mergeProtocolOverrides, offsetProtocolOverride, requireDTSdk, requireDTSdkFeatures, toDTAlgod, txIdsOf };

//# sourceMappingURL=dt-support.mjs.map