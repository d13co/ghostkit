Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/types/dt-support.ts
/**
* Runtime support for dtalgod (a time-travel algod) through the time-travel fork of algosdk.
*
* algokit-utils keeps working with stock algosdk: the fork's `DTAlgodClient` is looked up at runtime, and
* the features that need it throw a {@link DTNotAvailableError} when it isn't there. The types below describe
* the parts of the fork that algokit-utils uses, in terms of stock algosdk types, so that the published declarations
* never reference the fork.
*/
/** The `DTAlgodClient.features` that algokit-utils needs. */
const REQUIRED_DT_FEATURES = Object.freeze([
	"reads-at-round",
	"versions",
	"simulate-groups",
	"parallel-groups",
	"simulate-rounds",
	"from",
	"group-results",
	"from-transactions",
	"pack-rounds"
]);
/** Thrown when a time travel or extended simulate feature is used but the loaded algosdk is not the time-travel fork, or a version without it. */
var DTNotAvailableError = class extends Error {
	/**
	* @param feature The feature that was used, for the message
	* @param missing The optional features that a loaded fork lacks, if the fork is loaded but too old
	*/
	constructor(feature, missing = []) {
		super(missing.length > 0 ? `${feature} needs a newer version of the time-travel fork of algosdk: the loaded one does not have the DTAlgodClient features ${missing.join(", ")}. Install a newer fork and make sure the app loads a single copy of algosdk.` : `${feature} needs the time-travel fork of algosdk (with DTAlgodClient features ${REQUIRED_DT_FEATURES.join(", ")}), but the loaded algosdk does not have it. Install the fork and make sure the app loads a single copy of algosdk.`);
		this.name = "DTNotAvailableError";
	}
};
const sdk = algosdk.default;
/** Returns the parts of the time-travel fork of algosdk that algokit-utils uses, or `undefined` with stock algosdk. */
function getDTSdk() {
	const features = sdk.DTAlgodClient?.features;
	if (!features || !REQUIRED_DT_FEATURES.every((f) => features.includes(f))) return void 0;
	if (!sdk.packSimulateRounds || !sdk.dtModels?.DTSimulateRequest?.fromTransactions) return void 0;
	return sdk;
}
/** Returns the parts of the time-travel fork of algosdk that algokit-utils uses, or throws a {@link DTNotAvailableError}. */
function requireDTSdk(feature) {
	const tt = getDTSdk();
	if (!tt) throw new DTNotAvailableError(feature);
	return tt;
}
/**
* Like {@link requireDTSdk}, but also needs the given optional `DTAlgodClient.features` of a later version of the fork.
* @throws DTNotAvailableError if the loaded algosdk is not the time-travel fork, or a version without these features
*/
function requireDTSdkFeatures(feature, optional) {
	const tt = requireDTSdk(feature);
	const features = tt.DTAlgodClient.features ?? [];
	const missing = optional.filter((f) => !features.includes(f));
	if (missing.length > 0) throw new DTNotAvailableError(feature, missing);
	return tt;
}
/**
* Returns a time-travel algod client that shares the connection (server, token, headers and HTTP client) of the given
* algod client. The same client is returned for the same `algod`, so its cached time travel probe is kept.
*
* @param algod The algod client to share the connection of
* @param feature The feature that needs the client, for the error message
* @throws DTNotAvailableError if the loaded algosdk is not the time-travel fork
*/
function toDTAlgod(algod, feature = "This feature") {
	return requireDTSdk(feature).DTAlgodClient.from(algod);
}
/**
* Returns whether an error is the fork's `DTUnsupportedError`: the node answered without time travel, or for a
* different round than the one asked for.
*/
function isDTUnsupportedError(error) {
	const ctor = sdk.DTUnsupportedError;
	return ctor !== void 0 && error instanceof ctor || error instanceof Error && error.name === "DTUnsupportedError";
}
/**
* Returns a time-travel algod client for a read at a past round, after checking that the node supports time travel
* when `checkSupport` is set. Use `checkSupport` for reads whose response has no round to check, such as asset and
* application lookups, so that a stock node can't silently answer with the latest state.
*/
async function dtAlgodForRead(algod, feature, round, checkSupport) {
	const tt = requireDTSdk(feature);
	const client = tt.DTAlgodClient.from(algod);
	if (checkSupport && !await client.supportsDT()) throw new tt.DTUnsupportedError(`${feature} at round ${round} needs a time-travel algod (EnableTimeTravel), but the node does not support it`, { requestedRound: BigInt(round) });
	return client;
}
//#endregion
exports.DTNotAvailableError = DTNotAvailableError;
exports.REQUIRED_DT_FEATURES = REQUIRED_DT_FEATURES;
exports.dtAlgodForRead = dtAlgodForRead;
exports.getDTSdk = getDTSdk;
exports.isDTUnsupportedError = isDTUnsupportedError;
exports.requireDTSdk = requireDTSdk;
exports.requireDTSdkFeatures = requireDTSdkFeatures;
exports.toDTAlgod = toDTAlgod;

//# sourceMappingURL=dt-support.js.map