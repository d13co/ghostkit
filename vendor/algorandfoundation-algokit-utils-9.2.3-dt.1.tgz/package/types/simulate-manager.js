Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.js");
const require_transaction = require("../transaction/transaction.js");
const require_dt_support = require("./dt-support.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
let buffer = require("buffer");
//#region src/types/simulate-manager.ts
/** The default most groups per simulate request (dtalgod's `MaxAPISimulateGroups` default). */
const DEFAULT_MAX_SIMULATE_GROUPS = 16;
/** The default most rounds per simulate request (dtalgod's `MaxAPISimulateRounds` default). */
const DEFAULT_MAX_SIMULATE_ROUNDS = 16;
/** The optional fork features that the options need, after checking `validityWindow`. */
const optionalFeatures = (options) => {
	const { validityWindow } = options;
	if (validityWindow !== void 0 && validityWindow !== "skip" && validityWindow !== "rewrite") throw new Error(`validityWindow must be 'skip' or 'rewrite', not ${JSON.stringify(validityWindow)}`);
	return [...validityWindow ? ["validity-window"] : [], ...options.protocol ? ["simulate-protocol"] : []];
};
/** The order the node lists protocol notes in; codes it adds later go after these. */
const PROTOCOL_NOTE_ORDER = [
	"semantics-changed",
	"no-heartbeat-challenges",
	"no-load-history",
	"block-incentive-fields",
	"block-hash-fields",
	"online-stake-includes-expired",
	"account-incentive-fields",
	"app-version-starts-at-upgrade"
];
const chunk = (items, size) => {
	const chunks = [];
	for (let i = 0; i < items.length; i += size) chunks.push(items.slice(i, i + size));
	return chunks;
};
/** Turns a successful group result into the same shape as `TransactionComposer.simulate` returns. */
function toGroupResult(built, group, simulateResponse) {
	const { transactions, methodCalls } = built;
	const confirmations = group.txnResults.map((t) => t.txnResult);
	const returns = [...methodCalls.entries()].map(([index, method]) => require_transaction.getABIReturnValue(algosdk.default.AtomicTransactionComposer.parseMethodResponse(method, {
		txID: transactions[index].txID(),
		rawReturnValue: /* @__PURE__ */ new Uint8Array(),
		method
	}, confirmations[index]), method.returns.type));
	return {
		confirmations,
		transactions,
		txIds: transactions.map((t) => t.txID()),
		groupId: buffer.Buffer.from(transactions[0].group ?? /* @__PURE__ */ new Uint8Array()).toString("base64"),
		simulateResponse,
		returns
	};
}
function toOutcome(raw, groupIndex, built, response, protocolOverride) {
	const base = {
		groupIndex,
		round: raw.round,
		...protocolOverride ? { protocolOverride } : {}
	};
	return raw.ok ? {
		...base,
		ok: true,
		result: toGroupResult(built, raw.result, response)
	} : {
		...base,
		ok: false,
		error: raw.error
	};
}
/** The protocol override of one request at one round, with the notes' group indexes moved by `offset` (the request's first group). */
function protocolOverrideAt(response, roundIndex, offset) {
	const o = roundIndex === void 0 ? response.protocolOverride : response.roundResults?.[roundIndex]?.protocolOverride;
	if (!o || !o.notes || offset === 0) return o;
	return {
		...o,
		notes: o.notes.map((n) => n.hits ? {
			...n,
			hits: n.hits.map((h) => ({
				...h,
				group: h.group + offset
			}))
		} : n)
	};
}
/** Merges the protocol overrides of the requests that parallel groups were split across, at the same round. */
function mergeProtocolOverrides(overrides) {
	const present = overrides.filter((o) => o !== void 0);
	if (present.length <= 1) return present[0];
	const notes = [];
	for (const n of present.flatMap((o) => o.notes ?? [])) {
		const same = notes.find((m) => m.code === n.code && m.message === n.message);
		if (!same) notes.push({
			...n,
			...n.hits ? { hits: [...n.hits] } : {}
		});
		else if (n.hits) same.hits = [...same.hits ?? [], ...n.hits];
	}
	const rank = (code) => PROTOCOL_NOTE_ORDER.includes(code) ? PROTOCOL_NOTE_ORDER.indexOf(code) : PROTOCOL_NOTE_ORDER.length;
	notes.sort((a, b) => rank(a.code) - rank(b.code));
	return {
		from: present[0].from,
		to: present[0].to,
		applied: present.some((o) => o.applied),
		...notes.length ? { notes } : {}
	};
}
/**
* Extended simulate on dtalgod: several transaction groups in one request (one after the other in one block, or in
* parallel), and the same groups at several rounds in one request.
*
* The groups are simulated without signatures (like `simulate({ skipSignatures: true })`), so this is for reads and
* dry runs. Needs the time-travel fork of algosdk (without it, every method throws a `DTNotAvailableError`)
* and dtalgod (a stock node throws the fork's `DTUnsupportedError`).
*/
var SimulateManager = class {
	_clientManager;
	/**
	* Create a new simulate manager.
	* @param clientManager The `ClientManager` client to use for algod
	*/
	constructor(clientManager) {
		this._clientManager = clientManager;
	}
	/**
	* Simulates several transaction groups in one request, at the latest round or at a past `round`.
	*
	* By default the groups run one after the other in one block: later groups see the effects of earlier ones, and a
	* failed group is rolled back without stopping the later ones. With `parallel`, each group runs on its own against
	* the starting state.
	*
	* @param composers The groups, one composer each
	* @param options The simulate options
	* @returns The outcome of each group, in order
	* @example
	* ```typescript
	* const [a, b] = await algorand.simulate.groups([algorand.newGroup().addPayment(...), algorand.newGroup().addAppCallMethodCall(...)], {
	*   allowUnnamedResources: true,
	* })
	* if (b.ok) console.log(b.result.returns?.[0]?.returnValue)
	* ```
	*/
	async groups(composers, options) {
		const { round, ...rest } = options ?? {};
		const validity = round ? {
			firstValidRound: BigInt(round) + 1n,
			lastValidRound: BigInt(round) + 11n
		} : void 0;
		const built = await this.buildGroups(composers, validity);
		const [outcomes] = await this.send(built, rest, { round });
		return outcomes.groups;
	}
	/**
	* Simulates the same transaction groups at several past rounds, in as few requests as the node's limits allow.
	*
	* The rounds are packed into windows of at most `maxRounds` rounds that span at most 1,000 rounds, and the groups are
	* built again for each window, valid at its rounds; transactions that set their own `firstValidRound` /
	* `lastValidRound` keep them. The windows are sent in parallel. With `validityWindow`, a window can span any number of
	* rounds: the groups are built valid from its first round for at most 1,000 rounds, and the node moves (`rewrite`) or
	* ignores (`skip`) that validity window at the later rounds.
	*
	* @param composers The groups, one composer each (or a single composer)
	* @param rounds The rounds to simulate at (each > 0): the state as of the end of each round
	* @param options The simulate options
	* @returns The outcomes at each round, in the order of `rounds`
	* @example
	* ```typescript
	* const composer = algorand.newGroup().addAppCallMethodCall(await appClient.params.call({ method: 'get_price' }))
	* const prices = await algorand.simulate.rounds(composer, [45_000_000n, 45_001_000n, 45_002_000n], { allowUnnamedResources: true })
	* for (const { round, groups: [g] } of prices) if (g.ok) console.log(round, g.result.returns?.[0]?.returnValue)
	*
	* // Years apart, under today's rules
	* const now = await algorand.simulate.rounds(composer, [20_000_000n, 45_000_000n], { validityWindow: 'rewrite', protocol: 'latest' })
	* for (const { round, protocolOverride } of now) console.log(round, protocolOverride?.from, '->', protocolOverride?.to)
	* ```
	*/
	async rounds(composers, rounds, options) {
		const { maxRounds = 16, ...rest } = options ?? {};
		const groups = Array.isArray(composers) ? composers : [composers];
		if (rounds.length === 0) return [];
		const { windows, positions } = require_dt_support.requireDTSdkFeatures("Simulating at several rounds", optionalFeatures(rest)).packSimulateRounds(rounds, {
			maxRounds,
			...rest.validityWindow ? { maxSpan: null } : {}
		});
		const builtWindows = [];
		for (const w of windows) builtWindows.push(await this.buildGroups(groups, {
			firstValidRound: w.firstValid,
			lastValidRound: w.lastValid
		}));
		const results = await Promise.all(windows.map((w, i) => this.send(builtWindows[i], rest, { rounds: w.rounds })));
		return positions.map(({ window, roundIndex }, i) => {
			const { groups, protocolOverride } = results[window][roundIndex];
			return {
				round: BigInt(rounds[i]),
				groups,
				...protocolOverride ? { protocolOverride } : {}
			};
		});
	}
	async buildGroups(composers, validity) {
		if (composers.length === 0) throw new Error("No transaction groups to simulate");
		const built = [];
		for (const composer of composers) {
			const b = validity ? await composer.buildTransactionsWithValidity(validity) : await composer.buildTransactions();
			if (b.transactions.length === 0) throw new Error(`Transaction group ${built.length} is empty`);
			if (b.transactions.length > 1) b.transactions.forEach((t) => t.group = void 0);
			built.push(b);
		}
		return built;
	}
	/** Sends the groups (split into requests if parallel), returning the outcomes per round of the request (one round without `rounds`). */
	async send(built, options, at) {
		const tt = require_dt_support.requireDTSdkFeatures("Simulating several groups", optionalFeatures(options));
		const { parallel = false, maxGroups = 16, protocol, validityWindow, ...raw } = options;
		if (!parallel && built.length > maxGroups) throw new Error(`Can't simulate ${built.length} groups one after the other: the node takes at most ${maxGroups} per request (set maxGroups if the node allows more, or use parallel)`);
		const chunks = parallel ? chunk(built, maxGroups) : [built];
		const algod = this._clientManager.dtAlgod;
		let round = at.round || void 0;
		if (chunks.length > 1 && !round && !at.rounds) round = (await this._clientManager.algod.status().do()).lastRound;
		const responses = await Promise.all(chunks.map(async (groups) => {
			const request = tt.dtModels.DTSimulateRequest.fromTransactions(groups.map((g) => g.transactions), {
				...raw,
				allowEmptySignatures: true,
				fixSigners: true,
				parallelGroups: parallel || void 0,
				round
			});
			let call = algod.simulateTransactions(request);
			if (at.rounds) call = call.rounds(at.rounds);
			if (validityWindow === "skip") call = call.skipValidityWindow();
			if (validityWindow === "rewrite") call = call.rewriteValidityWindow();
			if (protocol) call = call.protocol(protocol);
			return await call.do();
		}));
		const offsets = chunks.map((_, c) => chunks.slice(0, c).reduce((n, g) => n + g.length, 0));
		return Array.from({ length: at.rounds ? at.rounds.length : 1 }, (_, roundIndex) => {
			const overrides = responses.map((response, c) => protocolOverrideAt(response, at.rounds ? roundIndex : void 0, offsets[c]));
			const protocolOverride = mergeProtocolOverrides(overrides);
			return {
				groups: chunks.flatMap((groups, c) => {
					const response = responses[c];
					return response.groupResults(groups.length)[roundIndex].map((raw, g) => toOutcome(raw, offsets[c] + g, groups[g], response, overrides[c] && protocolOverride));
				}),
				...protocolOverride ? { protocolOverride } : {}
			};
		});
	}
};
//#endregion
exports.DEFAULT_MAX_SIMULATE_GROUPS = DEFAULT_MAX_SIMULATE_GROUPS;
exports.DEFAULT_MAX_SIMULATE_ROUNDS = DEFAULT_MAX_SIMULATE_ROUNDS;
exports.SimulateManager = SimulateManager;

//# sourceMappingURL=simulate-manager.js.map