Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.js");
const require_transaction = require("../transaction/transaction.js");
const require_dt_support = require("./dt-support.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/types/simulate-manager.ts
/** The most simulate requests in flight at once, by default. */
const DEFAULT_SIMULATE_CONCURRENCY = 4;
/** Throws for a `validityWindow` other than `skip` or `rewrite`. Shared with `QueryManager`, which validates the same options. */
const checkValidityWindow = ({ validityWindow }) => {
	if (validityWindow !== void 0 && validityWindow !== "skip" && validityWindow !== "rewrite") throw new Error(`validityWindow must be 'skip' or 'rewrite', not ${JSON.stringify(validityWindow)}`);
};
/** The validity window of transactions simulated at `round` (none for the latest round). */
const validityAt = (round) => round ? {
	firstValidRound: BigInt(round) + 1n,
	lastValidRound: BigInt(round) + 11n
} : void 0;
/**
* Checks extended simulate options against the limits the node reported, throwing for what it doesn't allow. Shared with
* `QueryManager`, which validates the same options.
*/
function checkSimulateLimits(limits, protocol, raw) {
	if (!limits.developerApi) {
		if (protocol === "future") throw new Error("protocol 'future' needs a node with the developer API (EnableDeveloperAPI), and this node has it off");
		if (raw.execTraceConfig?.enable) throw new Error("execTraceConfig needs a node with the developer API (EnableDeveloperAPI), and this node has it off");
	}
	const { extraOpcodeBudget } = raw;
	if (extraOpcodeBudget !== void 0 && BigInt(extraOpcodeBudget) > BigInt(limits.maxExtraOpcodeBudget)) throw new Error(`extraOpcodeBudget ${extraOpcodeBudget} is more than the node allows (maxExtraOpcodeBudget ${limits.maxExtraOpcodeBudget})`);
}
/** The `concurrency` option, checked: a positive integer, or the default. */
function checkConcurrency(concurrency) {
	if (concurrency === void 0) return 4;
	if (!Number.isInteger(concurrency) || concurrency < 1) throw new RangeError(`concurrency must be a positive integer, not ${concurrency}`);
	return concurrency;
}
/** Turns a successful group result into the same shape as `TransactionComposer.simulate` returns. */
function toGroupResult(built, group, simulateResponse) {
	const { transactions, methodCalls } = built;
	const { groupId, txIds } = require_dt_support.txIdsOf(built);
	const confirmations = group.txnResults.map((t) => t.txnResult);
	const returns = [...methodCalls.entries()].map(([index, method]) => require_transaction.getABIReturnValue(algosdk.default.AtomicTransactionComposer.parseMethodResponse(method, {
		txID: txIds[index],
		rawReturnValue: /* @__PURE__ */ new Uint8Array(),
		method
	}, confirmations[index]), method.returns.type));
	return {
		confirmations,
		transactions,
		txIds: [...txIds],
		groupId,
		simulateResponse,
		returns
	};
}
function toOutcome(raw, groupIndex, built, response, protocolOverride) {
	const base = {
		groupIndex,
		round: raw.round,
		...protocolOverride ? { protocolOverride } : {}
	};
	return raw.ok ? {
		...base,
		ok: true,
		result: toGroupResult(built, raw.result, response)
	} : {
		...base,
		ok: false,
		error: raw.error
	};
}
/** The protocol override of one request at one round, with the notes' group indexes moved by `offset` (the request's first group). */
function protocolOverrideAt(response, roundIndex, offset) {
	return require_dt_support.offsetProtocolOverride(roundIndex === void 0 ? response.protocolOverride : response.roundResults?.[roundIndex]?.protocolOverride, offset);
}
/**
* Extended simulate on dtalgod: several transaction groups in one request (one after the other in one block, or in
* parallel), and the same groups at several rounds in one request.
*
* The groups are simulated without signatures (like `simulate({ skipSignatures: true })`), so this is for reads and
* dry runs. Needs dtalgosdk (without it, every method throws a `DTNotAvailableError`) and dtalgod: on stock algod,
* `groups` and `rounds` throw dtalgosdk's `DTUnsupportedError` before sending anything. The node's limits, which tell
* the two apart, are asked for once per algod client.
*/
var SimulateManager = class {
	_clientManager;
	/**
	* Create a new simulate manager.
	* @param clientManager The `ClientManager` client to use for algod
	*/
	constructor(clientManager) {
		this._clientManager = clientManager;
	}
	/**
	* Simulates several transaction groups in one request, at the latest round or at a past `round`.
	*
	* The node's limits (see `limits()`) apply: at most `maxTxnGroups` groups per request, and an `extraOpcodeBudget` above
	* `maxExtraOpcodeBudget` throws.
	*
	* By default the groups run one after the other in one block: later groups see the effects of earlier ones, and a
	* failed group is rolled back without stopping the later ones. With `parallel`, each group runs on its own against
	* the starting state.
	*
	* @param composers The groups, one composer each
	* @param options The simulate options
	* @returns The outcome of each group, in order
	* @example
	* ```typescript
	* const [a, b] = await algorand.simulate.groups([algorand.newGroup().addPayment(...), algorand.newGroup().addAppCallMethodCall(...)], {
	*   allowUnnamedResources: true,
	* })
	* if (b.ok) console.log(b.result.returns?.[0]?.returnValue)
	* ```
	*/
	async groups(composers, options) {
		const { round, ...rest } = options ?? {};
		require_dt_support.requireDTSdk("Simulating several groups");
		checkValidityWindow(rest);
		rest.signal?.throwIfAborted();
		const limits = await require_dt_support.requireDTNode(this._clientManager.algod, "Simulating several groups");
		const limit = require_dt_support.concurrencyLimiter(checkConcurrency(rest.concurrency));
		const built = await this.buildGroups(composers, validityAt(round));
		const [outcomes] = await this.send(built, rest, { round }, limits, limit);
		return outcomes.groups;
	}
	/**
	* Returns the node's simulate limits: how many groups and `rounds` entries a request may hold, the most
	* `extraOpcodeBudget`, and whether time travel and the developer API are on. `groups` and `rounds` keep to them.
	*
	* Every dtalgod node reports them. Stock algod, which has no limits endpoint, gets stock algod's limits, with
	* `reported` false: `reported` is how to tell dtalgod from stock algod. The limits are asked for once per algod client.
	*
	* @returns The node's simulate limits
	* @throws DTNotAvailableError if the loaded algosdk is not dtalgosdk
	* @example
	* ```typescript
	* const { maxTxnGroups, maxRounds, reported } = await algorand.simulate.limits()
	* ```
	*/
	async limits() {
		require_dt_support.requireDTSdk("Reading the simulate limits");
		return await require_dt_support.getSimulateLimits(this._clientManager.algod);
	}
	/**
	* Simulates the same transaction groups at several past rounds, in as few requests as the node's limits allow.
	*
	* The rounds are packed into windows of at most `maxRounds` rounds that span at most 1,000 rounds, and the groups are
	* built again for each window, valid at its rounds; transactions that set their own `firstValidRound` /
	* `lastValidRound` keep them. The windows are sent in parallel. With `validityWindow`, a window can span any number of
	* rounds: the groups are built valid from its first round for at most 1,000 rounds, and the node moves (`rewrite`) or
	* ignores (`skip`) that validity window at the later rounds.
	*
	* `maxRounds` defaults to the node's limit (see `limits()`). On a node with `rounds` disabled, each round is its own
	* request.
	*
	* @param composers The groups, one composer each (or a single composer)
	* @param rounds The rounds to simulate at (each > 0): the state as of the end of each round
	* @param options The simulate options
	* @returns The outcomes at each round, in the order of `rounds`
	* @example
	* ```typescript
	* const composer = algorand.newGroup().addAppCallMethodCall(await appClient.params.call({ method: 'get_price' }))
	* const prices = await algorand.simulate.rounds(composer, [45_000_000n, 45_001_000n, 45_002_000n], { allowUnnamedResources: true })
	* for (const { round, groups: [g] } of prices) if (g.ok) console.log(round, g.result.returns?.[0]?.returnValue)
	*
	* // Years apart, under today's rules
	* const now = await algorand.simulate.rounds(composer, [20_000_000n, 45_000_000n], { validityWindow: 'rewrite', protocol: 'latest' })
	* for (const { round, protocolOverride } of now) console.log(round, protocolOverride?.from, '->', protocolOverride?.to)
	* ```
	*/
	async rounds(composers, rounds, options) {
		const { maxRounds: maxRoundsOption, ...rest } = options ?? {};
		const groups = Array.isArray(composers) ? composers : [composers];
		if (rounds.length === 0) return [];
		const tt = require_dt_support.requireDTSdk("Simulating at several rounds");
		checkValidityWindow(rest);
		const limit = require_dt_support.concurrencyLimiter(checkConcurrency(rest.concurrency));
		rest.signal?.throwIfAborted();
		const limits = await require_dt_support.requireDTNode(this._clientManager.algod, "Simulating at several rounds");
		const maxRounds = maxRoundsOption ?? limits.maxRounds;
		if (maxRounds === 0) return await this.roundByRound(groups, rounds, rest, limits, limit);
		const { windows, positions } = tt.packSimulateRounds(rounds, {
			maxRounds,
			...rest.validityWindow ? { maxSpan: null } : {}
		});
		const builtWindows = [];
		for (const w of windows) builtWindows.push(await this.buildGroups(groups, {
			firstValidRound: w.firstValid,
			lastValidRound: w.lastValid
		}));
		const results = await Promise.all(windows.map((w, i) => this.send(builtWindows[i], rest, { rounds: w.rounds }, limits, limit)));
		return positions.map(({ window, roundIndex }, i) => {
			const { groups, protocolOverride } = results[window][roundIndex];
			return {
				round: BigInt(rounds[i]),
				groups,
				...protocolOverride ? { protocolOverride } : {}
			};
		});
	}
	/** Simulates the groups at each round in a request of its own, with `round` set: for a node with `rounds` disabled. */
	async roundByRound(composers, rounds, options, limits, limit) {
		const { validityWindow, ...rest } = options;
		const unique = [...new Set(rounds.map((r) => BigInt(r)))];
		const zero = unique.find((r) => r < 1n);
		if (zero !== void 0) throw new RangeError(`Can't simulate at round ${zero} in rounds: give past rounds (look the latest round up with status())`);
		const built = [];
		for (const r of unique) built.push(await this.buildGroups(composers, validityAt(r)));
		const results = await Promise.all(unique.map((r, i) => this.send(built[i], rest, { round: r }, limits, limit)));
		return rounds.map((r) => {
			const [{ groups, protocolOverride }] = results[unique.indexOf(BigInt(r))];
			return {
				round: BigInt(r),
				groups,
				...protocolOverride ? { protocolOverride } : {}
			};
		});
	}
	async buildGroups(composers, validity) {
		if (composers.length === 0) throw new Error("No transaction groups to simulate");
		const built = [];
		for (const composer of composers) {
			const b = validity ? await composer.buildTransactionsWithValidity(validity) : await composer.buildTransactions();
			if (b.transactions.length === 0) throw new Error(`Transaction group ${built.length} is empty`);
			if (b.transactions.length > 1) b.transactions.forEach((t) => t.group = void 0);
			built.push(b);
		}
		return built;
	}
	/** Sends the groups (split into requests if parallel), returning the outcomes per round of the request (one round without `rounds`). */
	async send(built, options, at, limits, limit) {
		const tt = require_dt_support.requireDTSdk("Simulating several groups");
		const { parallel = false, maxGroups: maxGroupsOption, protocol, validityWindow, signal, concurrency, ...raw } = options;
		signal?.throwIfAborted();
		const fetchOptions = signal ? { signal } : void 0;
		const maxGroups = maxGroupsOption ?? limits.maxTxnGroups;
		if (!Number.isInteger(maxGroups) || maxGroups < 1) throw new RangeError(`maxGroups must be a positive integer, not ${maxGroups}`);
		if (!parallel && built.length > maxGroups) throw new Error(`Can't simulate ${built.length} groups one after the other: ${maxGroupsOption === void 0 ? "the node takes" : "maxGroups allows"} at most ${maxGroups} per request (use parallel to split them across requests)`);
		checkSimulateLimits(limits, protocol, raw);
		const chunks = parallel ? require_dt_support.chunk(built, maxGroups) : [built];
		const algod = this._clientManager.dtAlgod;
		let round = at.round || void 0;
		if (chunks.length > 1 && !round && !at.rounds) round = (await this._clientManager.algod.status().do(void 0, fetchOptions)).lastRound;
		const responses = await Promise.all(chunks.map(async (groups) => {
			const request = tt.dtModels.DTSimulateRequest.fromTransactions(groups.map((g) => g.transactions), {
				...raw,
				allowEmptySignatures: true,
				fixSigners: true,
				parallelGroups: parallel && groups.length > 1 || void 0,
				round
			});
			let call = algod.simulateTransactions(request);
			if (at.rounds) call = call.rounds(at.rounds);
			if (validityWindow === "skip") call = call.skipValidityWindow();
			if (validityWindow === "rewrite") call = call.rewriteValidityWindow();
			if (protocol) call = call.protocol(protocol);
			return await limit(() => call.do(void 0, fetchOptions));
		}));
		const offsets = chunks.map((_, c) => chunks.slice(0, c).reduce((n, g) => n + g.length, 0));
		return Array.from({ length: at.rounds ? at.rounds.length : 1 }, (_, roundIndex) => {
			const overrides = responses.map((response, c) => protocolOverrideAt(response, at.rounds ? roundIndex : void 0, offsets[c]));
			const protocolOverride = require_dt_support.mergeProtocolOverrides(overrides);
			return {
				groups: chunks.flatMap((groups, c) => {
					const response = responses[c];
					return response.groupResults(groups.length)[roundIndex].map((raw, g) => toOutcome(raw, offsets[c] + g, groups[g], response, overrides[c] && protocolOverride));
				}),
				...protocolOverride ? { protocolOverride } : {}
			};
		});
	}
};
//#endregion
exports.DEFAULT_SIMULATE_CONCURRENCY = DEFAULT_SIMULATE_CONCURRENCY;
exports.SimulateManager = SimulateManager;
exports.checkSimulateLimits = checkSimulateLimits;
exports.checkValidityWindow = checkValidityWindow;

//# sourceMappingURL=simulate-manager.js.map