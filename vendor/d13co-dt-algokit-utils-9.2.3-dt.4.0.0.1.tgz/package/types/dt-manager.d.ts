import { Address } from 'algosdk';
import { AccountInformation } from './account';
import { AppState, BoxName } from './app';
import { AppInformation, BoxIdentifier } from './app-manager';
import { AssetInformation } from './asset-manager';
import { ClientManager } from './client-manager';
import { AccountVersionsExclude, Round, VersionsOrder } from './dt-support';
/**
 * The most rounds an iterator sends in one `rounds` request, by default: about 4.5 KB of URL for 8-digit rounds, under
 * the 8 KB request line many proxies allow.
 */
export declare const DEFAULT_MAX_VERSIONS_ROUNDS_PER_REQUEST = 500;
/** Options for a `/versions` listing. */
export interface VersionsOptions {
    /** Include versions at this round or later (inclusive). Defaults to 0. Not with `rounds`. */
    minRound?: Round;
    /** Include versions at this round or earlier (inclusive). Defaults to the latest round. A page with an explicit `maxRound` never changes. Not with `rounds`. */
    maxRound?: Round;
    /**
     * List the object as of each of these rounds instead of its versions in a range: one entry per distinct round, for the
     * state at the end of that round, with `changedRound`, the round of the change in effect then.
     *
     * - Entries come in `order` (ascending by default), not in the order given: match them by `round`.
     * - An entry with `deleted: true` and no `changedRound` means the object did not exist then.
     * - **Round 0 is the genesis round here**, unlike `algorand.simulate.rounds` and `algorand.query.*`, where 0 is the latest round.
     * - Not with `minRound` / `maxRound`; `limit` counts rounds.
     * - A page sends the rounds as given, in one request (at most 10,000). The iterators split them into requests of
     *   `min(limit, maxRoundsPerRequest)` rounds, so long lists stay under URL length limits: prefer them for long lists.
     */
    rounds?: readonly Round[];
    /**
     * Iterators only: the most `rounds` sent in one request, default {@link DEFAULT_MAX_VERSIONS_ROUNDS_PER_REQUEST} (500).
     * Each request sends at most `limit` rounds too.
     */
    maxRoundsPerRequest?: number;
    /** Oldest first (`asc`, the default) or newest first (`desc`). For the last N changes use `order: 'desc', limit: N`. */
    order?: VersionsOrder;
    /**
     * The most versions per page (rounds per page with `rounds`): default 100, at most 10,000, or 1,000 with
     * `includeValues` or `includeKeys`. Pages also end at 1 MB of values (and on the node's other budgets), so they can be
     * short or empty: only a missing `nextToken` means the end. Pass tokens back to the same node.
     */
    limit?: number;
    /** Include the value of each version (box values, app params, asset params, account objects). */
    includeValues?: boolean;
    /**
     * Aborts the listing: passed to fetch for every page request. An iterator stops at the abort, even within a page, and
     * throws the signal's reason without sending more requests.
     */
    signal?: AbortSignal;
}
/** Options for one page of a `/versions` listing. */
export interface VersionsPageOptions extends VersionsOptions {
    /** The `nextToken` of the previous page, with the same other options. */
    next?: string;
}
/** Options for the `/versions` listings of application state: an app's (global), an account's and an account's in one app (local). */
export interface AppStateVersionsOptions {
    /**
     * Include `changedKeys`, the state keys each version of global or local state changed (added, removed or given a new
     * value, net over the round), sorted, as bytes.
     */
    includeKeys?: boolean;
}
/** Options for the versions of an app's global state, or of an account's local state in one app, that can follow one state key. */
export interface KeyVersionsOptions extends AppStateVersionsOptions {
    /**
     * List only the versions at which this state key changed (added, removed, or a new value or type, net over the round),
     * each with `keyValue`, the key's value after it. A string is UTF-8; at most 64 bytes, and an empty key is valid. On
     * `get/iterateAppVersions` it is a global state key; on `get/iterateAccountAppVersions` a local state key, and the
     * entries then hold only the local state. Not with `rounds`.
     *
     * The node examines a bounded number of versions per page, so pages can be short or empty and still have a
     * `nextToken`: keep paging until it is absent (the iterators do). Needs dtalgosdk 3.9.0-dt.3.0.0.1 or later (its `versions-pages` feature).
     */
    key?: string | Uint8Array;
}
/** Options for an app's box change feed (`get/iterateBoxesVersions`). */
export interface BoxesVersionsOptions {
    /**
     * List only the changes of the boxes whose names start with this prefix, such as one ARC-56 box map. A string is
     * UTF-8; at most 64 bytes. An empty prefix means no filter. In a range, rounds in which none of them changed are left
     * out; with `rounds`, every round has an entry, possibly with no boxes, and only the boxes under the prefix count
     * toward the node's per-round box limit.
     *
     * The node steps through the app's box index, so pages can be short or empty and still have a `nextToken`: keep paging
     * until it is absent (the iterators do). Needs dtalgosdk 3.9.0-dt.3.0.0.1 or later (its `versions-pages` feature).
     */
    prefix?: string | Uint8Array;
}
/** Options for an account `/versions` listing. */
export interface AccountVersionsOptions {
    /** Leave out sub-objects: `all` lists only base account changes; `created-apps-params` / `created-assets-params` leave out the params of created apps / assets. */
    exclude?: AccountVersionsExclude[];
}
/** A page of a `/versions` listing. */
export interface VersionsPage<T> {
    /** The last round the listing covers: `maxRound`, or the latest round when it isn't set. */
    round: bigint;
    /** The versions on this page. */
    versions: T[];
    /** Pass as `next` to get the next page; `undefined` on the last page. */
    nextToken?: string;
}
/** An account that holds an asset. */
export interface AssetHolder {
    /** The account's address. */
    address: string;
    /** Its balance of the asset, in base units. Accounts opted in with a zero balance are listed. */
    amount: bigint;
    /** Whether its holding is frozen. */
    frozen: boolean;
}
/** A page of an asset's holders, in address order. */
export interface AssetHoldersPage {
    /** The round the holders are listed at: pass it as `round` with `next` for the following pages. */
    round: bigint;
    /** The holders on this page. */
    holders: AssetHolder[];
    /** Pass as `next` (with `round`) to get the next page; `undefined` on the last page. Pages can be short or empty and still have one. */
    nextToken?: string;
}
/** Options for listing an asset's holders. */
export interface AssetHoldersOptions {
    /** List the holders at this round. Defaults to the latest round. */
    round?: Round;
    /** Holders per page: default 1,000, at most 10,000. */
    limit?: number;
    /** Aborts the listing: passed to fetch for every page request. */
    signal?: AbortSignal;
}
/** Options for one page of an asset's holders. */
export interface AssetHoldersPageOptions extends AssetHoldersOptions {
    /** The `nextToken` of the previous page. Needs `round`: the previous page's `round`, so every page lists the same round. */
    next?: string;
}
/** A version of a box: its value as of the end of `round`. */
export interface BoxVersion {
    /** The round the box changed in. */
    round: bigint;
    /** The timestamp of that round's block, in seconds since the epoch. */
    timestamp: number;
    /** Whether the box was deleted in this round. */
    deleted: boolean;
    /** The box value after this round, with `includeValues` (and unless deleted). */
    value?: Uint8Array;
    /** With `rounds`: the round of the change in effect at `round`; undefined if the box did not exist then. */
    changedRound?: bigint;
}
/** A change to one box, in the app's box change feed. */
export interface BoxChange {
    /** The name of the box. */
    name: BoxName;
    /** Whether the box was deleted in this round. */
    deleted: boolean;
    /** The box value after this round, with `includeValues` (and unless deleted). */
    value?: Uint8Array;
    /** With `rounds`: the round of the box's change in effect at the entry's round. */
    changedRound?: bigint;
}
/** The boxes of an app that changed in one round. */
export interface BoxesVersion {
    /** The round the boxes changed in. */
    round: bigint;
    /** The timestamp of that round's block, in seconds since the epoch. */
    timestamp: number;
    /** The boxes that changed, in name order. */
    boxes: BoxChange[];
}
/** A decoded state value, as in {@link AppState}. */
export type AppStateValue = AppState[string];
/** A version of an app. */
export interface AppVersion {
    /** The round the app changed in. */
    round: bigint;
    /** The timestamp of that round's block, in seconds since the epoch. */
    timestamp: number;
    /** Whether the app was deleted in this round. */
    deleted: boolean;
    /** The app after this round, including its global state, with `includeValues` (and unless deleted). */
    app?: AppInformation;
    /** With `rounds`: the round of the change in effect at `round`; undefined if the app did not exist then. */
    changedRound?: bigint;
    /**
     * With `includeKeys`: the global state keys changed in this round, as bytes, sorted. `[]` when only other params
     * changed; undefined on deletions or when not asked for.
     */
    changedKeys?: Uint8Array[];
    /** With `key`: the key's value after this round; undefined when the key was removed or the app deleted. */
    keyValue?: AppStateValue;
}
/** A version of an asset. */
export interface AssetVersion {
    /** The round the asset changed in. */
    round: bigint;
    /** The timestamp of that round's block, in seconds since the epoch. */
    timestamp: number;
    /** Whether the asset was destroyed in this round. */
    deleted: boolean;
    /** The asset after this round, with `includeValues` (and unless deleted). */
    asset?: AssetInformation;
    /** With `rounds`: the round of the change in effect at `round`; undefined if the asset did not exist then. */
    changedRound?: bigint;
}
/** A version of an account: what changed in one round. Lists of objects that didn't change are left out. */
export interface AccountVersion {
    /** The round the account changed in. */
    round: bigint;
    /** The timestamp of that round's block, in seconds since the epoch. */
    timestamp: number;
    /** The account's base record (balance, status, ...), as `exclude: 'all'` account information, if it changed. */
    base?: {
        /** Whether the account was closed in this round. */
        deleted: boolean;
        /** The account after this round, with `includeValues` (and unless deleted). */
        account?: AccountInformation;
        /** With `rounds`: the round of the change in effect at the entry's round. */
        changedRound?: bigint;
    };
    /** Asset holdings that changed. */
    assets?: {
        assetId: bigint;
        /** Whether the account opted out of the asset in this round. */
        deleted: boolean;
        /** The holding after this round, with `includeValues` (and unless deleted). */
        holding?: {
            balance: bigint;
            frozen: boolean;
        };
        /** With `rounds`: the round of the change in effect at the entry's round. */
        changedRound?: bigint;
    }[];
    /** App local states that changed. */
    appsLocalState?: {
        appId: bigint;
        /** Whether the account opted out of (or cleared) the app in this round. */
        deleted: boolean;
        /** The local state after this round, with `includeValues` (and unless deleted). */
        state?: AppState;
        /** With `rounds`: the round of the change in effect at the entry's round. */
        changedRound?: bigint;
        /** With `includeKeys`: the local state keys changed in this round, as bytes, sorted (`[]` on none; undefined on deletions). */
        changedKeys?: Uint8Array[];
        /** With `key`: the local key's value after this round; undefined when the key was removed or the account opted out. */
        keyValue?: AppStateValue;
    }[];
    /** Assets created by the account that changed. */
    createdAssets?: {
        assetId: bigint;
        /** Whether the asset was destroyed in this round. */
        deleted: boolean;
        /** The asset after this round, with `includeValues` (and unless deleted or excluded). */
        asset?: AssetInformation;
        /** With `rounds`: the round of the change in effect at the entry's round. */
        changedRound?: bigint;
    }[];
    /** Apps created by the account that changed. */
    createdApps?: {
        appId: bigint;
        /** Whether the app was deleted in this round. */
        deleted: boolean;
        /** The app after this round, with `includeValues` (and unless deleted or excluded). */
        app?: AppInformation;
        /** With `rounds`: the round of the change in effect at the entry's round. */
        changedRound?: bigint;
        /** With `includeKeys`: the global state keys changed in this round (undefined on deletions, or with `exclude: ['created-apps-params']`). */
        changedKeys?: Uint8Array[];
    }[];
}
/**
 * Time travel on a time-travel algod (dtalgod with `EnableTimeTravel`): the rounds at which boxes, apps, assets and
 * accounts changed, with their values.
 *
 * Needs dtalgosdk (the time-travel fork of algosdk); without it every method throws a `DTNotAvailableError`. A node
 * without time travel (stock algod, or dtalgod with `EnableTimeTravel` off) throws dtalgosdk's `DTUnsupportedError`
 * before any request is sent; whether the node has time travel is read once per algod client, from its simulate limits.
 *
 * To read state at a past round, pass `{ round }` to the usual reads (`algorand.app.getGlobalState(appId, { round })`,
 * `algorand.account.getInformation(address, { round })`, ...) or use `appClient.atRound(round)`.
 */
export declare class DTManager {
    private _clientManager;
    /**
     * Create a new time travel manager.
     * @param clientManager The `ClientManager` client to use for algod
     */
    constructor(clientManager: ClientManager);
    private get algod();
    /**
     * Returns whether time travel can be used: the loaded algosdk is dtalgosdk and the node is dtalgod with time travel
     * on (`EnableTimeTravel`). It is read from the node's simulate limits, asked for once per algod client.
     * @returns Whether time travel is supported
     * @example
     * ```typescript
     * if (await algorand.dt.supported()) { ... }
     * ```
     */
    supported(): Promise<boolean>;
    /**
     * Returns a page of the versions of a box: the rounds at which it changed.
     * @param appId The ID of the app
     * @param name The name of the box
     * @param options The range, order, page size, whether to include values and the `next` token
     * @returns The page of versions
     * @example
     * ```typescript
     * const { versions } = await algorand.dt.getBoxVersions(appId, 'counter', { order: 'desc', limit: 10, includeValues: true })
     * ```
     */
    getBoxVersions(appId: bigint, name: BoxIdentifier | BoxName, options?: VersionsPageOptions): Promise<VersionsPage<BoxVersion>>;
    /**
     * Iterates over the versions of a box, following the pages.
     * @param appId The ID of the app
     * @param name The name of the box
     * @param options The range, order, page size and whether to include values
     * @returns The versions
     * @example
     * ```typescript
     * for await (const v of algorand.dt.iterateBoxVersions(appId, 'counter', { includeValues: true })) { ... }
     * ```
     */
    iterateBoxVersions(appId: bigint, name: BoxIdentifier | BoxName, options?: VersionsOptions): AsyncGenerator<BoxVersion>;
    /**
     * Returns a page of an app's box change feed: the rounds at which any of its boxes changed, with the boxes that
     * changed in each.
     * @param appId The ID of the app
     * @param options The range, order, page size, whether to include values and the `next` token
     * @returns The page of versions
     * @example
     * ```typescript
     * const { versions } = await algorand.dt.getBoxesVersions(appId, { minRound: 45_000_000n })
     * ```
     */
    getBoxesVersions(appId: bigint, options?: VersionsPageOptions & BoxesVersionsOptions): Promise<VersionsPage<BoxesVersion>>;
    /**
     * Iterates over an app's box change feed, following the pages.
     * @param appId The ID of the app
     * @param options The range, order, page size and whether to include values
     * @returns The versions
     * @example
     * ```typescript
     * for await (const { round, boxes } of algorand.dt.iterateBoxesVersions(appId)) { ... }
     * ```
     */
    iterateBoxesVersions(appId: bigint, options?: VersionsOptions & BoxesVersionsOptions): AsyncGenerator<BoxesVersion>;
    /**
     * Returns a page of the versions of an app (its params and global state).
     * @param appId The ID of the app
     * @param options The range, order, page size, whether to include values and the `next` token
     * @returns The page of versions
     * @example
     * ```typescript
     * const { versions } = await algorand.dt.getAppVersions(appId, { includeValues: true })
     * const counters = versions.map((v) => v.app?.globalState.counter?.value)
     * ```
     */
    getAppVersions(appId: bigint, options?: VersionsPageOptions & KeyVersionsOptions): Promise<VersionsPage<AppVersion>>;
    /**
     * Iterates over the versions of an app (its params and global state), following the pages.
     * @param appId The ID of the app
     * @param options The range, order, page size and whether to include values
     * @returns The versions
     * @example
     * ```typescript
     * for await (const v of algorand.dt.iterateAppVersions(appId, { includeValues: true })) { ... }
     * ```
     */
    iterateAppVersions(appId: bigint, options?: VersionsOptions & KeyVersionsOptions): AsyncGenerator<AppVersion>;
    /**
     * Returns a page of the versions of an asset (its params).
     * @param assetId The ID of the asset
     * @param options The range, order, page size, whether to include values and the `next` token
     * @returns The page of versions
     * @example
     * ```typescript
     * const { versions } = await algorand.dt.getAssetVersions(assetId, { includeValues: true })
     * ```
     */
    getAssetVersions(assetId: bigint, options?: VersionsPageOptions): Promise<VersionsPage<AssetVersion>>;
    /**
     * Iterates over the versions of an asset (its params), following the pages.
     * @param assetId The ID of the asset
     * @param options The range, order, page size and whether to include values
     * @returns The versions
     * @example
     * ```typescript
     * for await (const v of algorand.dt.iterateAssetVersions(assetId)) { ... }
     * ```
     */
    iterateAssetVersions(assetId: bigint, options?: VersionsOptions): AsyncGenerator<AssetVersion>;
    /**
     * Returns a page of the versions of an account: its base record, holdings, local states and created assets and apps.
     * @param address The address of the account
     * @param options The range, order, page size, whether to include values, what to exclude and the `next` token
     * @returns The page of versions
     * @example
     * ```typescript
     * const { versions } = await algorand.dt.getAccountVersions(address, { exclude: ['all'], includeValues: true })
     * const balances = versions.map((v) => v.base?.account?.balance)
     * ```
     */
    getAccountVersions(address: string | Address, options?: VersionsPageOptions & AccountVersionsOptions & AppStateVersionsOptions): Promise<VersionsPage<AccountVersion>>;
    /**
     * Iterates over the versions of an account, following the pages.
     * @param address The address of the account
     * @param options The range, order, page size, whether to include values and what to exclude
     * @returns The versions
     * @example
     * ```typescript
     * for await (const v of algorand.dt.iterateAccountVersions(address, { exclude: ['all'] })) { ... }
     * ```
     */
    iterateAccountVersions(address: string | Address, options?: VersionsOptions & AccountVersionsOptions & AppStateVersionsOptions): AsyncGenerator<AccountVersion>;
    /**
     * Returns a page of the versions of an account's holding of one asset.
     * @param address The address of the account
     * @param assetId The ID of the asset
     * @param options The range, order, page size, whether to include values and the `next` token
     * @returns The page of versions
     * @example
     * ```typescript
     * const { versions } = await algorand.dt.getAccountAssetVersions(address, assetId, { includeValues: true })
     * ```
     */
    getAccountAssetVersions(address: string | Address, assetId: bigint, options?: VersionsPageOptions): Promise<VersionsPage<AccountVersion>>;
    /**
     * Iterates over the versions of an account's holding of one asset, following the pages.
     * @param address The address of the account
     * @param assetId The ID of the asset
     * @param options The range, order, page size and whether to include values
     * @returns The versions
     * @example
     * ```typescript
     * for await (const v of algorand.dt.iterateAccountAssetVersions(address, assetId)) { ... }
     * ```
     */
    iterateAccountAssetVersions(address: string | Address, assetId: bigint, options?: VersionsOptions): AsyncGenerator<AccountVersion>;
    /**
     * Returns a page of the versions of an account's local state in one app (and of the app, if the account created it).
     * @param address The address of the account
     * @param appId The ID of the app
     * @param options The range, order, page size, whether to include values and the `next` token
     * @returns The page of versions
     * @example
     * ```typescript
     * const { versions } = await algorand.dt.getAccountAppVersions(address, appId, { includeValues: true })
     * ```
     */
    getAccountAppVersions(address: string | Address, appId: bigint, options?: VersionsPageOptions & KeyVersionsOptions): Promise<VersionsPage<AccountVersion>>;
    /**
     * Iterates over the versions of an account's local state in one app, following the pages.
     * @param address The address of the account
     * @param appId The ID of the app
     * @param options The range, order, page size and whether to include values
     * @returns The versions
     * @example
     * ```typescript
     * for await (const v of algorand.dt.iterateAccountAppVersions(address, appId)) { ... }
     * ```
     */
    iterateAccountAppVersions(address: string | Address, appId: bigint, options?: VersionsOptions & KeyVersionsOptions): AsyncGenerator<AccountVersion>;
    private accountVersionsRequest;
    /** Checks the options before anything is sent. */
    private check;
    private configure;
    private page;
    private iterate;
    /**
     * Returns a page of the accounts that hold an asset at a round, in address order. Needs dtalgod with time travel and
     * the asset holders index (`TimeTravelHoldersIndex`); otherwise dtalgosdk's `DTUnsupportedError`. An index still being
     * built is a 503 that is thrown at once (not retried). For every holder, prefer {@link iterateAssetHolders}.
     * @param assetId The ID of the asset
     * @param options The round, the page size, the `next` token (with the first page's `round`) and an abort signal
     * @returns The page of holders
     * @example
     * ```typescript
     * const first = await algorand.dt.getAssetHolders(assetId, { limit: 100 })
     * const second = first.nextToken
     *   ? await algorand.dt.getAssetHolders(assetId, { round: first.round, next: first.nextToken, limit: 100 })
     *   : undefined
     * ```
     */
    getAssetHolders(assetId: bigint, options?: AssetHoldersPageOptions): Promise<AssetHoldersPage>;
    /**
     * Iterates over the accounts that hold an asset at a round, in address order, following the pages, which all list the
     * first page's round.
     * @param assetId The ID of the asset
     * @param options The round, the page size and an abort signal
     * @returns The holders
     * @example
     * ```typescript
     * let held = 0n
     * for await (const h of algorand.dt.iterateAssetHolders(assetId, { round: 50_000_000n })) held += h.amount
     * ```
     */
    iterateAssetHolders(assetId: bigint, options?: AssetHoldersOptions): AsyncGenerator<AssetHolder>;
    /**
     * Checks that the node has time travel. Stock algod would answer some of these routes with errors of its own; a
     * dtalgod without the holders index rejects the holders request itself with a `DTUnsupportedError`.
     */
    private requireTimeTravel;
    private holdersRequest;
    /** The `key` filter of a listing, if any: checked, and set on the request as the node's `key` parameter. */
    private keyFilter;
    /** The `prefix` filter of a box change feed, if any: checked, and set on the request as the node's `prefix` parameter. */
    private prefixFilter;
    /**
     * The `rounds` of each request an iterator sends: the distinct rounds in `order`, in consecutive chunks of
     * `min(limit, maxRoundsPerRequest)`, so a request carries only the rounds its page can return and the URL stays short.
     * One request without `rounds` when there are none; none for an empty list.
     */
    private roundsChunks;
}
