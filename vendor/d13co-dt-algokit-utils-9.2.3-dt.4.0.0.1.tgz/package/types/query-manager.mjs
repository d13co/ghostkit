import { Config } from "../config.mjs";
import { getABIReturnValue } from "../transaction/transaction.mjs";
import { DTNotAvailableError, chunk, getDTSdk, getQueryLimits, getSimulateLimits, isDTUnsupportedError, mapProtocolOverrideHits, mergeProtocolOverrides, noQueryMessage, offsetProtocolOverride, requireDTNode, requireDTSdk, txIdsOf } from "./dt-support.mjs";
import { checkSimulateLimits, checkValidityWindow } from "./simulate-manager.mjs";
import algosdk from "algosdk";
//#region src/types/query-manager.ts
/** The most requests of a query in flight at once, by default. */
const DEFAULT_QUERY_CONCURRENCY = 4;
/** Room left in a request body for everything but the calls and the programs (keys, sender, schemas, budget, protocol). */
const QUERY_REQUEST_OVERHEAD_BYTES = 512;
/** The most bytes of a round in a request body (a msgpack uint64). */
const QUERY_ROUND_BYTES = 9;
/** The log bytes a transaction may have with simulate's `allowMoreLogging` (`simulation.LogBytesLimit`). */
const SIMULATE_MORE_LOGGING_BYTES = 65536;
/** The opcode budget of each app call of a group (`MaxAppProgramCost`), pooled. */
const APP_CALL_BUDGET = 700;
/** The failure of one call of a query at one round. */
var QueryCallError = class extends Error {
	/** Why the call has no result. */
	kind;
	/** The index of the call, in the order given. */
	callIndex;
	/** The round of the result: the state as of the end of this round. */
	round;
	/** The node's message, as it sent it. */
	failureMessage;
	/** What the call logged before it failed (none for `round`, or when the node returned no result for it). */
	logs;
	/** The opcode budget the call used before it failed, when the node returned it. */
	cost;
	constructor({ kind, callIndex, round, failureMessage, logs = [], cost }) {
		super(kind === "round" ? `Could not query round ${round}: ${failureMessage}` : `Query call ${callIndex} at round ${round} failed: ${failureMessage}`);
		this.name = "QueryCallError";
		this.kind = kind;
		this.callIndex = callIndex;
		this.round = round;
		this.failureMessage = failureMessage;
		this.logs = logs;
		this.cost = cost;
	}
};
/** The failure of a group at a round, from `algorand.query.groups` / `rounds`, on either path. */
var QueryGroupError = class extends Error {
	/** Why the group has no result. */
	kind;
	/** The index of the group, in the order the composers were given. */
	groupIndex;
	/** The round of the result. */
	round;
	/**
	* The node's message. For a logic error, as simulate words it: `transaction <TXID>: logic eval error: ...` (the query
	* path adds the prefix, with the ID of the transaction as built), so `LogicError` can parse it. A call that was too large
	* or too slow even alone has the node's message as it is.
	*/
	failureMessage;
	/** For `group`: the path of the transaction that failed (on the query path, its index in the group). */
	failedAt;
	/**
	* For `group`: the results of the group's transactions, with the failed one's `error`. On the query path every
	* transaction ran and has one; on the simulate path, the ones that ran before the failure.
	*/
	txns;
	constructor({ kind, groupIndex, round, failureMessage, failedAt, txns, cause }) {
		const where = `group ${groupIndex} at round ${round}`;
		let message;
		switch (kind) {
			case "round":
				message = `Could not query ${where}: ${failureMessage}`;
				break;
			case "not-simulated":
				message = `Did not query ${where}: ${failureMessage}`;
				break;
			case "missing":
				message = `The response has no result for ${where}`;
				break;
			default: message = `Querying ${where} failed${failedAt ? ` at transaction ${failedAt.join(".")}` : ""}: ${failureMessage}`;
		}
		super(message, cause !== void 0 ? { cause } : void 0);
		this.name = "QueryGroupError";
		this.kind = kind;
		this.groupIndex = groupIndex;
		this.round = round;
		this.failureMessage = failureMessage;
		this.failedAt = failedAt;
		this.txns = txns;
	}
};
/** The HTTP status of an algosdk request error. */
const errorStatus = (error) => {
	const e = error;
	const status = Number(e?.status ?? e?.response?.status);
	return Number.isNaN(status) ? void 0 : status;
};
/** The text of an algosdk request error: its message and the response body. */
const errorText = (error) => {
	const e = error;
	return `${e?.message ?? ""} ${e?.response?.text ?? ""}`;
};
/** The node's message of an algosdk request error (its JSON `message`), or the error's message. */
const nodeMessage = (error) => {
	const e = error;
	try {
		const { message } = JSON.parse(e?.response?.text ?? "");
		if (typeof message === "string" && message) return message;
	} catch {}
	return e?.message ?? String(error);
};
const checkPositiveInteger = (name, value) => {
	if (value !== void 0 && (!Number.isInteger(value) || value < 1)) throw new RangeError(`${name} must be a positive integer, not ${value}`);
};
/** The fork's query call for a call of a query. */
const toQueryCall = (call) => ({
	...call.args ? { args: call.args } : {},
	...call.accounts ? { accounts: call.accounts.map((a) => a.toString()) } : {},
	...call.foreignApps ? { foreignApps: call.foreignApps.map(BigInt) } : {},
	...call.foreignAssets ? { foreignAssets: call.foreignAssets.map(BigInt) } : {},
	...call.boxes ? { boxes: call.boxes.map((b) => ({
		app: BigInt(b.app),
		name: b.name
	})) } : {}
});
/**
* The requests of one top-level query call (`run`, or `groups` / `rounds` on the query path): splits the calls and rounds
* into requests within the node's limits, sends them with bounded concurrency, splits again what the node finds too large
* or too slow, and pins the latest round when it is queried in more than one request. The first error that isn't solved
* by splitting cancels the requests in flight and is thrown.
*/
var QueryRun = class {
	algod;
	dtAlgod;
	tt;
	limits;
	config;
	controller = new AbortController();
	failure;
	active = 0;
	waiting = [];
	pin;
	jobs = [];
	results = [];
	constructor(algod, dtAlgod, tt, limits, config) {
		this.algod = algod;
		this.dtAlgod = dtAlgod;
		this.tt = tt;
		this.limits = limits;
		this.config = config;
	}
	/** Runs the jobs, returning the results of each job by round (0 for the latest). */
	async execute(jobs) {
		const { signal } = this.config;
		signal?.throwIfAborted();
		const onAbort = () => this.controller.abort(signal.reason);
		signal?.addEventListener("abort", onAbort, { once: true });
		try {
			this.jobs = jobs;
			this.results = jobs.map((job) => new Map(job.rounds.map((r) => [r, {
				round: r,
				overrides: [],
				calls: new Array(job.calls.length)
			}])));
			const pieces = jobs.flatMap((job, j) => this.plan(job, j));
			if (pieces.filter((p) => p.rounds.includes(0n)).length > 1) this.pinLatest();
			await Promise.all(pieces.map((p) => this.send(p)));
			return this.results;
		} catch (error) {
			throw this.failure ? this.failure.error : error;
		} finally {
			signal?.removeEventListener("abort", onAbort);
		}
	}
	/** Splits a job into requests: rounds by `maxRounds`, calls by `maxCalls` and by the request body limit. */
	plan(job, j) {
		const roundsPerRequest = Math.max(1, Math.min(this.config.maxRounds, this.limits.maxRounds));
		const callsPerRequest = Math.max(1, Math.min(this.config.maxCalls, this.limits.maxCalls));
		const maxBody = this.tt.MAX_QUERY_REQUEST_BYTES;
		const { program, clearProgram } = job.target;
		const room = maxBody - (program?.length ?? 0) - (clearProgram?.length ?? 0) - QUERY_REQUEST_OVERHEAD_BYTES - QUERY_ROUND_BYTES * Math.min(roundsPerRequest, job.rounds.length);
		const callRanges = [];
		let start = 0;
		let bytes = 0;
		job.calls.forEach((call, i) => {
			const size = this.callSize(call);
			if (size > room) throw new Error(`Query call ${i} is too large to send: it takes about ${size} bytes, and the request has room for ${Math.max(0, room)}`);
			if (i - start >= callsPerRequest || bytes + size > room) {
				callRanges.push([start, i]);
				start = i;
				bytes = 0;
			}
			bytes += size;
		});
		callRanges.push([start, job.calls.length]);
		return chunk(job.rounds, roundsPerRequest).flatMap((rounds) => callRanges.map(([start, end]) => ({
			job: j,
			start,
			end,
			rounds
		})));
	}
	/** The encoded size of a call: exact with the fork's model, else an upper estimate. */
	callSize(call) {
		const QueryCall = this.tt.dtModels.QueryCall;
		if (QueryCall) return algosdk.encodeMsgpack(new QueryCall(call)).length;
		return 64 + (call.args ?? []).reduce((n, a) => n + a.length + 5, 0) + (call.accounts?.length ?? 0) * 64 + ((call.foreignApps?.length ?? 0) + (call.foreignAssets?.length ?? 0)) * 9 + (call.boxes ?? []).reduce((n, b) => n + b.name.length + 24, 0);
	}
	/** Resolves the latest round once, for the requests that query it. */
	pinLatest() {
		if (!this.pin) {
			this.pin = this.algod.status().do(void 0, { signal: this.controller.signal }).then((s) => s.lastRound);
			this.pin.catch(() => void 0);
		}
		return this.pin;
	}
	async acquire() {
		if (this.active < this.config.concurrency) {
			this.active++;
			return;
		}
		await new Promise((resolve) => this.waiting.push(resolve));
	}
	release() {
		const next = this.waiting.shift();
		if (next) next();
		else this.active--;
	}
	fail(error) {
		if (this.failure) return;
		this.failure = { error };
		this.controller.abort();
	}
	async send(piece) {
		const job = this.jobs[piece.job];
		let response;
		let failed = false;
		let error;
		await this.acquire();
		try {
			this.controller.signal.throwIfAborted();
			const latest = this.pin && piece.rounds.includes(0n) ? await this.pin : void 0;
			const rounds = latest === void 0 ? piece.rounds : piece.rounds.map((r) => r === 0n ? latest : r);
			let request = this.dtAlgod.query({
				...job.target,
				calls: job.calls.slice(piece.start, piece.end),
				...job.budget !== void 0 ? { budget: job.budget } : {}
			}).rounds(rounds);
			if (job.protocol) request = request.protocol(job.protocol);
			response = await request.do(void 0, { signal: this.controller.signal });
		} catch (e) {
			failed = true;
			error = e;
		} finally {
			this.release();
		}
		if (!failed) return this.record(piece, response);
		const split = this.controller.signal.aborted ? void 0 : this.split(piece, error);
		if (!split) {
			this.fail(error);
			throw error;
		}
		if (split === "alone") return await this.recordAlone(piece, error);
		await Promise.all(split.map((p) => this.send(p)));
	}
	/**
	* How to split a request the node refused as too large (results over `maxResponseBytes`, or a body over its limit) or
	* too slow (504): by rounds, then by calls. `alone` when it is one call that can't be split further (at one round, or for
	* the body limit at any number of rounds); undefined for any other error.
	*/
	split(piece, error) {
		const status = errorStatus(error);
		const tooLarge = this.tt.isQueryResponseTooLarge(error);
		const bodyTooLarge = status === 400 && /request body too large/.test(errorText(error));
		if (!tooLarge && !bodyTooLarge && status !== 504) return void 0;
		if (piece.rounds.length > 1 && !bodyTooLarge) {
			const half = Math.ceil(piece.rounds.length / 2);
			return [{
				...piece,
				rounds: piece.rounds.slice(0, half)
			}, {
				...piece,
				rounds: piece.rounds.slice(half)
			}];
		}
		if (piece.end - piece.start > 1) {
			if (piece.rounds.includes(0n)) this.pinLatest();
			const mid = piece.start + Math.ceil((piece.end - piece.start) / 2);
			return [{
				...piece,
				end: mid
			}, {
				...piece,
				start: mid
			}];
		}
		return "alone";
	}
	record(piece, response) {
		const results = this.results[piece.job];
		response.rounds.forEach((r, i) => {
			const acc = results.get(piece.rounds[i]);
			if (r.round) acc.round = r.round;
			if (r.error !== void 0) {
				acc.error ??= r.error;
				return;
			}
			acc.overrides.push(offsetProtocolOverride(r.protocolOverride, piece.start));
			r.calls.forEach((c, k) => acc.calls[piece.start + k] = c);
		});
	}
	/** Records a call that the node couldn't answer even alone, as failed with the node's message at each round of the request. */
	async recordAlone(piece, error) {
		const results = this.results[piece.job];
		let latest;
		if (piece.rounds.includes(0n)) try {
			latest = await this.pinLatest();
		} catch (e) {
			this.fail(e);
			throw e;
		}
		for (const r of piece.rounds) {
			const acc = results.get(r);
			if (r === 0n && acc.round === 0n) acc.round = latest;
			for (let k = piece.start; k < piece.end; k++) acc.calls[k] = {
				logs: [],
				error: nodeMessage(error)
			};
		}
	}
};
/**
* Read-only TEAL queries on dtalgod (`POST /v2/query`): many calls of one program or app, each alone, at many rounds, with
* their logs and cost. No signatures, fees or minimum balances; every resource is available without references; nothing
* is written.
*
* Needs dtalgosdk and a dtalgod with queries on (`MaxAPIQueryCalls` above 0), which its simulate limits report.
*/
var QueryManager = class {
	_clientManager;
	_simulate;
	/**
	* Create a new query manager.
	* @param clientManager The `ClientManager` client to use for algod
	* @param simulateManager The `SimulateManager` to fall back to
	*/
	constructor(clientManager, simulateManager) {
		this._clientManager = clientManager;
		this._simulate = simulateManager;
	}
	/**
	* Returns the node's query limits: how many calls and rounds a request may hold, the most budget and log bytes of a
	* call, and the most bytes of a response. `run` keeps to them. Undefined when the node has no queries (stock algod, or
	* dtalgod with queries disabled). The limits are asked for once per algod client, with the simulate limits.
	*
	* @returns The node's query limits, if it has queries
	* @throws DTNotAvailableError if the loaded algosdk is not dtalgosdk
	* @example
	* ```typescript
	* const limits = await algorand.query.limits()
	* if (limits) console.log(limits.maxCalls, limits.maxRounds)
	* ```
	*/
	async limits() {
		requireDTSdk("Reading the query limits");
		return await getQueryLimits(this._clientManager.algod);
	}
	/**
	* Returns whether queries can be used: the loaded algosdk is dtalgosdk, and the node reports query limits. Never throws
	* `DTNotAvailableError`.
	*
	* @returns Whether `run` can be used
	* @example
	* ```typescript
	* if (await algorand.query.supported()) { ... }
	* ```
	*/
	async supported() {
		if (!getDTSdk()) return false;
		return await getQueryLimits(this._clientManager.algod) !== void 0;
	}
	/**
	* Runs read-only calls of one program (each call creates an app running it) or one deployed app (each call is a NoOp
	* call of it) at each round, in as few requests as the node's limits allow.
	*
	* Each call is an app call alone in its group, in the block after the round, on the state that round left: no
	* signatures, fees or minimum balances, every resource available without references, and its writes dropped. A failed
	* call doesn't affect the others.
	*
	* The calls and rounds are split into requests by the node's `maxCalls` and `maxRounds` and by the request body limit,
	* and sent `concurrency` at a time. A request whose results are over the node's `maxResponseBytes`, or that runs over
	* its time limit (504), is split in halves (rounds first) and sent again; a call that is still too large or too slow
	* alone fails on its own (`kind: 'call'`). When the latest round (0) is queried in more than one request, it is
	* resolved first so every call sees the same block. A busy node (503) is retried by the HTTP client of an
	* `AlgorandClient` made from a config (`AlgoHttpClientWithRetry`, honoring `Retry-After`). Any other error (a bad
	* request, a round after the latest one) cancels the requests in flight and is thrown.
	*
	* There is no simulate fallback here; `groups` and `rounds` have one.
	*
	* @param params The program or app, the calls, the rounds and the request options
	* @param options How to send the requests
	* @returns The results at each round, in the order of `rounds` (one, at the latest round, without `rounds`)
	* @throws DTNotAvailableError if the loaded algosdk is not dtalgosdk
	* @throws dtalgosdk's `DTUnsupportedError` if the node has no queries (stock algod, or dtalgod with queries disabled)
	* @example
	* ```typescript
	* const program = (await algorand.app.compileTeal('#pragma version 10\nglobal Round\nitob\nlog\nint 1')).compiledBase64ToBytes
	* const results = await algorand.query.run({ program, rounds: [0, 50_000_000], protocol: 'round', calls: [{}] })
	* for (const { round, calls: [call] } of results) if (call.ok) console.log(round, call.logs[0])
	*
	* // A deployed app at the latest round
	* const [{ calls }] = await algorand.query.run({ appId: 760937186n, calls: [{ args: [selector] }] })
	* ```
	*/
	async run(params, options) {
		const tt = requireDTSdk("Querying");
		const { signal, concurrency = 4, maxCalls, maxRounds } = options ?? {};
		signal?.throwIfAborted();
		checkPositiveInteger("concurrency", concurrency);
		checkPositiveInteger("maxCalls", maxCalls);
		checkPositiveInteger("maxRounds", maxRounds);
		const { program, clearProgram, globalSchema, localSchema, appId, sender, protocol, budget, calls } = params;
		if (!calls || calls.length === 0) throw new Error("A query needs at least one call");
		const hasProgram = program !== void 0 && program.length > 0;
		const hasApp = appId !== void 0 && BigInt(appId) !== 0n;
		if (hasProgram === hasApp) throw new Error("A query needs exactly one of program and appId");
		const nonZero = (schema) => schema !== void 0 && (schema.numUint !== 0 || schema.numByteSlice !== 0);
		if (hasApp && (clearProgram !== void 0 && clearProgram.length > 0 || nonZero(globalSchema) || nonZero(localSchema))) throw new Error("clearProgram, globalSchema and localSchema need program, not appId");
		const rounds = params.rounds && params.rounds.length > 0 ? params.rounds.map((r) => BigInt(r)) : [0n];
		const negative = rounds.find((r) => r < 0n);
		if (negative !== void 0) throw new RangeError(`Can't query at round ${negative}`);
		const nodeLimits = await getSimulateLimits(this._clientManager.algod);
		const limits = nodeLimits?.query;
		if (!limits) throw new tt.DTUnsupportedError(noQueryMessage(nodeLimits));
		if (budget !== void 0 && (!Number.isInteger(budget) || budget < 1 || budget > limits.maxCallBudget)) throw new RangeError(`budget must be a positive integer of at most the node's maxCallBudget ${limits.maxCallBudget}, not ${budget}`);
		const target = hasProgram ? {
			program,
			...clearProgram?.length ? { clearProgram } : {},
			...globalSchema ? { globalSchema } : {},
			...localSchema ? { localSchema } : {}
		} : { appId: BigInt(appId) };
		if (sender !== void 0) target.sender = sender.toString();
		const job = {
			target,
			calls: calls.map(toQueryCall),
			rounds: [...new Set(rounds)],
			protocol,
			budget
		};
		const [results] = await this.newRun(tt, limits, {
			signal,
			concurrency,
			maxCalls,
			maxRounds
		}).execute([job]);
		return rounds.map((r) => toRunResult(results.get(r), calls.length));
	}
	/**
	* Queries composed app calls at one round (the latest by default), with simulate as the fallback: a drop-in for
	* `algorand.simulate.groups(composers, { parallel: true })` for read-only calls.
	*
	* With query, every app call runs alone, against the round's state: the calls of one group don't see each other (no
	* shared budget pool, `global GroupSize` 1, no `gtxn`), and the composers' fees, validity, notes and leases are ignored;
	* each call gets the node's `maxCallBudget`. With simulate, the groups run as composed, each on its own (`parallel`).
	* So use it for independent read-only calls, such as ghost calls. The protocol defaults to `round` (the round's own,
	* as simulate does).
	*
	* `via: 'auto'` (the default) queries when all of these hold, and simulates otherwise:
	* - the node reports query limits (it has queries on);
	* - `execTraceConfig` is off;
	* - without `allowMoreLogging`, or with the node's `maxCallLogBytes` at least simulate's 65,536;
	* - with `extraOpcodeBudget`, it plus 700 per transaction is at most `maxCallBudget` for every group;
	* - every transaction is a NoOp app call that creates an app (with an approval program) or calls one (without
	*   programs), without an access list or `rejectVersion`, and no method call has transaction arguments.
	*
	* The options are checked the same way whichever path is taken. A node without queries met mid-way (a load balancer
	* mixing nodes) falls back to simulate with `auto`.
	*
	* Unlike `algorand.simulate.groups`, a round the query can't run at gives `kind: 'round'` outcomes (a bad round still
	* fails the whole request).
	*
	* @param composers The groups, one composer each
	* @param options The simulate options and the routing
	* @returns The outcome of each group, in order
	* @example
	* ```typescript
	* const composer = algorand.newGroup().addAppCreateMethodCall({ sender, method, args, approvalProgram, clearStateProgram, schema })
	* const [outcome] = await algorand.query.groups([composer])
	* if (outcome.ok) console.log(outcome.via, outcome.returns[0]?.returnValue, outcome.txns[0].logs)
	* ```
	*/
	async groups(composers, options) {
		const { round, ...rest } = options ?? {};
		const [outcomes] = await this.composed(composers, { round: round ? BigInt(round) : 0n }, rest);
		return outcomes.groups;
	}
	/**
	* Queries composed app calls at several past rounds, with simulate as the fallback: a drop-in for
	* `algorand.simulate.rounds(composers, rounds, { parallel: true })` for read-only calls. See `groups` for what query
	* runs and when it is used.
	*
	* @param composers The groups, one composer each (or a single composer)
	* @param rounds The rounds to query at (each > 0): the state as of the end of each round
	* @param options The simulate options and the routing
	* @returns The outcomes at each round, in the order of `rounds`
	* @example
	* ```typescript
	* const composer = algorand.newGroup().addAppCallMethodCall(await appClient.params.call({ method: 'get_price' }))
	* const prices = await algorand.query.rounds(composer, [45_000_000n, 45_001_000n, 45_002_000n])
	* for (const { round, groups: [g] } of prices) if (g.ok) console.log(round, g.returns[0]?.returnValue)
	* ```
	*/
	async rounds(composers, rounds, options) {
		const groups = Array.isArray(composers) ? composers : [composers];
		if (rounds.length === 0) return [];
		const requested = rounds.map((r) => BigInt(r));
		const zero = requested.find((r) => r < 1n);
		if (zero !== void 0) throw new RangeError(`Can't query at round ${zero} in rounds: give past rounds (look the latest round up with status())`);
		return await this.composed(groups, { rounds: requested }, options ?? {});
	}
	/** Validates the options, then queries or simulates. */
	async composed(composers, at, options) {
		const { via = "auto", concurrency, ...simulateOptions } = options;
		if (via !== "auto" && via !== "query" && via !== "simulate") throw new Error(`via must be 'auto', 'query' or 'simulate', not ${JSON.stringify(via)}`);
		checkPositiveInteger("concurrency", concurrency);
		if (composers.length === 0) throw new Error("No transaction groups to query");
		requireDTSdk("Querying composed app calls");
		checkValidityWindow(simulateOptions);
		simulateOptions.signal?.throwIfAborted();
		checkSimulateLimits(await requireDTNode(this._clientManager.algod, "Querying composed app calls"), simulateOptions.protocol, simulateOptions);
		if (via !== "simulate") {
			const plan = await this.queryPlan(composers, simulateOptions, "round" in at ? at.round : void 0);
			if (plan.ok) try {
				return await this.viaQuery(plan, at, simulateOptions, concurrency ?? 4);
			} catch (error) {
				if (via === "query" || !isDTUnsupportedError(error)) throw error;
				Config.logger.debug(`Querying through simulate: ${error.message}`);
			}
			else {
				if (via === "query") throw plan.error();
				Config.logger.debug(`Querying through simulate: ${plan.reason}`);
			}
		}
		return await this.viaSimulate(composers, at, {
			...simulateOptions,
			...concurrency !== void 0 ? { concurrency } : {}
		});
	}
	/** Whether the groups can be queried with these options, with the built groups if so. */
	async queryPlan(composers, options, round) {
		const no = (reason, error = () => /* @__PURE__ */ new Error(`Can't query these groups: ${reason}`)) => ({
			ok: false,
			reason,
			error
		});
		const tt = getDTSdk();
		if (!tt) return no("the loaded algosdk is not dtalgosdk", () => new DTNotAvailableError("Querying"));
		const nodeLimits = await getSimulateLimits(this._clientManager.algod);
		const limits = nodeLimits?.query;
		if (!limits) return no("the node has queries disabled", () => new tt.DTUnsupportedError(noQueryMessage(nodeLimits)));
		if (options.execTraceConfig?.enable) return no("execTraceConfig needs simulate");
		if (options.allowMoreLogging && limits.maxCallLogBytes < SIMULATE_MORE_LOGGING_BYTES) return no(`allowMoreLogging allows more log bytes than the node's queries (maxCallLogBytes ${limits.maxCallLogBytes})`);
		const built = [];
		for (const composer of composers) {
			const b = round ? await composer.buildTransactionsWithValidity({
				firstValidRound: round + 1n,
				lastValidRound: round + 11n
			}) : await composer.buildTransactions();
			if (b.transactions.length === 0) throw new Error(`Transaction group ${built.length} is empty`);
			built.push(b);
		}
		const { extraOpcodeBudget } = options;
		for (const [g, b] of built.entries()) {
			if (extraOpcodeBudget !== void 0) {
				const pool = BigInt(extraOpcodeBudget) + BigInt(APP_CALL_BUDGET * b.transactions.length);
				if (pool > BigInt(limits.maxCallBudget)) return no(`group ${g} gets a budget of ${pool} with simulate, more than a query call's maxCallBudget ${limits.maxCallBudget}`);
			}
			for (const [t, txn] of b.transactions.entries()) {
				const why = notQueryable(txn);
				if (why) return no(`transaction ${t} of group ${g} ${why}`);
			}
			for (const [t, method] of b.methodCalls) if (method.args.some((a) => algosdk.abiTypeIsTransaction(a.type))) return no(`the method call at transaction ${t} of group ${g} has transaction arguments`);
		}
		return {
			ok: true,
			tt,
			limits,
			built
		};
	}
	/** Queries the groups' app calls: one job per target (program or app, and sender), sharing one run. */
	async viaQuery(plan, at, options, concurrency) {
		const { tt, limits, built } = plan;
		const parts = [];
		const where = built.map((b, g) => b.transactions.map((txn, t) => {
			const target = targetOf(txn);
			let part = parts.findIndex((p) => sameTarget(p.target, target));
			if (part < 0) part = parts.push({
				target,
				calls: [],
				refs: []
			}) - 1;
			parts[part].calls.push(callOf(txn));
			parts[part].refs.push({
				group: g,
				txn: t
			});
			return {
				part,
				call: parts[part].calls.length - 1
			};
		}));
		const requested = "rounds" in at ? at.rounds : [at.round];
		const protocol = options.protocol ?? "round";
		const results = await this.newRun(tt, limits, {
			signal: options.signal,
			concurrency,
			maxRounds: options.maxRounds || void 0
		}).execute(parts.map((p) => ({
			target: p.target,
			calls: p.calls,
			rounds: [...new Set(requested)],
			protocol
		})));
		return requested.map((r) => {
			const accs = results.map((m) => m.get(r));
			const round = r === 0n ? accs[0].round : r;
			const error = accs.find((a) => a.error !== void 0)?.error;
			const protocolOverride = error === void 0 ? mergeProtocolOverrides(accs.map((acc, p) => mapProtocolOverrideHits(mergeProtocolOverrides(acc.overrides), (h) => {
				const ref = parts[p].refs[h.group];
				return ref ? {
					group: ref.group,
					path: [ref.txn, ...h.path.slice(1)]
				} : h;
			}))) : void 0;
			return {
				round,
				groups: built.map((b, g) => toQueryGroupOutcome(b, g, round, error, where[g].map((w) => accs[w.part].calls[w.call]), protocolOverride)),
				...protocolOverride ? { protocolOverride } : {}
			};
		});
	}
	/** Simulates the groups in parallel, as `algorand.simulate` does, and maps the outcomes. */
	async viaSimulate(composers, at, options) {
		if ("round" in at) {
			const { maxRounds: _maxRounds, validityWindow: _validityWindow, ...rest } = options;
			const outcomes = await this._simulate.groups(composers, {
				...rest,
				...at.round ? { round: at.round } : {},
				parallel: true
			});
			const protocolOverride = outcomes.find((o) => o.protocolOverride)?.protocolOverride;
			return [{
				round: outcomes[0]?.round ?? at.round,
				groups: outcomes.map(fromSimulateOutcome),
				...protocolOverride ? { protocolOverride } : {}
			}];
		}
		return (await this._simulate.rounds(composers, at.rounds, {
			...options,
			parallel: true
		})).map((r) => ({
			round: r.round,
			groups: r.groups.map(fromSimulateOutcome),
			...r.protocolOverride ? { protocolOverride: r.protocolOverride } : {}
		}));
	}
	/** A run of query requests within the node's limits. */
	newRun(tt, limits, { signal, concurrency, maxCalls, maxRounds }) {
		return new QueryRun(this._clientManager.algod, this._clientManager.dtAlgod, tt, limits, {
			signal,
			concurrency,
			maxCalls: maxCalls ?? Infinity,
			maxRounds: maxRounds ?? Infinity
		});
	}
};
/** The outcome of each call at one round. */
function toRunResult(acc, callCount) {
	const { round, error } = acc;
	const protocolOverride = error === void 0 ? mergeProtocolOverrides(acc.overrides) : void 0;
	const calls = Array.from({ length: callCount }, (_, callIndex) => {
		if (error !== void 0) return {
			callIndex,
			round,
			ok: false,
			error: new QueryCallError({
				kind: "round",
				callIndex,
				round,
				failureMessage: error
			})
		};
		const c = acc.calls[callIndex];
		if (!c) return {
			callIndex,
			round,
			ok: false,
			error: new QueryCallError({
				kind: "call",
				callIndex,
				round,
				failureMessage: "the node returned no result for the call"
			})
		};
		if (c.error !== void 0) return {
			callIndex,
			round,
			ok: false,
			error: new QueryCallError({
				kind: "call",
				callIndex,
				round,
				failureMessage: c.error,
				logs: c.logs,
				cost: c.cost
			})
		};
		return {
			callIndex,
			round,
			ok: true,
			logs: c.logs,
			cost: c.cost ?? 0
		};
	});
	return {
		round,
		...protocolOverride ? { protocolOverride } : {},
		calls
	};
}
/** Why a transaction can't be a query call, or undefined if it can. */
function notQueryable(txn) {
	const app = txn.applicationCall;
	if (txn.type !== algosdk.TransactionType.appl || !app) return `is a ${txn.type} transaction, not an app call`;
	if (app.onComplete !== algosdk.OnApplicationComplete.NoOpOC) return `has OnComplete ${algosdk.OnApplicationComplete[app.onComplete] ?? app.onComplete}, not NoOp`;
	if (app.access.length > 0) return "has an access list";
	if (app.rejectVersion) return "sets rejectVersion";
	if (app.appIndex === 0n) return app.approvalProgram.length > 0 ? void 0 : "creates an app without an approval program";
	return app.approvalProgram.length > 0 || app.clearProgram.length > 0 ? "calls an existing app with programs" : void 0;
}
/** The query target of an app call. */
function targetOf(txn) {
	const app = txn.applicationCall;
	const sender = txn.sender.toString();
	if (app.appIndex !== 0n) return {
		appId: app.appIndex,
		sender
	};
	const schema = (numUint, numByteSlice) => numUint || numByteSlice ? {
		numUint,
		numByteSlice
	} : void 0;
	const globalSchema = schema(app.numGlobalInts, app.numGlobalByteSlices);
	const localSchema = schema(app.numLocalInts, app.numLocalByteSlices);
	return {
		program: app.approvalProgram,
		...app.clearProgram.length > 0 ? { clearProgram: app.clearProgram } : {},
		...globalSchema ? { globalSchema } : {},
		...localSchema ? { localSchema } : {},
		sender
	};
}
const sameBytes = (a, b) => {
	if (a === b) return true;
	if (!a || !b || a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
};
const sameSchema = (a, b) => a?.numUint === b?.numUint && a?.numByteSlice === b?.numByteSlice;
/** Whether two targets are the same request target. */
function sameTarget(a, b) {
	return a.sender === b.sender && a.appId === b.appId && sameSchema(a.globalSchema, b.globalSchema) && sameSchema(a.localSchema, b.localSchema) && sameBytes(a.program, b.program) && sameBytes(a.clearProgram, b.clearProgram);
}
/** The query call of an app call: its args and references. */
function callOf(txn) {
	const app = txn.applicationCall;
	return {
		...app.appArgs.length ? { args: [...app.appArgs] } : {},
		...app.accounts.length ? { accounts: app.accounts.map((a) => a.toString()) } : {},
		...app.foreignApps.length ? { foreignApps: [...app.foreignApps] } : {},
		...app.foreignAssets.length ? { foreignAssets: [...app.foreignAssets] } : {},
		...app.boxes.length ? { boxes: app.boxes.map((b) => ({
			app: b.appIndex,
			name: b.name
		})) } : {}
	};
}
/** The outcome of a queried group from the results of its calls. */
function toQueryGroupOutcome(built, groupIndex, round, roundError, calls, protocolOverride) {
	const base = {
		groupIndex,
		round,
		via: "query",
		...protocolOverride ? { protocolOverride } : {}
	};
	const fail = (error) => ({
		...base,
		ok: false,
		error
	});
	if (roundError !== void 0) return fail(new QueryGroupError({
		kind: "round",
		groupIndex,
		round,
		failureMessage: roundError
	}));
	if (calls.some((c) => !c)) return fail(new QueryGroupError({
		kind: "missing",
		groupIndex,
		round
	}));
	const results = calls;
	const txnResult = (c) => ({
		logs: c.logs,
		...c.cost !== void 0 ? { cost: c.cost } : {}
	});
	const failed = results.findIndex((c) => c.error !== void 0);
	if (failed >= 0) return fail(new QueryGroupError({
		kind: "group",
		groupIndex,
		round,
		failureMessage: /^logic eval error/.test(results[failed].error) ? `transaction ${txIdsOf(built).txIds[failed]}: ${results[failed].error}` : results[failed].error,
		failedAt: [failed],
		txns: results.map((c) => ({
			...txnResult(c),
			...c.error !== void 0 ? { error: c.error } : {}
		}))
	}));
	const { txIds } = txIdsOf(built);
	const returns = [...built.methodCalls.entries()].map(([index, method]) => getABIReturnValue(algosdk.AtomicTransactionComposer.parseMethodResponse(method, {
		txID: txIds[index],
		rawReturnValue: /* @__PURE__ */ new Uint8Array(),
		method
	}, { logs: results[index].logs }), method.returns.type));
	return {
		...base,
		ok: true,
		txns: results.map(txnResult),
		returns
	};
}
/** The simulate transaction results of a response, by their confirmation (`txnResult`). */
const simulateResults = /* @__PURE__ */ new WeakMap();
function simulateResultsOf(response) {
	let results = simulateResults.get(response);
	if (!results) {
		results = /* @__PURE__ */ new Map();
		const rounds = response.roundResults ?? [];
		for (const group of [...response.txnGroups, ...rounds.flatMap((r) => r.txnGroups)]) for (const t of group.txnResults) results.set(t.txnResult, t);
		simulateResults.set(response, results);
	}
	return results;
}
/** A simulate outcome as a query outcome. */
function fromSimulateOutcome(o) {
	const { groupIndex, round } = o;
	const base = {
		groupIndex,
		round,
		via: "simulate",
		...o.protocolOverride ? { protocolOverride: o.protocolOverride } : {}
	};
	const cost = (t) => t?.appBudgetConsumed !== void 0 ? { cost: t.appBudgetConsumed } : {};
	if (o.ok) {
		const results = simulateResultsOf(o.result.simulateResponse);
		return {
			...base,
			ok: true,
			txns: o.result.confirmations.map((c) => ({
				logs: c.logs ?? [],
				...cost(results.get(c))
			})),
			returns: o.result.returns ?? []
		};
	}
	const { kind, failureMessage, failedAt, result } = o.error;
	const txns = result?.txnResults.map((t, i) => ({
		logs: t.txnResult.logs ?? [],
		...cost(t),
		...failedAt?.[0] === i && failureMessage !== void 0 ? { error: failureMessage } : {}
	}));
	return {
		...base,
		ok: false,
		error: new QueryGroupError({
			kind,
			groupIndex,
			round,
			failureMessage,
			failedAt,
			txns,
			cause: o.error
		})
	};
}
//#endregion
export { DEFAULT_QUERY_CONCURRENCY, QueryCallError, QueryGroupError, QueryManager };

//# sourceMappingURL=query-manager.mjs.map